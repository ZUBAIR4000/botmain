import os
import random
import asyncio
import discord
from discord.ext import commands
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import yt_dlp as youtube_dl

# Spotify configuration
SPOTIFY_PLAYLIST_ID = '7Hoy49clpCEF67cogAUycl'
SPOTIFY_CLIENT_ID = '34f7f6a5211f4bf59df7253eac3822c7'
SPOTIFY_CLIENT_SECRET= 'b3030384df9c4e418902bc37c5a23766'

# YouTube DL configuration
YTDL_OPTIONS = {
    'format': 'bestaudio/best',
    'noplaylist': True,
    'quiet': True,
    'default_search': 'ytsearch',
    'source_address': '0.0.0.0',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn -loglevel quiet'
}

class RadioControlView(discord.ui.View):
    def __init__(self, radio_cog, voice_client, ctx):
        super().__init__(timeout=None)
        self.radio_cog = radio_cog
        self.voice_client = voice_client
        self.ctx = ctx

    @discord.ui.button(emoji='<:backward:1389287120543420546>', style=discord.ButtonStyle.grey)
    async def backward(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.voice and interaction.user.voice.channel == self.voice_client.channel:
            await interaction.response.send_message("⏮️ Going to previous song...", ephemeral=True)
            await self.radio_cog.skip_song(backward=True)
        else:
            await interaction.response.send_message("You must be in the VC to control the radio.", ephemeral=True)

    @discord.ui.button(emoji='<:pause:1389287098690961630>', style=discord.ButtonStyle.grey)
    async def pause(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.voice and interaction.user.voice.channel == self.voice_client.channel:
            if self.voice_client.is_playing():
                self.voice_client.pause()
                await interaction.response.send_message("⏸️ Paused the song.", ephemeral=True)
            elif self.voice_client.is_paused():
                self.voice_client.resume()
                await interaction.response.send_message("▶️ Resumed the song.", ephemeral=True)
            else:
                await interaction.response.send_message("Nothing is playing.", ephemeral=True)
        else:
            await interaction.response.send_message("You must be in the VC to control the radio.", ephemeral=True)

    @discord.ui.button(emoji='<:next:1389287150058475520>', style=discord.ButtonStyle.grey)
    async def next(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.voice and interaction.user.voice.channel == self.voice_client.channel:
            await interaction.response.send_message("⏭️ Skipping to next song...", ephemeral=True)
            await self.radio_cog.skip_song()
        else:
            await interaction.response.send_message("You must be in the VC to control the radio.", ephemeral=True)

class RadioCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.spotify = spotipy.Spotify(auth_manager=SpotifyClientCredentials(
            client_id=SPOTIFY_CLIENT_ID,
            client_secret=SPOTIFY_CLIENT_SECRET
        ))
        self.playlist_tracks = []
        self.loaded = False
        self.radio_task = None
        self.current_index = 0
        self.skip_event = asyncio.Event()
        self.backward_event = asyncio.Event()

        bot.loop.create_task(self.auto_start_radio())

    async def auto_start_radio(self):
        await self.bot.wait_until_ready()
        channel_id = 1386291136011964447
        voice_channel = self.bot.get_channel(channel_id)
        if not voice_channel:
            print("vc deleted")
            return

        if not self.loaded:
            print("loading assets")
            await self.load_playlist()

        guild = voice_channel.guild
        voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
        try:
            if voice_client:
                await voice_client.move_to(voice_channel)
            else:
                voice_client = await voice_channel.connect()
        except Exception as e:
            print(f"nope {e}")
            return

        await asyncio.sleep(5)

        try:
            await voice_channel.edit(name="24/7 Radio 808s")
            await guild.change_voice_state(channel=voice_channel, self_deaf=True)
        except discord.Forbidden:
            print("⚠️ Missing permissions to edit channel or self-deafen")

        if not self.radio_task or self.radio_task.done():
            self.radio_task = self.bot.loop.create_task(self.play_radio(voice_client, voice_channel))

    async def load_playlist(self):
        if self.loaded:
            return
        results = self.spotify.playlist_tracks(SPOTIFY_PLAYLIST_ID)
        while results:
            for item in results['items']:
                track = item['track']
                if track:
                    artists = ", ".join([artist['name'] for artist in track['artists']])
                    duration = track['duration_ms'] // 1000
                    minutes, seconds = divmod(duration, 60)
                    self.playlist_tracks.append({
                        "name": track['name'],
                        "artists": artists,
                        "duration": f"{minutes}:{seconds:02d}",
                        "album_cover": track['album']['images'][0]['url'] if track['album']['images'] else None,
                        "query": f"{track['name']} - {artists}"
                    })
            if results['next']:
                results = self.spotify.next(results)
            else:
                results = None
        self.loaded = True
        print(f"Loaded {len(self.playlist_tracks)} tracks from Spotify playlist")

    def get_track(self, index):
        if not self.playlist_tracks:
            return None
        return self.playlist_tracks[index % len(self.playlist_tracks)]

    def get_youtube_url(self, query):
        with youtube_dl.YoutubeDL(YTDL_OPTIONS) as ydl:
            try:
                info = ydl.extract_info(f"ytsearch:{query}", download=False)
                if 'entries' in info and info['entries']:
                    return info['entries'][0]['url']
            except Exception as e:
                print(f"YouTube search error: {e}")
            return None

    async def play_radio(self, voice_client, voice_channel):
        while voice_client.is_connected():
            track = self.get_track(self.current_index)
            if not track:
                await asyncio.sleep(5)
                continue

            url = await self.bot.loop.run_in_executor(None, self.get_youtube_url, track["query"])
            if not url:
                await asyncio.sleep(2)
                continue

            try:
                source = discord.FFmpegPCMAudio(url, **FFMPEG_OPTIONS)
                voice_client.play(source)


                await self.wait_for_song_end(voice_client)
            except Exception as e:
                print(f"Playback error: {e}")
                await asyncio.sleep(5)

            # Wait for skip/backward events or song end
            if self.backward_event.is_set():
                self.current_index = (self.current_index - 1) % len(self.playlist_tracks)
                self.backward_event.clear()
            else:
                self.current_index = (self.current_index + 1) % len(self.playlist_tracks)
            self.skip_event.clear()

    async def wait_for_song_end(self, voice_client):
        while voice_client.is_playing() or voice_client.is_paused():
            await asyncio.sleep(1)
            if self.skip_event.is_set() or self.backward_event.is_set():
                voice_client.stop()
                break

    async def skip_song(self, backward=False):
        if backward:
            self.backward_event.set()
        else:
            self.skip_event.set()

    @commands.command()
    async def radio(self, ctx):
        """Start the 24/7 radio in the designated channel"""
        channel_id = 1386291136011964447
        voice_channel = self.bot.get_channel(channel_id)
        
        if not voice_channel:
            return await ctx.send("❌ Radio channel not found")
        
        if not self.loaded:
            await ctx.send("⏳ Loading playlist...")
            await self.load_playlist()

        try:
            if ctx.voice_client:
                await ctx.voice_client.move_to(voice_channel)
            else:
                voice_client = await voice_channel.connect()
        except Exception as e:
            return await ctx.send(f"❌ Connection error: {e}")
        
        await ctx.send("✅ ok")
        await asyncio.sleep(5)
        try:
            await voice_channel.edit(name="24/7 Radio 808s")
            await ctx.guild.change_voice_state(channel=voice_channel, self_deaf=True)
        except discord.Forbidden:
            await ctx.send("⚠️ Missing permissions to edit channel or self-deafen")
        
        if not self.radio_task or self.radio_task.done():
            self.radio_task = self.bot.loop.create_task(self.play_radio(ctx.voice_client, voice_channel))

async def setup(bot):
    await bot.add_cog(RadioCog(bot))
