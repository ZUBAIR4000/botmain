import discord
from PIL import Image, ImageDraw, ImageFont, ImageOps
import requests
from io import BytesIO
import os
import random
import math


def create_embed(description: str) -> discord.Embed:
    return discord.Embed(
        description=description,
        color=0xFAFAFA
    )

async def download_image(url: str) -> Image.Image:
    response = requests.get(url)
    return Image.open(BytesIO(response.content))

def create_collage(images: list, username: str) -> BytesIO:
    # Calculate grid size (max 4 columns)
    cols = min(4, len(images))
    rows = math.ceil(len(images) / cols)
    
    # Create blank canvas
    collage = Image.new('RGB', (cols * 300, rows * 300 + 50), (240, 240, 240))
    draw = ImageDraw.Draw(collage)
    
    # Paste images in grid
    for i, img in enumerate(images):
        img = ImageOps.fit(img, (280, 280), Image.LANCZOS)
        x = (i % cols) * 300 + 10
        y = (i // cols) * 300 + 10
        collage.paste(img, (x, y))
    
    # Add watermarks
    font = ImageFont.load_default()
    draw.text((10, rows * 300 + 15), "discord.gg/808s", fill="black", font=font)
    username_width = draw.textlength(username, font=font)
    draw.text((collage.width - username_width - 10, rows * 300 + 15), username, fill="black", font=font)
    
    # Save to bytes
    buffer = BytesIO()
    collage.save(buffer, format='PNG')
    buffer.seek(0)
    return buffer

def create_stats_image(user: discord.User, avatar: Image.Image, smash: int, pass_: int) -> BytesIO:
    total = smash + pass_
    ratio = smash / total if total > 0 else 0
    
    # Create blank image
    img = Image.new('RGB', (800, 600), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Add title
    font_large = ImageFont.truetype("arial.ttf", 40)
    title = f"{user.display_name}'s FaceID Stats"
    draw.text((400 - draw.textlength(title, font_large)/2, 50), title, fill="white", font=font_large)
    
    # Create circular avatar
    mask = Image.new('L', (250, 250), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, 250, 250), fill=255)
    avatar = ImageOps.fit(avatar, (250, 250), Image.LANCZOS)
    img.paste(avatar, (275, 150), mask)
    
    # Progress bar (Attractiveness)
    bar_width = 400
    bar_height = 40
    bar_x = 200
    bar_y = 450
    
    # Background bar
    draw.rectangle([bar_x, bar_y, bar_x + bar_width, bar_y + bar_height], fill=(50, 50, 50))
    
    # Filled portion
    fill_width = int(bar_width * ratio)
    draw.rectangle([bar_x, bar_y, bar_x + fill_width, bar_y + bar_height], fill=(76, 181, 249))
    
    # Percentage text
    percent_text = f"{ratio*100:.1f}%"
    font_medium = ImageFont.truetype("arial.ttf", 30)
    draw.text((bar_x + bar_width + 10, bar_y), percent_text, fill="white", font=font_medium)
    
    # Stats boxes
    box_width = 200
    box_height = 80
    box_y = 500
    
    # Smash box
    draw.rounded_rectangle([100, box_y, 100 + box_width, box_y + box_height], radius=15, fill=(40, 40, 40))
    draw.text((200 - draw.textlength("SMASH", font_medium)/2, box_y + 15), "SMASH", fill=(76, 181, 249), font=font_medium)
    draw.text((200 - draw.textlength(str(smash), font_medium)/2, box_y + 45), str(smash), fill="white", font=font_medium)
    
    # Pass box
    draw.rounded_rectangle([300, box_y, 300 + box_width, box_y + box_height], radius=15, fill=(40, 40, 40))
    draw.text((400 - draw.textlength("PASS", font_medium)/2, box_y + 15), "PASS", fill=(249, 76, 76), font=font_medium)
    draw.text((400 - draw.textlength(str(pass_), font_medium)/2, box_y + 45), str(pass_), fill="white", font=font_medium)
    
    # Total box
    draw.rounded_rectangle([500, box_y, 500 + box_width, box_y + box_height], radius=15, fill=(40, 40, 40))
    draw.text((600 - draw.textlength("TOTAL", font_medium)/2, box_y + 15), "TOTAL", fill=(126, 217, 87), font=font_medium)
    draw.text((600 - draw.textlength(str(total), font_medium)/2, box_y + 45), str(total), fill="white", font=font_medium)
    
    # Watermark
    font_small = ImageFont.truetype("arial.ttf", 20)
    draw.text((10, 570), "discord.gg/808s", fill="white", font=font_small)
    
    # Save to bytes
    buffer = BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    return buffer