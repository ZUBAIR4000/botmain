import discord
from discord.ext import commands
import json
import os

class IgnoreCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ignore_file = "ignore_settings.json"
        self.ignore_settings = self.load_ignore_settings()

    def load_ignore_settings(self):
        if os.path.exists(self.ignore_file):
            try:
                with open(self.ignore_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {"users": {}, "servers": {}}
        return {"users": {}, "servers": {}}

    def save_ignore_settings(self):
        with open(self.ignore_file, 'w') as f:
            json.dump(self.ignore_settings, f, indent=4)

    async def is_command_ignored(self, ctx, command_name):
        """Check if a command is ignored for this user or server"""
        user_id = str(ctx.author.id)
        server_id = str(ctx.guild.id) if ctx.guild else "dm"
        
        # Check user ignores
        if user_id in self.ignore_settings["users"]:
            user_ignores = self.ignore_settings["users"][user_id]
            if "all" in user_ignores or command_name in user_ignores:
                return True
        
        # Check server ignores (only if in a server)
        if ctx.guild and server_id in self.ignore_settings["servers"]:
            server_ignores = self.ignore_settings["servers"][server_id]
            if "all" in server_ignores or command_name in server_ignores:
                return True
        
        return False

    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def ignore(self, ctx, target_type: str, command_name: str):
        """Ignore a command for a user or server. Usage: ,ignore <user/server> <command_name/all>"""
        target_type = target_type.lower()
        
        if target_type not in ["user", "server"]:
            return await ctx.send("Invalid target type! Use 'user' or 'server'.")
        
        if command_name not in ["all"] + [cmd.name for cmd in self.bot.commands]:
            return await ctx.send("Invalid command name! Use 'all' or a valid command name.")
        
        if target_type == "user":
            # For user ignores, users can only ignore themselves unless they have admin perms
            user_id = str(ctx.author.id)
            
            if user_id not in self.ignore_settings["users"]:
                self.ignore_settings["users"][user_id] = []
            
            if command_name in self.ignore_settings["users"][user_id]:
                return await ctx.send(f"Command '{command_name}' is already ignored for you.")
            
            self.ignore_settings["users"][user_id].append(command_name)
            await ctx.send(f"Command '{command_name}' will now be ignored for you.")
        
        elif target_type == "server":
            # For server ignores, require manage_guild permission
            if not ctx.guild:
                return await ctx.send("Server ignores can only be set in a server.")
            
            server_id = str(ctx.guild.id)
            
            if server_id not in self.ignore_settings["servers"]:
                self.ignore_settings["servers"][server_id] = []
            
            if command_name in self.ignore_settings["servers"][server_id]:
                return await ctx.send(f"Command '{command_name}' is already ignored for this server.")
            
            self.ignore_settings["servers"][server_id].append(command_name)
            await ctx.send(f"Command '{command_name}' will now be ignored for this server.")
        
        self.save_ignore_settings()

    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def unignore(self, ctx, target_type: str = None, command_name: str = None):
        """Unignore commands. Usage: ,unignore [user/server] [command_name/all]"""
        if target_type is None and command_name is None:
            # Show all ignored items
            user_id = str(ctx.author.id)
            server_id = str(ctx.guild.id) if ctx.guild else None
            
            ignored_items = []
            
            # User ignores
            if user_id in self.ignore_settings["users"]:
                user_ignores = self.ignore_settings["users"][user_id]
                for cmd in user_ignores:
                    ignored_items.append(f"User: {cmd}")
            
            # Server ignores
            if server_id and server_id in self.ignore_settings["servers"]:
                server_ignores = self.ignore_settings["servers"][server_id]
                for cmd in server_ignores:
                    ignored_items.append(f"Server: {cmd}")
            
            if not ignored_items:
                return await ctx.send("No commands are currently ignored.")
            
            embed = discord.Embed(
                title="Ignored Commands",
                description="\n".join(ignored_items),
                color=0xffff00
            )
            embed.set_footer(text="Use ,unignore <user/server> <command> to unignore specific commands")
            return await ctx.send(embed=embed)
        
        # Specific unignore command
        target_type = target_type.lower()
        
        if target_type not in ["user", "server"]:
            return await ctx.send("Invalid target type! Use 'user' or 'server'.")
        
        if command_name not in ["all"] + [cmd.name for cmd in self.bot.commands]:
            return await ctx.send("Invalid command name! Use 'all' or a valid command name.")
        
        if target_type == "user":
            user_id = str(ctx.author.id)
            
            if user_id not in self.ignore_settings["users"]:
                return await ctx.send("You don't have any ignored commands.")
            
            if command_name == "all":
                # Remove all ignores for this user
                self.ignore_settings["users"][user_id] = []
                if not self.ignore_settings["users"][user_id]:
                    del self.ignore_settings["users"][user_id]
                await ctx.send("All commands have been unignored for you.")
            else:
                # Remove specific command ignore
                if command_name not in self.ignore_settings["users"][user_id]:
                    return await ctx.send(f"Command '{command_name}' is not ignored for you.")
                
                self.ignore_settings["users"][user_id].remove(command_name)
                if not self.ignore_settings["users"][user_id]:
                    del self.ignore_settings["users"][user_id]
                await ctx.send(f"Command '{command_name}' has been unignored for you.")
        
        elif target_type == "server":
            if not ctx.guild:
                return await ctx.send("Server ignores can only be managed in a server.")
            
            server_id = str(ctx.guild.id)
            
            if server_id not in self.ignore_settings["servers"]:
                return await ctx.send("This server doesn't have any ignored commands.")
            
            if command_name == "all":
                # Remove all ignores for this server
                self.ignore_settings["servers"][server_id] = []
                if not self.ignore_settings["servers"][server_id]:
                    del self.ignore_settings["servers"][server_id]
                await ctx.send("All commands have been unignored for this server.")
            else:
                # Remove specific command ignore
                if command_name not in self.ignore_settings["servers"][server_id]:
                    return await ctx.send(f"Command '{command_name}' is not ignored for this server.")
                
                self.ignore_settings["servers"][server_id].remove(command_name)
                if not self.ignore_settings["servers"][server_id]:
                    del self.ignore_settings["servers"][server_id]
                await ctx.send(f"Command '{command_name}' has been unignored for this server.")
        
        self.save_ignore_settings()

    @commands.Cog.listener()
    async def on_command(self, ctx):
        """Check if command should be ignored"""
        if await self.is_command_ignored(ctx, ctx.command.name):
            # Delete the command message if possible
            try:
                await ctx.message.delete()
            except:
                pass
            # Prevent the command from executing
            raise commands.CommandError("This command is ignored.")

async def setup(bot):
    await bot.add_cog(IgnoreCog(bot))