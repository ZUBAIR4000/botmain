import discord
from discord.ext import commands
import os
import asyncio
import logging
import random
from cogs.helper import generate_command_data
from datetime import datetime


class MyBot(commands.Bot):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.launch_time = datetime.utcnow()

# Initialize bot with default prefix and intents
intents = discord.Intents.all()
bot = commands.Bot(
    command_prefix=',',
    intents=intents
)

# Global prefix storage (persists between reloads)
bot.custom_prefixes = {}
bot.DEFAULT_PREFIX = ','

async def determine_prefix(bot, message):
    """Dynamic prefix resolver"""
    guild_id = message.guild.id if message.guild else None
    return commands.when_mentioned_or(
        bot.custom_prefixes.get(guild_id, bot.DEFAULT_PREFIX)
    )(bot, message)

async def load_extensions():
    """Load all cogs on startup"""
    cogs_dir = os.path.join(os.path.dirname(__file__), 'cogs')
    if not os.path.exists(cogs_dir):
        os.makedirs(cogs_dir)
        print(f"Created cogs directory at {cogs_dir}")
    
    for filename in os.listdir(cogs_dir):
        if filename.endswith('.py'):
            try:
                await bot.load_extension(f'cogs.{filename[:-3]}')
                print(f"Successfully loaded cog: {filename}")
            except Exception as e:
                print(f"Failed to load cog {filename}: {e}")

bot.command_prefix = determine_prefix

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} | {bot.user.id}')
    print('------')
    
    # Set bot status with emoji
    status_message = "with my dick"
    await bot.change_presence(
        status=discord.Status.online,
        activity=discord.Game(name=status_message)
    )
    generate_command_data(bot)

@bot.event
async def on_message(message):
    # Process commands (ignore other messages)
    await bot.process_commands(message)

@bot.event
async def on_message_edit(before, after):
    # Treat the edited message as a new message and process commands
    await bot.process_commands(after)
    await bot.on_message(after)

bot.remove_command("help")

@bot.event
async def on_guild_join(guild):
    # Find a channel to send the welcome embed
    channel = None
    for c in guild.text_channels:
        if c.permissions_for(guild.me).send_messages:
            channel = c
            break
    if not channel:
        return

    embed = discord.Embed(
        description="# ty for using Glide \nMy default prefix is `,` \nUse `,help` to see commands.",
        color=discord.Color.white()
    )
    embed.set_author(
        name=bot.user.name,
        icon_url=bot.user.display_avatar.url if hasattr(bot.user, "display_avatar") else bot.user.avatar.url
    )

    view = discord.ui.View()
    # Add 3 grey buttons with URLs
    view.add_item(discord.ui.Button(
        style=discord.ButtonStyle.gray,
        label="Support Server",
        url="https://discord.gg/support"
    ))
    view.add_item(discord.ui.Button(
        style=discord.ButtonStyle.gray,
        label="Invite Bot",
        url=f"https://discord.com/oauth2/authorize?client_id={bot.user.id}&scope=bot"
    ))
    view.add_item(discord.ui.Button(
        style=discord.ButtonStyle.gray,
        label="Commands",
        url="https://yourbotwebsite.com"
    ))

    await channel.send(embed=embed, view=view)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        if ctx.command:
            help_cog = bot.get_cog("HelpSystem")
            if help_cog:
                embed = await help_cog.generate_command_embed(ctx, ctx.command.name)
                if embed:
                    await ctx.send(embed=embed)
                else:
                    await ctx.send(f"Usage: `{ctx.command.name}` is missing required arguments.")
            else:
                await ctx.send(f"Usage: `{ctx.command.name}` is missing required arguments.")
        return

async def main():
    async with bot:
        await load_extensions()
        await bot.start('MTM4NTQwODMyMjE1NjM2ODA0NQ.Gbrfn3.dyag2HEGyGvl6bQP9xM1QOz-hCgiPEOuqiI9G8')

if __name__ == '__main__':
    asyncio.run(main())
