// State management
let currentSequence = null;
let currentWord = null;
let lastBotMessageId = null;
let autoSendEnabled = true;
let soundEnabled = true;

// Load settings
chrome.storage.sync.get(['autoSend', 'soundEnabled'], (result) => {
  autoSendEnabled = result.autoSend !== false;
  soundEnabled = result.soundEnabled !== false;
});

// Listen for settings changes
chrome.storage.onChanged.addListener((changes) => {
  if (changes.autoSend) {
    autoSendEnabled = changes.autoSend.newValue;
  }
  if (changes.soundEnabled) {
    soundEnabled = changes.soundEnabled.newValue;
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'getState') {
    sendResponse({ sequence: currentSequence, word: currentWord });
  }
  
  if (message.type === 'generateNewWord' && currentSequence) {
    generateWord(currentSequence).then(word => {
      currentWord = word;
      chrome.runtime.sendMessage({ 
        type: 'wordGenerated', 
        sequence: currentSequence,
        word: currentWord
      });
      if (autoSendEnabled) {
        typeWord(word);
      }
    });
  }
  
  if (message.type === 'copyWord' && currentWord) {
    copyToClipboard(currentWord);
  }
});

// Find Discord's message container
const messageContainer = document.querySelector('[aria-label*="Message"]');

if (messageContainer) {
  // Set up MutationObserver to watch for new messages
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          const message = node.querySelector('[class^="messageContent"]');
          if (message) {
            processMessage(message.textContent, node);
          }
        }
      });
    });
  });
  
  observer.observe(messageContainer, { childList: true, subtree: true });
}

// Process message to detect word game prompts
function processMessage(text, node) {
  // Check for the specific bot message pattern
  if (
    text.includes('Type a word containing') &&
    text.includes('**') &&
    node.querySelector('[class*="botTag"]')
  ) {
    // Extract bot ID from message
    const mention = node.querySelector('[class*="mention"]');
    const botId = mention ? mention.getAttribute('data-user-id') : null;

    // Only proceed if it's from the specific bot (432610292342587392)
    if (botId === '432610292342587392') {
      // Extract the sequence from bold text
      const boldText = node.querySelector('[class*="messageContent"] strong');
      if (boldText) {
        const sequence = boldText.textContent.trim();
        const messageId = node.getAttribute('data-id') || node.getAttribute('id');

        // Skip if we've already processed this message
        if (messageId === lastBotMessageId) return;
        lastBotMessageId = messageId;

        currentSequence = sequence;

        // Notify popup
        chrome.runtime.sendMessage({
          type: 'wordPrompt',
          sequence: sequence,
          botId: botId
        });

        // Generate a word and type it
        generateWord(sequence).then(word => {
          currentWord = word;
          chrome.runtime.sendMessage({
            type: 'wordGenerated',
            sequence: sequence,
            word: word
          });
          if (autoSendEnabled) {
            typeWord(word);
          }
        });
      }
    }
  }
}

// Generate a word containing the sequence
async function generateWord(sequence) {
  try {
    const response = await fetch(`https://api.datamuse.com/words?sp=*${sequence.toLowerCase()}*&max=100`, {
      method: 'GET',
      mode: 'cors'
    });
    const words = await response.json();
    
    if (words.length > 0) {
      // Filter for words that actually contain the sequence
      const validWords = words.filter(item => 
        item.word.toLowerCase().includes(sequence.toLowerCase())
      );
      
      if (validWords.length > 0) {
        // Select a random word from the top 10 results
        const randomIndex = Math.floor(Math.random() * Math.min(10, validWords.length));
        return validWords[randomIndex].word;
      }
    }
    
    // Fallback to local word list if API fails
    return getFallbackWord(sequence);
  } catch (error) {
    console.error('Fetch error:', error);
    return getFallbackWord(sequence);
  }
}

// Fallback word list
function getFallbackWord(sequence) {
  const words = {
    'IAR': ['familiar', 'liar', 'diary', 'briar', 'friar'],
    'TIO': ['nation', 'station', 'motion', 'portion', 'lotion'],
    'ERA': ['opera', 'camera', 'genera', 'chimera', 'bacteria'],
    'ENT': ['event', 'scent', 'rent', 'tent', 'cent'],
    'ING': ['king', 'ring', 'sing', 'wing', 'thing'],
    'TER': ['water', 'later', 'meter', 'cater', 'enter'],
    'ATE': ['late', 'date', 'gate', 'hate', 'rate'],
    'CON': ['icon', 'acon', 'scon', 'recon', 'beacon'],
    'COM': ['welcome', 'income', 'become', 'overcome', 'outcome'],
    'PRE': ['prepare', 'prevent', 'present', 'preview', 'preset']
  };
  
  const sequenceWords = words[sequence] || [
    'example', 'default', 'fallback', 'assistant', 'extension'
  ];
  
  return sequenceWords[Math.floor(Math.random() * sequenceWords.length)];
}

// Type the word in Discord's input
function typeWord(word) {
  const input = document.querySelector('[data-slate-editor="true"]');
  if (!input) return;
  
  // Focus the input
  input.focus();
  
  // Clear any existing content
  input.textContent = '';
  
  // Dispatch input event to trigger React state update
  const inputEvent = new Event('input', { bubbles: true });
  input.dispatchEvent(inputEvent);
  
  // Type the word character by character
  let index = 0;
  const typeInterval = setInterval(() => {
    if (index < word.length) {
      // Simulate key press for each character
      const char = word[index];
      input.textContent += char;
      
      // Dispatch input event
      input.dispatchEvent(inputEvent);
      
      index++;
    } else {
      clearInterval(typeInterval);
      
      // Wait a moment and press Enter to send
      setTimeout(() => {
        const enterEvent = new KeyboardEvent('keydown', {
          key: 'Enter',
          code: 'Enter',
          keyCode: 13,
          which: 13,
          bubbles: true
        });
        input.dispatchEvent(enterEvent);
      }, 100);
    }
  }, 50);
}

// Copy word to clipboard
function copyToClipboard(text) {
  const input = document.createElement('textarea');
  input.value = text;
  document.body.appendChild(input);
  input.select();
  document.execCommand('copy');
  document.body.removeChild(input);
}