document.addEventListener('DOMContentLoaded', () => {
  const statusIndicator = document.getElementById('statusIndicator');
  const statusText = document.getElementById('statusText');
  const sequenceElement = document.getElementById('sequence');
  const wordElement = document.getElementById('word');
  const newWordBtn = document.getElementById('newWordBtn');
  const copyBtn = document.getElementById('copyBtn');
  const wordHistory = document.getElementById('wordHistory');
  const autoSendCheckbox = document.getElementById('autoSend');
  const soundEnabledCheckbox = document.getElementById('soundEnabled');
  
  // Load settings from storage
  chrome.storage.sync.get(['autoSend', 'soundEnabled'], (result) => {
    autoSendCheckbox.checked = result.autoSend !== false;
    soundEnabledCheckbox.checked = result.soundEnabled !== false;
  });
  
  // Save settings when changed
  autoSendCheckbox.addEventListener('change', () => {
    chrome.storage.sync.set({ autoSend: autoSendCheckbox.checked });
  });
  
  soundEnabledCheckbox.addEventListener('change', () => {
    chrome.storage.sync.set({ soundEnabled: soundEnabledCheckbox.checked });
  });
  
  // Update status based on messages from content script
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'wordPrompt') {
      statusIndicator.classList.add('active');
      statusText.textContent = `Word prompt detected: ${message.sequence}`;
      sequenceElement.textContent = message.sequence;
      playSound('detected');
      
      // Debug output
      console.log('Detected word prompt from bot:', message.botId);
    }
    
    if (message.type === 'wordGenerated') {
      wordElement.textContent = message.word;
      addToHistory(message.sequence, message.word);
      playSound('generated');
    }
  });
  
  // Get initial state from content script
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, {type: 'getState'}, (response) => {
      if (response) {
        if (response.sequence) {
          statusIndicator.classList.add('active');
          statusText.textContent = `Word prompt detected: ${response.sequence}`;
          sequenceElement.textContent = response.sequence;
        }
        if (response.word) {
          wordElement.textContent = response.word;
        }
      }
    });
  });
  
  // New Word button
  newWordBtn.addEventListener('click', () => {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {type: 'generateNewWord'});
    });
  });
  
  // Copy button
  copyBtn.addEventListener('click', () => {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {type: 'copyWord'});
    });
  });
  
  // Add word to history
  function addToHistory(sequence, word) {
    const li = document.createElement('li');
    li.innerHTML = `<span class="history-sequence">${sequence}</span> 
                    <span class="history-word">${word}</span>`;
    wordHistory.insertBefore(li, wordHistory.firstChild);
    
    // Limit to 10 history items
    if (wordHistory.children.length > 10) {
      wordHistory.removeChild(wordHistory.lastChild);
    }
  }
  
  // Play notification sounds
  function playSound(type) {
    if (!soundEnabledCheckbox.checked) return;
    
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    if (type === 'detected') {
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(1760, audioContext.currentTime + 0.1);
    } else {
      oscillator.type = 'triangle';
      oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1);
    }
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
    
    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.3);
  }
});