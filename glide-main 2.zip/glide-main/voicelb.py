import discord
from discord.ext import commands, tasks
import json
import os
from datetime import datetime, timedelta

class VoiceLeaderboardCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.voice_stats_file = "voice_stats.json"
        self.voice_stats = self.load_voice_stats()
        self.leaderboard_message_file = "leaderboard_messages.json"
        self.leaderboard_messages = self.load_leaderboard_messages()
        self.update_leaderboard_loop.start()

    def load_voice_stats(self):
        if os.path.exists(self.voice_stats_file):
            try:
                with open(self.voice_stats_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def load_leaderboard_messages(self):
        if os.path.exists(self.leaderboard_message_file):
            try:
                with open(self.leaderboard_message_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_voice_stats(self):
        with open(self.voice_stats_file, 'w') as f:
            json.dump(self.voice_stats, f, indent=4)

    def save_leaderboard_messages(self):
        with open(self.leaderboard_message_file, 'w') as f:
            json.dump(self.leaderboard_messages, f, indent=4)

    def format_time(self, seconds):
        """Convert seconds to days, hours, minutes, seconds format"""
        days = seconds // (24 * 3600)
        seconds %= (24 * 3600)
        hours = seconds // 3600
        seconds %= 3600
        minutes = seconds // 60
        seconds %= 60
        
        parts = []
        if days > 0:
            parts.append(f"{days} day{'s' if days != 1 else ''}")
        if hours > 0:
            parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if minutes > 0:
            parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
        if seconds > 0 or not parts:
            parts.append(f"{seconds} second{'s' if seconds != 1 else ''}")
        
        return " ".join(parts)

    async def update_voice_stats(self, member, channel, joined):
        """Update voice statistics for a member"""
        guild_id = str(member.guild.id)
        user_id = str(member.id)
        
        if guild_id not in self.voice_stats:
            self.voice_stats[guild_id] = {}
        
        if user_id not in self.voice_stats[guild_id]:
            self.voice_stats[guild_id][user_id] = {
                "total_seconds": 0,
                "last_join": None,
                "display_name": member.display_name,
                "username": str(member)
            }
        
        if joined:
            # Member joined voice channel
            self.voice_stats[guild_id][user_id]["last_join"] = datetime.utcnow().isoformat()
        else:
            # Member left voice channel
            if self.voice_stats[guild_id][user_id]["last_join"]:
                join_time = datetime.fromisoformat(self.voice_stats[guild_id][user_id]["last_join"])
                time_in_channel = (datetime.utcnow() - join_time).total_seconds()
                self.voice_stats[guild_id][user_id]["total_seconds"] += time_in_channel
                self.voice_stats[guild_id][user_id]["last_join"] = None
        
        # Update display name and username
        self.voice_stats[guild_id][user_id]["display_name"] = member.display_name
        self.voice_stats[guild_id][user_id]["username"] = str(member)
        
        self.save_voice_stats()

    async def create_leaderboard_embed(self, guild):
        """Create the leaderboard embed for a guild"""
        guild_id = str(guild.id)
        
        if guild_id not in self.voice_stats or not self.voice_stats[guild_id]:
            return None
        
        # Calculate current time for users currently in voice channels
        current_time = datetime.utcnow()
        user_stats = []
        
        for user_id, stats in self.voice_stats[guild_id].items():
            total_seconds = stats["total_seconds"]
            
            # Add time for users currently in voice
            if stats["last_join"]:
                join_time = datetime.fromisoformat(stats["last_join"])
                total_seconds += (current_time - join_time).total_seconds()
            
            user_stats.append({
                "user_id": user_id,
                "display_name": stats["display_name"],
                "username": stats["username"],
                "total_seconds": total_seconds
            })
        
        # Sort by total time (descending)
        user_stats.sort(key=lambda x: x["total_seconds"], reverse=True)
        
        # Create embed
        embed = discord.Embed(
            title="🎤 Voice Leaderboard",
            color=discord.Color.from_rgb(255, 255, 255)  # White color
        )
        
        # Set author with server icon and name
        if guild.icon:
            embed.set_author(name=guild.name, icon_url=guild.icon.url)
        else:
            embed.set_author(name=guild.name)
        
        # Add leaderboard entries
        leaderboard_text = ""
        for i, stats in enumerate(user_stats[:15]):  # Top 15 users
            try:
                member = guild.get_member(int(stats["user_id"]))
                if member:
                    display_name = member.display_name
                    username = str(member)
                else:
                    display_name = stats["display_name"]
                    username = stats["username"]
                
                time_str = self.format_time(int(stats["total_seconds"]))
                leaderboard_text += f"**{i+1}. {display_name}** ({username}) - {time_str}\n"
            except:
                continue
        
        if not leaderboard_text:
            leaderboard_text = "No voice activity recorded yet."
        
        embed.description = leaderboard_text
        embed.set_footer(text="Updated in real-time • Tracked since bot startup")
        embed.timestamp = datetime.utcnow()
        
        return embed

    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def leaderboardvoice(self, ctx, channel: discord.TextChannel = None):
        """Create a voice leaderboard in the specified channel"""
        if not channel:
            channel = ctx.channel
        
        guild_id = str(ctx.guild.id)
        
        # Create initial leaderboard embed
        embed = await self.create_leaderboard_embed(ctx.guild)
        if not embed:
            embed = discord.Embed(
                title="🎤 Voice Leaderboard",
                description="No voice activity recorded yet. Join a voice channel to get tracked!",
                color=discord.Color.from_rgb(255, 255, 255)
            )
            if ctx.guild.icon:
                embed.set_author(name=ctx.guild.name, icon_url=ctx.guild.icon.url)
            else:
                embed.set_author(name=ctx.guild.name)
        
        # Send the leaderboard message
        message = await channel.send(embed=embed)
        
        # Store the message info for updates
        if guild_id not in self.leaderboard_messages:
            self.leaderboard_messages[guild_id] = {}
        
        self.leaderboard_messages[guild_id][str(message.id)] = {
            "channel_id": str(channel.id),
            "message_id": str(message.id)
        }
        
        self.save_leaderboard_messages()
        
        await ctx.send(f"✅ Voice leaderboard created in {channel.mention}")

    @tasks.loop(minutes=1.0)
    async def update_leaderboard_loop(self):
        """Update all leaderboard messages periodically"""
        for guild_id, messages in self.leaderboard_messages.items():
            guild = self.bot.get_guild(int(guild_id))
            if not guild:
                continue
            
            for message_info in messages.values():
                try:
                    channel = guild.get_channel(int(message_info["channel_id"]))
                    if not channel:
                        continue
                    
                    message = await channel.fetch_message(int(message_info["message_id"]))
                    embed = await self.create_leaderboard_embed(guild)
                    
                    if embed:
                        await message.edit(embed=embed)
                except:
                    # Message might have been deleted, remove from tracking
                    if guild_id in self.leaderboard_messages and message_info["message_id"] in self.leaderboard_messages[guild_id]:
                        del self.leaderboard_messages[guild_id][message_info["message_id"]]
                        self.save_leaderboard_messages()

    @update_leaderboard_loop.before_loop
    async def before_update_leaderboard(self):
        await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        """Track voice channel joins and leaves"""
        # Ignore bot users
        if member.bot:
            return
        
        # Member joined a voice channel
        if before.channel is None and after.channel is not None:
            await self.update_voice_stats(member, after.channel, True)
        
        # Member left a voice channel
        elif before.channel is not None and after.channel is None:
            await self.update_voice_stats(member, before.channel, False)
        
        # Member switched voice channels
        elif before.channel is not None and after.channel is not None and before.channel != after.channel:
            await self.update_voice_stats(member, before.channel, False)  # Left old channel
            await self.update_voice_stats(member, after.channel, True)    # Joined new channel

    @commands.command()
    async def voicetime(self, ctx, member: discord.Member = None):
        """Check your voice time statistics"""
        if not member:
            member = ctx.author
        
        guild_id = str(ctx.guild.id)
        user_id = str(member.id)
        
        if guild_id not in self.voice_stats or user_id not in self.voice_stats[guild_id]:
            await ctx.send(f"{member.mention} hasn't spent any time in voice channels yet.")
            return
        
        stats = self.voice_stats[guild_id][user_id]
        total_seconds = stats["total_seconds"]
        
        # Add current session time if user is in voice
        if stats["last_join"]:
            join_time = datetime.fromisoformat(stats["last_join"])
            total_seconds += (datetime.utcnow() - join_time).total_seconds()
        
        time_str = self.format_time(int(total_seconds))
        
        embed = discord.Embed(
            title="VC Stats",
            description=f"**{member.display_name}** has spent **{time_str}** in VC",
            color=discord.Color.from_rgb(255, 255, 255)
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        
        await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def clearvocestats(self, ctx):
        """Clear all voice statistics for this server"""
        guild_id = str(ctx.guild.id)
        
        if guild_id in self.voice_stats:
            del self.voice_stats[guild_id]
            self.save_voice_stats()
        
        if guild_id in self.leaderboard_messages:
            del self.leaderboard_messages[guild_id]
            self.save_leaderboard_messages()
        
        await ctx.send("✅ Voice statistics cleared for this server.")

async def setup(bot):
    await bot.add_cog(VoiceLeaderboardCog(bot))