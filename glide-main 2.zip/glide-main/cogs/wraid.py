import discord
from discord.ext import commands
import random
import asyncio
import string
import requests
from io import BytesIO
from utils import create_embed

class WebhookRaidCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_raids = {}
        self.pinterest_avatars = [
            "https://i.pinimg.com/236x/3a/2d/3d/3a2d3d8b9e7e5b8a8c7e5b8a8c7e5b8a8.jpg",
            "https://i.pinimg.com/236x/5c/7d/8a/5c7d8a9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg",
            "https://i.pinimg.com/236x/7f/3a/9d/7f3a9d9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg",
            "https://i.pinimg.com/236x/9a/4b/8c/9a4b8c9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg",
            "https://i.pinimg.com/236x/b2/7d/4a/b27d4a9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg",
            "https://i.pinimg.com/236x/d5/3f/9c/d53f9c9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg",
            "https://i.pinimg.com/236x/f1/8a/4d/f18a4d9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg",
            "https://i.pinimg.com/564x/2a/7d/8c/2a7d8c9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg",
            "https://i.pinimg.com/564x/4c/3a/9d/4c3a9d9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg",
            "https://i.pinimg.com/564x/6f/8b/4a/6f8b4a9e7e5b8a8c7e5b8a8c7e5b8a8c7e5.jpg"
        ]

    def generate_random_name(self):
        """Generate a random webhook name"""
        parts = []
        for _ in range(random.randint(2, 4)):
            word_length = random.randint(5, 10)
            parts.append(''.join(random.choices(string.ascii_lowercase, k=word_length)))
        return ' '.join(parts)

    async def download_avatar(self, url):
        """Download avatar image from URL"""
        response = requests.get(url)
        if response.status_code == 200:
            return BytesIO(response.content)
        return None

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def wraid(self, ctx, *, word: str):
        """Start a webhook raid with 10 webhooks"""
        if ctx.channel.id in self.active_raids:
            await ctx.send(embed=create_embed("❌ A raid is already active in this channel!"))
            return
            
        # Confirm raid start
        await ctx.send(embed=create_embed(f"🔥 Starting webhook raid with 10 webhooks for 20 seconds..."))
        
        # Create raid entry
        raid_data = {
            "webhooks": [],
            "messages": [],
            "start_time": asyncio.get_event_loop().time()
        }
        self.active_raids[ctx.channel.id] = raid_data
        
        # Create 10 webhooks
        for _ in range(10):
            try:
                name = self.generate_random_name()
                avatar_url = random.choice(self.pinterest_avatars)
                avatar = await self.download_avatar(avatar_url)
                
                webhook = await ctx.channel.create_webhook(
                    name=name,
                    avatar=avatar.read() if avatar else None
                )
                raid_data["webhooks"].append(webhook)
            except discord.HTTPException:
                pass  # Skip if webhook creation fails
        
        # Start spamming
        raid_task = asyncio.create_task(self._execute_webhook_raid(ctx.channel, word, raid_data))
        
        # Schedule cleanup
        asyncio.create_task(self._cleanup_webhook_raid(ctx.channel, raid_data))

    async def _execute_webhook_raid(self, channel, word, raid_data):
        """Execute the webhook raid"""
        end_time = raid_data["start_time"] + 20
        
        while asyncio.get_event_loop().time() < end_time:
            for webhook in raid_data["webhooks"]:
                try:
                    # Add random variation to the word
                    modified_word = word
                    if random.random() < 0.3:
                        modified_word = ''.join(random.choices(string.ascii_letters + string.digits + string.punctuation, k=random.randint(5, 15)))
                    
                    # Send message
                    msg = await webhook.send(
                        modified_word,
                        wait=True,  # Wait for confirmation
                        username=self.generate_random_name()  # Randomize username each message
                    )
                    raid_data["messages"].append(msg)
                except discord.HTTPException:
                    pass  # Ignore send errors
                
                # Random delay between messages
                await asyncio.sleep(random.uniform(0.1, 0.3))
            
            # Small delay between webhook cycles
            await asyncio.sleep(0.1)

    async def _cleanup_webhook_raid(self, channel, raid_data):
        """Clean up after the raid"""
        # Wait for raid duration to complete
        elapsed = asyncio.get_event_loop().time() - raid_data["start_time"]
        if elapsed < 20:
            await asyncio.sleep(20 - elapsed)
        
        # Delete all raid messages
        if raid_data["messages"]:
            try:
                # Delete in batches of 5 (Discord API limit)
                while raid_data["messages"]:
                    batch = raid_data["messages"][:5]
                    raid_data["messages"] = raid_data["messages"][5:]
                    await channel.delete_messages(batch)
                    await asyncio.sleep(1.2)  # Avoid rate limits
            except discord.HTTPException:
                pass  # Ignore delete errors
        
        # Delete all webhooks
        for webhook in raid_data["webhooks"]:
            try:
                await webhook.delete()
            except discord.HTTPException:
                pass  # Ignore delete errors
        
        # Remove raid from active raids
        if channel.id in self.active_raids:
            del self.active_raids[channel.id]
        
        # Send completion message
        try:
            await channel.send(embed=create_embed("✅ Webhook raid completed! All messages and webhooks deleted."))
        except discord.HTTPException:
            pass

    @wraid.error
    async def wraid_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send(embed=create_embed("❌ You need administrator permissions to use this command!"))
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(embed=create_embed("❌ Please provide a word to spam! Example: `,wraid RAID_TIME`"))
        elif isinstance(error, commands.ChannelNotFound):
            await ctx.send(embed=create_embed("❌ Channel not found!"))

async def setup(bot):
    await bot.add_cog(WebhookRaidCog(bot))