import discord
from discord.ext import commands
from datetime import datetime, timezone

class TimeoutCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="tolist")
    @commands.has_permissions(manage_messages=True)
    async def timeout_list(self, ctx):
        """List all timed out members in the server"""
        # Get current time in UTC
        now = datetime.now(timezone.utc)
        
        # Find timed out members
        timed_out_members = []
        for member in ctx.guild.members:
            # Check if member has an active timeout
            if member.is_timed_out() and member.communication_disabled_until > now:
                time_left = member.communication_disabled_until - now
                hours, remainder = divmod(time_left.seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                time_str = f"{hours}h {minutes}m {seconds}s"
                
                timed_out_members.append({
                    "member": member,
                    "until": member.communication_disabled_until,
                    "time_left": time_str
                })
        
        # Sort by timeout expiration time
        timed_out_members.sort(key=lambda x: x["until"])
        
        # Create embed
        embed = discord.Embed(
            title="⏱️ Timed Out Members",
            color=discord.Color.orange()
        )
        
        if not timed_out_members:
            embed.description = "No members are currently timed out."
            return await ctx.send(embed=embed)
        
        # Add members to embed
        for i, data in enumerate(timed_out_members, 1):
            member = data["member"]
            embed.add_field(
                name=f"{i}. {member.display_name}",
                value=f"ID: {member.id}\n"
                      f"Time left: {data['time_left']}\n"
                      f"Until: {data['until'].strftime('%Y-%m-%d %H:%M:%S UTC')}",
                inline=False
            )
        
        embed.set_footer(text=f"Total timed out: {len(timed_out_members)}")
        await ctx.send(embed=embed)

    @commands.command(name="utoall")
    @commands.has_permissions(manage_messages=True)
    async def untimeout_all(self, ctx):
        """Remove timeout from all members in the server"""
        # Get current time
        now = datetime.now(timezone.utc)
        
        # Find and untimeout members
        untimeout_count = 0
        for member in ctx.guild.members:
            if member.is_timed_out() and member.communication_disabled_until > now:
                try:
                    await member.edit(timed_out_until=None)
                    untimeout_count += 1
                except discord.Forbidden:
                    continue
                except discord.HTTPException:
                    continue
        
        # Create confirmation embed
        embed = discord.Embed(
            title="⏱️ Timeouts Removed",
            description=f"Removed timeouts from **{untimeout_count}** members",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @timeout_list.error
    @untimeout_all.error
    async def timeout_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            embed = discord.Embed(
                title="Permission Denied",
                description="You need the `Manage Messages` permission to use this command.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(TimeoutCog(bot))