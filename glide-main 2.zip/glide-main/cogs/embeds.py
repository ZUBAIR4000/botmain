import discord
from discord.ext import commands
import json
import os
import base64
import zlib
from datetime import datetime
import re

class EmbedCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.embed_file = "embed_configs.json"
        self.embed_configs = self.load_embed_configs()

    def load_embed_configs(self):
        if os.path.exists(self.embed_file):
            try:
                with open(self.embed_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_embed_configs(self):
        with open(self.embed_file, 'w') as f:
            json.dump(self.embed_configs, f, indent=4)

    def get_default_embed_config(self):
        """Return default embed configuration"""
        return {
            'title': '{null}',
            'description': 'This is a sample embed description.',
            'color': 0x1DB954,
            'author_name': '{user.display_name}',
            'author_icon': '{user.avatar}',
            'author_url': '{null}',
            'thumbnail': '{null}',
            'image': '{null}',
            'footer': 'Embed created with {bot.name}',
            'footer_icon': '{bot.avatar}',
            'timestamp': False,
            'buttons': []
        }

    def replace_variables(self, text, ctx):
        """Replace variables in text with actual values"""
        if text == "{null}":
            return None
        
        # Guild variables
        if ctx.guild:
            text = text.replace('{guild.name}', ctx.guild.name)
            text = text.replace('{guild.id}', str(ctx.guild.id))
            text = text.replace('{guild.count}', str(ctx.guild.member_count))
            # Removed {guild.region} as it no longer exists
            text = text.replace('{guild.owner_id}', str(ctx.guild.owner_id))
            text = text.replace('{guild.created_at}', str(ctx.guild.created_at))
            text = text.replace('{guild.created_at_timestamp}', str(int(ctx.guild.created_at.timestamp())))
            text = text.replace('{guild.emoji_count}', str(len(ctx.guild.emojis)))
            text = text.replace('{guild.role_count}', str(len(ctx.guild.roles)))
            text = text.replace('{guild.boost_count}', str(ctx.guild.premium_subscription_count))
            text = text.replace('{guild.boost_tier}', str(ctx.guild.premium_tier))
            text = text.replace('{guild.preferred_locale}', str(ctx.guild.preferred_locale))
            text = text.replace('{guild.icon}', str(ctx.guild.icon.url) if ctx.guild.icon else 'N/A')
            text = text.replace('{guild.banner}', str(ctx.guild.banner.url) if ctx.guild.banner else 'N/A')
            text = text.replace('{guild.splash}', str(ctx.guild.splash.url) if ctx.guild.splash else 'N/A')
            text = text.replace('{guild.vanity}', ctx.guild.vanity_url_code if ctx.guild.vanity_url_code else 'N/A')
            text = text.replace('{guild.channels_count}', str(len(ctx.guild.channels)))
            text = text.replace('{guild.text_channels_count}', str(len(ctx.guild.text_channels)))
            text = text.replace('{guild.voice_channels_count}', str(len(ctx.guild.voice_channels)))
            text = text.replace('{guild.category_channels_count}', str(len(ctx.guild.categories)))
        
        # User variables
        text = text.replace('{user}', f"{ctx.author.name}#{ctx.author.discriminator}")
        text = text.replace('{user.id}', str(ctx.author.id))
        text = text.replace('{user.mention}', ctx.author.mention)
        text = text.replace('{user.name}', ctx.author.name)
        text = text.replace('{user.tag}', ctx.author.discriminator)
        text = text.replace('{user.avatar}', str(ctx.author.avatar.url) if ctx.author.avatar else str(ctx.author.default_avatar.url))
        text = text.replace('{user.display_avatar}', str(ctx.author.display_avatar.url))
        text = text.replace('{user.joined_at}', str(ctx.author.joined_at) if ctx.author.joined_at else 'N/A')
        text = text.replace('{user.joined_at_timestamp}', str(int(ctx.author.joined_at.timestamp())) if ctx.author.joined_at else 'N/A')
        text = text.replace('{user.created_at}', str(ctx.author.created_at))
        text = text.replace('{user.created_at_timestamp}', str(int(ctx.author.created_at.timestamp())))
        text = text.replace('{user.display_name}', ctx.author.display_name)
        text = text.replace('{user.color}', str(ctx.author.color) if ctx.author.color else 'N/A')
        text = text.replace('{user.bot}', 'Yes' if ctx.author.bot else 'No')
        
        # Channel variables
        text = text.replace('{channel.name}', ctx.channel.name)
        text = text.replace('{channel.id}', str(ctx.channel.id))
        text = text.replace('{channel.mention}', ctx.channel.mention)
        text = text.replace('{channel.topic}', ctx.channel.topic if hasattr(ctx.channel, 'topic') and ctx.channel.topic else 'N/A')
        text = text.replace('{channel.type}', str(ctx.channel.type))
        text = text.replace('{channel.position}', str(ctx.channel.position))
        
        # Date and time variables
        now = datetime.now()
        utc_now = datetime.utcnow()
        text = text.replace('{date.now}', now.strftime('%Y-%m-%d'))
        text = text.replace('{date.utc_timestamp}', str(int(utc_now.timestamp())))
        text = text.replace('{date.now_proper}', now.strftime('%B %d, %Y'))
        text = text.replace('{date.now_short}', now.strftime('%b %d, %Y'))
        text = text.replace('{date.now_shorter}', now.strftime('%m/%d/%Y'))
        text = text.replace('{time.now}', now.strftime('%I:%M %p'))
        text = text.replace('{time.now_military}', now.strftime('%H:%M'))
        text = text.replace('{date.utc_now}', utc_now.strftime('%Y-%m-%d'))
        text = text.replace('{date.utc_now_proper}', utc_now.strftime('%B %d, %Y'))
        text = text.replace('{date.utc_now_short}', utc_now.strftime('%b %d, %Y'))
        text = text.replace('{date.utc_now_shorter}', utc_now.strftime('%m/%d/%Y'))
        text = text.replace('{time.utc_now}', utc_now.strftime('%I:%M %p'))
        text = text.replace('{time.utc_now_military}', utc_now.strftime('%H:%M'))
        
        # Bot variables
        text = text.replace('{bot.name}', self.bot.user.name)
        text = text.replace('{bot.avatar}', str(self.bot.user.avatar.url) if self.bot.user.avatar else str(self.bot.user.default_avatar.url))
        text = text.replace('{bot.id}', str(self.bot.user.id))
        
        return text

    async def create_embed(self, ctx, config=None):
        """Create and send an embed based on configuration"""
        if config is None:
            user_id = str(ctx.author.id)
            config = self.embed_configs.get(user_id, self.get_default_embed_config())
        
        # Replace variables in the config
        title = self.replace_variables(config.get('title', '{null}'), ctx)
        description = self.replace_variables(config.get('description', ''), ctx)
        color = config.get('color', 0x1DB954)
        author_name = self.replace_variables(config.get('author_name', '{null}'), ctx)
        author_icon = self.replace_variables(config.get('author_icon', '{null}'), ctx)
        author_url = self.replace_variables(config.get('author_url', '{null}'), ctx)
        thumbnail = self.replace_variables(config.get('thumbnail', '{null}'), ctx)
        image = self.replace_variables(config.get('image', '{null}'), ctx)
        footer = self.replace_variables(config.get('footer', '{null}'), ctx)
        footer_icon = self.replace_variables(config.get('footer_icon', '{null}'), ctx)
        timestamp = config.get('timestamp', False)
        
        # Create embed
        embed = discord.Embed(color=color)
        
        if title and title != '{null}':
            embed.title = title
        
        if description and description != '{null}':
            embed.description = description
        
        # Set author
        if author_name and author_name != '{null}':
            if author_icon and author_icon != '{null}' and author_url and author_url != '{null}':
                embed.set_author(name=author_name, icon_url=author_icon, url=author_url)
            elif author_icon and author_icon != '{null}':
                embed.set_author(name=author_name, icon_url=author_icon)
            elif author_url and author_url != '{null}':
                embed.set_author(name=author_name, url=author_url)
            else:
                embed.set_author(name=author_name)
        
        # Set thumbnail
        if thumbnail and thumbnail != '{null}':
            embed.set_thumbnail(url=thumbnail)
        
        # Set image
        if image and image != '{null}':
            embed.set_image(url=image)
        
        # Set footer
        if footer and footer != '{null}':
            if footer_icon and footer_icon != '{null}':
                embed.set_footer(text=footer, icon_url=footer_icon)
            else:
                embed.set_footer(text=footer)
        
        # Set timestamp
        if timestamp:
            embed.timestamp = datetime.utcnow()
        
        # Create view with buttons
        view = discord.ui.View()
        buttons = config.get('buttons', [])
        
        for button in buttons:
            button_label = self.replace_variables(button.get('label', 'Button'), ctx)
            button_url = self.replace_variables(button.get('url', ''), ctx)
            button_emoji = button.get('emoji', None)
            button_style = button.get('style', 'secondary')
            
            if button_url:
                style_map = {
                    'primary': discord.ButtonStyle.primary,
                    'secondary': discord.ButtonStyle.secondary,
                    'success': discord.ButtonStyle.success,
                    'danger': discord.ButtonStyle.danger,
                    'link': discord.ButtonStyle.link
                }
                
                button_style = style_map.get(button_style, discord.ButtonStyle.secondary)
                
                discord_button = discord.ui.Button(
                    label=button_label,
                    url=button_url,
                    style=button_style,
                    emoji=button_emoji
                )
                view.add_item(discord_button)
        
        return embed, view

    @commands.command(aliases=['ce'])
    @commands.has_permissions(manage_messages=True)
    async def createembed(self, ctx, *, code: str = None):
        """Create or load an embed configuration"""
        user_id = str(ctx.author.id)

        try:
            if code:
                # Load from code
                try:
                    # Decode and decompress
                    decoded = base64.urlsafe_b64decode(code.encode())
                    decompressed = zlib.decompress(decoded)
                    config = json.loads(decompressed.decode())

                    # Update settings
                    if user_id not in self.embed_configs:
                        self.embed_configs[user_id] = self.get_default_embed_config()

                    self.embed_configs[user_id].update(config)
                    self.save_embed_configs()

                    await ctx.send("Embed configuration loaded successfully!")
                except Exception as e:
                    await ctx.send(f"Invalid embed code! Error: {e}")
                    return
            else:
                # Initialize with default config if not exists
                if user_id not in self.embed_configs:
                    self.embed_configs[user_id] = self.get_default_embed_config()
                    self.save_embed_configs()

            # Send the embed
            embed, view = await self.create_embed(ctx)
            if embed:
                await ctx.send(embed=embed, view=view)
            else:
                await ctx.send("Failed to create the embed. Please check your configuration.")
        except Exception as e:
            await ctx.send(f"An error occurred while creating the embed: {e}")

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedauthor(self, ctx, *, icon_url: str):
        """Set author icon for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['author_icon'] = icon_url
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedauthorname(self, ctx, *, name: str):
        """Set author name for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['author_name'] = name
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedauthorurl(self, ctx, *, url: str):
        """Set author URL for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['author_url'] = url
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedthumbnail(self, ctx, *, thumbnail_url: str):
        """Set thumbnail for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['thumbnail'] = thumbnail_url
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embeddescription(self, ctx, *, description: str):
        """Set description for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['description'] = description
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedfooter(self, ctx, *, footer: str):
        """Set footer for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['footer'] = footer
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedfootericon(self, ctx, *, icon_url: str):
        """Set footer icon for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['footer_icon'] = icon_url
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedimage(self, ctx, *, image_url: str):
        """Set image for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['image'] = image_url
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedtitle(self, ctx, *, title: str):
        """Set title for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        self.embed_configs[user_id]['title'] = title
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedcolor(self, ctx, color: str):
        """Set color for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        try:
            if color.startswith('#'):
                color_int = int(color[1:], 16)
            else:
                color_int = getattr(discord.Color, color.lower())().value
        except:
            return await ctx.send("Invalid color! Use hex (#FF0000) or color name (red)")
        
        self.embed_configs[user_id]['color'] = color_int
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedtimestamp(self, ctx, enabled: bool = None):
        """Toggle timestamp for embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        if enabled is None:
            # Toggle current value
            current = self.embed_configs[user_id].get('timestamp', False)
            self.embed_configs[user_id]['timestamp'] = not current
        else:
            self.embed_configs[user_id]['timestamp'] = enabled
        
        self.save_embed_configs()
        
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedbutton(self, ctx, action: str, *args):
        """Add or remove buttons from embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            self.embed_configs[user_id] = self.get_default_embed_config()
        
        if action.lower() == 'add':
            if len(args) < 2:
                return await ctx.send("Usage: `,embedbutton add <name> <type> <url> [emoji]`")
            
            name = args[0]
            button_type = args[1].lower()
            url = args[2] if len(args) > 2 else ''
            emoji = args[3] if len(args) > 3 else None
            
            if button_type not in ['primary', 'secondary', 'success', 'danger', 'link']:
                return await ctx.send("Button type must be: primary, secondary, success, danger, or link")
            
            # Add button
            buttons = self.embed_configs[user_id].get('buttons', [])
            buttons.append({
                'label': name,
                'style': button_type,
                'url': url,
                'emoji': emoji
            })
            self.embed_configs[user_id]['buttons'] = buttons
            self.save_embed_configs()
            
            await ctx.send(f"Button '{name}' added!")
            
        elif action.lower() == 'remove':
            if not args:
                return await ctx.send("Usage: `,embedbutton remove <name>`")
            
            name = ' '.join(args)
            buttons = self.embed_configs[user_id].get('buttons', [])
            
            # Remove button
            new_buttons = [btn for btn in buttons if btn.get('label') != name]
            
            if len(new_buttons) == len(buttons):
                return await ctx.send(f"No button named '{name}' found!")
            
            self.embed_configs[user_id]['buttons'] = new_buttons
            self.save_embed_configs()
            
            await ctx.send(f"Button '{name}' removed!")
            
        else:
            return await ctx.send("Usage: `,embedbutton add|remove <arguments>`")
        
        # Show updated embed
        embed, view = await self.create_embed(ctx)
        await ctx.send("Embed updated!", embed=embed, view=view)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embedcode(self, ctx):
        """Generate a shareable code for your embed configuration"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.embed_configs:
            return await ctx.send("You don't have an embed configuration! Use `,ce` to create one first.")
        
        # Convert to JSON and compress
        config = self.embed_configs[user_id].copy()
        config_json = json.dumps(config)
        compressed = zlib.compress(config_json.encode())
        encoded = base64.urlsafe_b64encode(compressed).decode()
        
        await ctx.send(f"Your embed code:\n```{encoded}```\nUse `,ce {encoded}` to load this configuration.")

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def variables(self, ctx):
        """Show all available variables"""
        variables_text = """
**Available Variables:**

**Guild Variables:**
- `{guild.name}` - The guild's name
- `{guild.id}` - The guild's ID
- `{guild.count}` - The guild's member count
- `{guild.region}` - The guild's voice region
- `{guild.owner_id}` - The guild's owner ID
- `{guild.created_at}` - The guild's creation date in UTC
- `{guild.created_at_timestamp}` - The guild's creation date in UNIX
- `{guild.emoji_count}` - The guild's emoji count
- `{guild.role_count}` - The guild's role count
- `{guild.boost_count}` - The guild's boost count
- `{guild.boost_tier}` - The guild's boost tier
- `{guild.preferred_locale}` - The guild's preferred locale
- `{guild.icon}` - The guild's icon URL
- `{guild.banner}` - The guild's banner URL
- `{guild.splash}` - The guild's splash URL
- `{guild.vanity}` - The guild's custom vanity URL
- `{guild.channels_count}` - The guild's total channel count
- `{guild.text_channels_count}` - The guild's text channel count
- `{guild.voice_channels_count}` - The guild's voice channel count
- `{guild.category_channels_count}` - The guild's category channel count

**User Variables:**
- `{user}` - The user's name and discriminator
- `{user.id}` - The user's ID
- `{user.mention}` - The user's mention
- `{user.name}` - The user's name
- `{user.tag}` - The user's discriminator
- `{user.avatar}` - The user's profile picture
- `{user.display_avatar}` - The user's available profile picture
- `{user.joined_at}` - The user's guild join date in UTC
- `{user.joined_at_timestamp}` - The user's guild join date in UNIX
- `{user.created_at}` - The user's account creation date in UTC
- `{user.created_at_timestamp}` - The user's account creation date in UNIX
- `{user.display_name}` - The user's current display name
- `{user.color}` - The user's top role hex code
- `{user.bot}` - Yes/No if the user is a bot

**Channel Variables:**
- `{channel.name}` - The channel's name
- `{channel.id}` - The channel's ID
- `{channel.mention}` - The channel's mention
- `{channel.topic}` - The channel's topic
- `{channel.type}` - The channel's type
- `{channel.position}` - The channel's position

**Date and Time Variables:**
- `{date.now}` - Current date in PST
- `{date.utc_timestamp}` - Current date as UNIX
- `{date.now_proper}` - Better formatted date in PST
- `{date.now_short}` - Short formatted date in PST
- `{date.now_shorter}` - Shorter formatted date in PST
- `{time.now}` - 12 hour timestamp in PST
- `{time.now_military}` - 24 hour timestamp in PST
- `{date.utc_now}` - Current date in UTC
- `{date.utc_now_proper}` - Better formatted date in UTC
- `{date.utc_now_short}` - Short formatted date in UTC
- `{date.utc_now_shorter}` - Shorter formatted date in UTC
- `{time.utc_now}` - 12 hour timestamp in UTC
- `{time.utc_now_military}` - 24 hour timestamp in UTC

**Bot Variables:**
- `{bot.name}` - Bot's name
- `{bot.avatar}` - Bot's avatar URL
- `{bot.id}` - Bot's ID

**Special Variables:**
- `{null}` - Removes the field from the embed

Use these variables in your embed customization commands!
        """
        
        # Split into multiple messages if too long
        if len(variables_text) > 2000:
            parts = [variables_text[i:i+2000] for i in range(0, len(variables_text), 2000)]
            for part in parts:
                await ctx.send(part)
        else:
            await ctx.send(variables_text)

async def setup(bot):
    await bot.add_cog(EmbedCog(bot))