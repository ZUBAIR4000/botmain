import discord
from discord.ext import commands
import aiohttp
import random

class porn(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="porn")
    async def porn_command(self, ctx, *, query: str = ""):
        # 1️⃣ NSFW channel check
        if not ctx.channel.is_nsfw():
            emoji = discord.utils.get(self.bot.emojis, name="error")
            emoji_display = f"{emoji} |" if emoji else ":x: |"
            embed = discord.Embed(
                description=f"{emoji_display} This command can only be run in **NSFW** Channels.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        # 2️⃣ Prepare Danbooru tags (lowercase, spaces → underscores)
        tags = "_".join(query.lower().split()) if query else "hentai_animated"
        url = f"https://danbooru.donmai.us/posts.json?tags={tags}+rating:explicit&limit=100"

        try:
            # 3️⃣ Try Danbooru
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        posts = data  # array of post objects
                    else:
                        posts = []
        except aiohttp.ClientConnectorError:
            posts = []

        # 4️⃣ Filter for only animated media
        valid = [
            post for post in posts
            if post.get("file_url", "").endswith((".webm", ".mp4", ".gif"))
        ]

        # 5️⃣ If Danbooru failed or no animated posts, fallback to NekoBot
        if not valid:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get("https://nekobot.xyz/api/image?type=pgif") as fb:
                        fb_data = await fb.json()
                        file_url = fb_data.get("message")
                        if file_url:
                            await ctx.send(f"**NSFW 🔞**\n\n\n[Source]({file_url})")
                            return
            except Exception:
                # final failure
                await ctx.send("❌ Could not connect to any  source. Please try again later.")
                return

        # 6️⃣ Send a random Danbooru animated post
        chosen = random.choice(valid)
        file_url = chosen.get("file_url")
        await ctx.send(f"**Source**\n[Source]({file_url})")

async def setup(bot):
    await bot.add_cog(porn(bot))