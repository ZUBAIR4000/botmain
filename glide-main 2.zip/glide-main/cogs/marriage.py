import discord
from discord.ext import commands
import json
import os
from datetime import datetime
import aiohttp
import io
from PIL import Image, ImageDraw, ImageFont
import math
import asyncio

class MarriageCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.marriage_file = "marriages.json"
        self.adoption_file = "adoptions.json"
        self.marriages = self.load_data(self.marriage_file)
        self.adoptions = self.load_data(self.adoption_file)
        self.pending_proposals = {}

    def load_data(self, filename):
        """Load data from JSON file"""
        if os.path.exists(filename):
            try:
                with open(filename, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_data(self, filename, data):
        """Save data to JSON file"""
        with open(filename, 'w') as f:
            json.dump(data, f, indent=4)

    def get_marriage(self, user_id):
        """Get marriage data for a user"""
        user_id = str(user_id)
        for marriage in self.marriages.values():
            if user_id in [marriage['user1'], marriage['user2']]:
                return marriage
        return None

    def is_married(self, user_id):
        """Check if a user is married"""
        return self.get_marriage(user_id) is not None

    def get_adopted_children(self, user_id):
        """Get adopted children for a user"""
        user_id = str(user_id)
        return [child for child, parents in self.adoptions.items() if user_id in parents]

    def get_adoptive_parents(self, user_id):
        """Get adoptive parents for a user"""
        user_id = str(user_id)
        return self.adoptions.get(user_id, [])

    def can_adopt(self, user_id):
        """Check if a user can adopt more children"""
        return len(self.get_adopted_children(user_id)) < 10

    def is_adopted(self, user_id):
        """Check if a user is adopted"""
        return str(user_id) in self.adoptions

    @commands.command()
    async def marry(self, ctx, member: discord.Member):
        """Propose marriage to another user"""
        # Check if proposer is already married
        if self.is_married(ctx.author.id):
            marriage = self.get_marriage(ctx.author.id)
            partner_id = marriage['user2'] if marriage['user1'] == str(ctx.author.id) else marriage['user1']
            partner = self.bot.get_user(int(partner_id))
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You are already married! Use `,divorce` first.")

        # Check if target is already married
        if self.is_married(member.id):
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: This user is already married!")

        # Check if target is the same as proposer
        if ctx.author.id == member.id:
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You can't marry yourself!")

        # Check if target is a bot
        if member.bot:
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You can't marry a bot!")

        # Create proposal embed
        embed = discord.Embed(
            title="💍 Marriage Proposal",
            description=f"{ctx.author.mention} has proposed to {member.mention}!\n\nDo you accept this proposal?",
            color=0xff66cc
        )
        embed.set_thumbnail(url=ctx.author.display_avatar.url)
        embed.set_footer(text="You have 2 minutes to respond")

        # Create buttons
        view = discord.ui.View(timeout=120)
        
        async def accept_callback(interaction):
            if interaction.user.id != member.id:
                await interaction.response.send_message("This proposal is not for you!", ephemeral=True)
                return
            
            # Create marriage
            marriage_id = f"{min(ctx.author.id, member.id)}_{max(ctx.author.id, member.id)}"
            self.marriages[marriage_id] = {
                'user1': str(ctx.author.id),
                'user2': str(member.id),
                'user1_name': str(ctx.author),
                'user2_name': str(member),
                'married_at': datetime.utcnow().isoformat()
            }
            self.save_data(self.marriage_file, self.marriages)
            
            # Send success message
            success_embed = discord.Embed(
                description=f"💖 {ctx.author.mention} and {member.mention} are now married! 💕",
                color=0xff66cc
            )
            await interaction.response.edit_message(embed=success_embed, view=None)
            
            # Delete pending proposal
            if ctx.author.id in self.pending_proposals:
                del self.pending_proposals[ctx.author.id]

        async def decline_callback(interaction):
            if interaction.user.id != member.id:
                await interaction.response.send_message("This proposal is not for you!", ephemeral=True)
                return
            
            # Send decline message
            decline_embed = discord.Embed(
                description=f"💔 {member.mention} has declined the marriage proposal.",
                color=0xff0000
            )
            await interaction.response.edit_message(embed=decline_embed, view=None)
            
            # Delete pending proposal
            if ctx.author.id in self.pending_proposals:
                del self.pending_proposals[ctx.author.id]

        # Add buttons
        accept_button = discord.ui.Button(style=discord.ButtonStyle.success, label="Accept", emoji="✅")
        decline_button = discord.ui.Button(style=discord.ButtonStyle.danger, label="Decline", emoji="❌")
        
        accept_button.callback = accept_callback
        decline_button.callback = decline_callback
        
        view.add_item(accept_button)
        view.add_item(decline_button)

        # Store proposal
        self.pending_proposals[ctx.author.id] = member.id
        
        # Send proposal
        await ctx.send(f"{member.mention}", embed=embed, view=view)

    @commands.command()
    async def divorce(self, ctx):
        """Divorce your current partner"""
        # Check if user is married
        marriage = self.get_marriage(ctx.author.id)
        if not marriage:
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You're not married!")
        
        # Get partner info
        partner_id = marriage['user2'] if marriage['user1'] == str(ctx.author.id) else marriage['user1']
        partner = self.bot.get_user(int(partner_id))
        partner_name = partner.display_name if partner else marriage['user1_name' if marriage['user2'] == str(ctx.author.id) else 'user2_name']
        
        # Create divorce confirmation embed
        embed = discord.Embed(
            title="💔 Divorce Confirmation",
            description=f"Are you sure you want to divorce {partner_name}?",
            color=0xff0000
        )
        embed.set_footer(text="This action cannot be undone!")

        # Create buttons
        view = discord.ui.View(timeout=60)
        
        async def confirm_callback(interaction):
            if interaction.user.id != ctx.author.id:
                await interaction.response.send_message("This confirmation is not for you!", ephemeral=True)
                return
            
            # Find and remove marriage
            marriage_id = None
            for mid, m in self.marriages.items():
                if str(ctx.author.id) in [m['user1'], m['user2']]:
                    marriage_id = mid
                    break
            
            if marriage_id:
                del self.marriages[marriage_id]
                self.save_data(self.marriage_file, self.marriages)
                
                # Send success message
                success_embed = discord.Embed(
                    description=f"💔 You are now divorced from {partner_name}.",
                    color=0xff0000
                )
                await interaction.response.edit_message(embed=success_embed, view=None)
            else:
                await interaction.response.edit_message(content=f"<:warning:1365257382619250719> {ctx.author.mention}: Marriage not found!", embed=None, view=None)

        async def cancel_callback(interaction):
            if interaction.user.id != ctx.author.id:
                await interaction.response.send_message("This confirmation is not for you!", ephemeral=True)
                return
            
            cancel_embed = discord.Embed(
                description="💖 Your marriage remains intact!",
                color=0x00ff00
            )
            await interaction.response.edit_message(embed=cancel_embed, view=None)

        # Add buttons
        confirm_button = discord.ui.Button(style=discord.ButtonStyle.danger, label="Confirm Divorce", emoji="💔")
        cancel_button = discord.ui.Button(style=discord.ButtonStyle.secondary, label="Cancel", emoji="❤️")
        
        confirm_button.callback = confirm_callback
        cancel_button.callback = cancel_callback
        
        view.add_item(confirm_button)
        view.add_item(cancel_button)

        await ctx.send(embed=embed, view=view)

    @commands.command()
    async def marriage(self, ctx, user: discord.Member = None):
        """Check marriage status"""
        target = user or ctx.author
        
        # Check if user is married
        marriage = self.get_marriage(target.id)
        if not marriage:
            if target == ctx.author:
                return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You're not married!")
            else:
                return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: {target.display_name} is not married!")
        
        # Get partner info
        partner_id = marriage['user2'] if marriage['user1'] == str(target.id) else marriage['user1']
        partner = self.bot.get_user(int(partner_id))
        partner_name = partner.display_name if partner else marriage['user1_name' if marriage['user2'] == str(target.id) else 'user2_name']
        
        # Calculate marriage duration
        married_at = datetime.fromisoformat(marriage['married_at'])
        duration = datetime.utcnow() - married_at
        days = duration.days
        hours = duration.seconds // 3600
        
        # Create marriage display embed
        embed = discord.Embed(
            title=f"💖 {target.display_name} is happily married to {partner_name} 💖",
            color=0xff66cc
        )
        
        # Set background image
        embed.set_image(url="https://media.discordapp.net/attachments/1361730745973866496/1409589462693969940/hODMie6.png?ex=68adedfc&is=68ac9c7c&hm=dd687229452a2a254ed48d9c0c9b595e2084b0634e3500851ae2b506d903fadf&=&width=1756&height=1080")
        
        # Add marriage info
        embed.add_field(name="Married Since", value=f"<t:{int(married_at.timestamp())}:D>", inline=True)
        embed.add_field(name="Duration", value=f"{days} days, {hours} hours", inline=True)
        embed.add_field(name="Partner", value=partner.mention if partner else partner_name, inline=True)
        
        # Set thumbnail with both profile pictures
        embed.set_thumbnail(url="https://media.discordapp.net/attachments/1361730745973866496/1409590279215779926/pinkhearts.png?ex=68adeebf&is=68ac9d3f&hm=7473ac381498c1184401ed42252ef207dd6fb1fbf6c65aace8a3b5a5c193559e&=&width=256&height=256")
        
        # Add both profile pictures as author icons
        embed.set_author(name=f"{target.display_name} 💞 {partner_name}", 
                        icon_url=target.display_avatar.url)
        
        await ctx.send(embed=embed)

    @commands.command()
    async def adopt(self, ctx, member: discord.Member):
        """Adopt a user (must be married)"""
        # Check if adopter is married
        if not self.is_married(ctx.author.id):
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You must be married to adopt someone!")
        
        # Check if target is already adopted
        if self.is_adopted(member.id):
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: This user is already adopted by another family!")
        
        # Check if adopter can adopt more children
        if not self.can_adopt(ctx.author.id):
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You can only adopt up to 10 children!")
        
        # Check if target is the adopter or spouse
        marriage = self.get_marriage(ctx.author.id)
        spouse_id = marriage['user2'] if marriage['user1'] == str(ctx.author.id) else marriage['user1']
        if member.id == ctx.author.id or member.id == int(spouse_id):
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You can't adopt yourself or your spouse!")
        
        # Check if target is a bot
        if member.bot:
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You can't adopt a bot!")
        
        # Get spouse
        spouse = self.bot.get_user(int(spouse_id))
        
        # Create adoption confirmation embed
        embed = discord.Embed(
            title="👨‍👩‍👧‍👦 Adoption Proposal",
            description=f"{ctx.author.mention} and {spouse.mention if spouse else 'your spouse'} want to adopt {member.mention}!\n\nDo you accept this adoption?",
            color=0x00ff00
        )
        embed.set_footer(text="You have 2 minutes to respond")

        # Create buttons
        view = discord.ui.View(timeout=120)
        
        async def accept_callback(interaction):
            if interaction.user.id != member.id:
                await interaction.response.send_message("This adoption is not for you!", ephemeral=True)
                return
            
            # Create adoption
            self.adoptions[str(member.id)] = [str(ctx.author.id), spouse_id]
            self.save_data(self.adoption_file, self.adoptions)
            
            # Send success message
            success_embed = discord.Embed(
                description=f"👨‍👩‍👧‍👦 {member.mention} has been adopted by {ctx.author.mention} and {spouse.mention if spouse else 'their spouse'}!",
                color=0x00ff00
            )
            await interaction.response.edit_message(embed=success_embed, view=None)

        async def decline_callback(interaction):
            if interaction.user.id != member.id:
                await interaction.response.send_message("This adoption is not for you!", ephemeral=True)
                return
            
            # Send decline message
            decline_embed = discord.Embed(
                description=f"❌ {member.mention} has declined the adoption.",
                color=0xff0000
            )
            await interaction.response.edit_message(embed=decline_embed, view=None)

        # Add buttons
        accept_button = discord.ui.Button(style=discord.ButtonStyle.success, label="Accept", emoji="✅")
        decline_button = discord.ui.Button(style=discord.ButtonStyle.danger, label="Decline", emoji="❌")
        
        accept_button.callback = accept_callback
        decline_button.callback = decline_callback
        
        view.add_item(accept_button)
        view.add_item(decline_button)

        await ctx.send(f"{member.mention}", embed=embed, view=view)

    @commands.command()
    async def disown(self, ctx):
        """Disown an adopted child"""
        # Check if user has any children
        children = self.get_adopted_children(ctx.author.id)
        if not children:
            return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You don't have any children yet! Use `,adopt @user`")
        
        # Create dropdown menu
        options = []
        for child_id in children:
            child = self.bot.get_user(int(child_id))
            if child:
                options.append(discord.SelectOption(
                    label=child.display_name[:100],
                    description=f"Adopted child"[:100],
                    value=child_id
                ))
        
        select = discord.ui.Select(
            placeholder="Select a child to disown...",
            options=options[:25]
        )
        
        async def select_callback(interaction):
            if interaction.user.id != ctx.author.id:
                await interaction.response.send_message("This menu is not for you!", ephemeral=True)
                return
            
            child_id = select.values[0]
            child = self.bot.get_user(int(child_id))
            
            # Remove adoption
            if child_id in self.adoptions:
                del self.adoptions[child_id]
                self.save_data(self.adoption_file, self.adoptions)
                
                embed = discord.Embed(
                    description=f"❌ {child.mention if child else 'The child'} has been disowned.",
                    color=0xff0000
                )
                await interaction.response.edit_message(embed=embed, view=None)
            else:
                await interaction.response.edit_message(content=f"<:warning:1365257382619250719> {ctx.author.mention}: Child not found!", embed=None, view=None)
        
        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)
        
        await ctx.send("Select a child to disown:", view=view)

    @commands.command(aliases=['family', 'familytree'])
    async def tree(self, ctx, user: discord.Member = None):
        """Display family tree"""
        # Show typing indicator while processing
        async with ctx.typing():
            target = user or ctx.author
            target_id = str(target.id)
            
            # Check if user has a family
            if not self.is_married(target.id) and not self.get_adoptive_parents(target_id) and not self.get_adopted_children(target_id):
                if target == ctx.author:
                    return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You don't have a family tree yet!")
                else:
                    return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: {target.display_name} doesn't have a family tree yet!")
            
            # Get all family connections with relationships
            family_data = self.get_family_data(target_id)
            
            if not family_data:
                if target == ctx.author:
                    return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: You don't have a family tree yet!")
                else:
                    return await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: {target.display_name} doesn't have a family tree yet!")
            
            # Create family tree image
            try:
                image_data = await self.generate_family_tree_image(family_data, target)
                
                # Create embed
                embed = discord.Embed(
                    title=f"👨‍👩‍👧‍👦 {target.display_name}'s Family Tree",
                    color=0xffffff
                )
                embed.set_image(url="attachment://family_tree.png")
                
                await ctx.send(embed=embed, file=discord.File(image_data, "family_tree.png"))
                
            except Exception as e:
                print(f"Error generating family tree: {e}")
                await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: Error generating family tree image.")

    def get_family_data(self, user_id):
        """Get family data with relationships in a tree structure"""
        family_data = {
            'user_id': user_id,
            'spouse': None,
            'parents': [],
            'children': []
        }
        
        # Get marriage data
        marriage = self.get_marriage(user_id)
        if marriage:
            spouse_id = marriage['user2'] if marriage['user1'] == user_id else marriage['user1']
            family_data['spouse'] = spouse_id
        
        # Get parents
        family_data['parents'] = self.get_adoptive_parents(user_id)
        
        # Get children
        family_data['children'] = self.get_adopted_children(user_id)
        
        # Recursively get data for spouse, parents, and children
        extended_family = {}
        queue = [family_data]
        
        while queue:
            current = queue.pop(0)
            current_id = current['user_id']
            
            if current_id in extended_family:
                continue
                
            extended_family[current_id] = current
            
            # Add spouse to queue if not already processed
            if current['spouse'] and current['spouse'] not in extended_family:
                spouse_data = {
                    'user_id': current['spouse'],
                    'spouse': current_id,
                    'parents': self.get_adoptive_parents(current['spouse']),
                    'children': current['children']  # Spouse shares the same children
                }
                queue.append(spouse_data)
            
            # Add parents to queue if not already processed
            for parent_id in current['parents']:
                if parent_id not in extended_family:
                    parent_data = {
                        'user_id': parent_id,
                        'spouse': None,
                        'parents': self.get_adoptive_parents(parent_id),
                        'children': [current_id] + [c for c in self.get_adopted_children(parent_id) if c != current_id]
                    }
                    
                    # Find spouse of parent
                    parent_marriage = self.get_marriage(parent_id)
                    if parent_marriage:
                        spouse_id = parent_marriage['user2'] if parent_marriage['user1'] == parent_id else parent_marriage['user1']
                        parent_data['spouse'] = spouse_id
                    
                    queue.append(parent_data)
            
            # Add children to queue if not already processed
            for child_id in current['children']:
                if child_id not in extended_family:
                    child_data = {
                        'user_id': child_id,
                        'spouse': None,
                        'parents': [current_id] + ([current['spouse']] if current['spouse'] else []),
                        'children': self.get_adopted_children(child_id)
                    }
                    queue.append(child_data)
        
        return extended_family

    async def generate_family_tree_image(self, family_data, target_user):
        """Generate a proper family tree image with connections"""
        try:
            # Create a mapping of user IDs to their data
            user_data = {}
            for user_id, data in family_data.items():
                user = self.bot.get_user(int(user_id))
                if user:
                    user_data[user_id] = {
                        'user': user,
                        'data': data,
                        'image': None
                    }
            
            # Download profile pictures for all family members
            for user_id, data in user_data.items():
                user = data['user']
                async with aiohttp.ClientSession() as session:
                    async with session.get(user.display_avatar.url) as resp:
                        if resp.status == 200:
                            img_data = await resp.read()
                            img = Image.open(io.BytesIO(img_data)).convert("RGBA")
                            
                            # Create circular mask
                            mask = Image.new("L", img.size, 0)
                            draw = ImageDraw.Draw(mask)
                            draw.ellipse((0, 0, img.size[0], img.size[1]), fill=255)
                            
                            # Apply mask
                            result = Image.new("RGBA", img.size)
                            result.paste(img, (0, 0), mask=mask)
                            user_data[user_id]['image'] = result
            
            # Calculate tree structure and positions
            levels = self.calculate_tree_levels(family_data, str(target_user.id))
            
            # Calculate image dimensions based on tree structure
            max_level_width = max(len(level) for level in levels.values()) if levels else 1
            max_level_depth = len(levels) if levels else 1
            
            img_size = 80
            h_spacing = 120
            v_spacing = 150
            padding = 50
            
            width = max_level_width * h_spacing + padding * 2
            height = max_level_depth * v_spacing + padding * 2
            
            # Create blank image
            img = Image.new('RGBA', (width, height), (255, 255, 255, 255))
            draw = ImageDraw.Draw(img)
            
            # Draw title
            try:
                font = ImageFont.truetype("arial.ttf", 24) if os.path.exists("arial.ttf") else ImageFont.load_default()
                title = f"{target_user.display_name}'s Family Tree"
                title_bbox = draw.textbbox((0, 0), title, font=font)
                title_width = title_bbox[2] - title_bbox[0]
                title_x = (width - title_width) // 2
                draw.text((title_x, 10), title, fill='black', font=font)
            except:
                draw.text((10, 10), f"{target_user.display_name}'s Family Tree", fill='black')
            
            # Draw tree connections first
            connection_points = {}  # Store center points of each profile for connections
            
            for level_idx, (level, users) in enumerate(levels.items()):
                y = padding + 50 + level_idx * v_spacing
                
                for user_idx, user_id in enumerate(users):
                    x = padding + user_idx * h_spacing + (width - padding * 2 - (len(users) - 1) * h_spacing) // 2
                    
                    # Store center point for connections
                    connection_points[user_id] = (x + img_size // 2, y + img_size // 2)
                    
                    # Draw connections to parents
                    user_info = family_data[user_id]
                    if user_info['parents']:
                        for parent_id in user_info['parents']:
                            if parent_id in connection_points:
                                parent_x, parent_y = connection_points[parent_id]
                                # Draw line from parent to child
                                draw.line([(parent_x, parent_y + img_size // 2), 
                                          (x + img_size // 2, y - v_spacing // 2 + 25)], 
                                         fill='black', width=2)
                    
                    # Draw connection between spouses
                    if user_info['spouse'] and user_info['spouse'] in connection_points:
                        spouse_x, spouse_y = connection_points[user_info['spouse']]
                        if abs(spouse_x - (x + img_size // 2)) < h_spacing * 2:  # Only connect if spouses are close
                            draw.line([(x + img_size // 2, y + img_size // 2), 
                                      (spouse_x, spouse_y + img_size // 2)], 
                                     fill='black', width=2)
            
            # Draw profile pictures and names on top of connections
            for level_idx, (level, users) in enumerate(levels.items()):
                y = padding + 50 + level_idx * v_spacing
                
                for user_idx, user_id in enumerate(users):
                    x = padding + user_idx * h_spacing + (width - padding * 2 - (len(users) - 1) * h_spacing) // 2
                    
                    # Draw profile picture
                    if user_id in user_data and user_data[user_id]['image']:
                        profile_img = user_data[user_id]['image']
                        if profile_img.size != (img_size, img_size):
                            profile_img = profile_img.resize((img_size, img_size), Image.LANCZOS)
                        img.paste(profile_img, (x, y), profile_img)
                    
                    # Draw username
                    user = self.bot.get_user(int(user_id))
                    if user:
                        username = user.display_name
                        if len(username) > 12:
                            username = username[:12] + "..."
                        
                        try:
                            text_bbox = draw.textbbox((0, 0), username, font=font)
                            text_width = text_bbox[2] - text_bbox[0]
                            text_x = x + (img_size - text_width) // 2
                            draw.text((text_x, y + img_size + 5), username, fill='black', font=font)
                        except:
                            draw.text((x, y + img_size + 5), username, fill='black')
            
            # Convert to bytes
            img_bytes = io.BytesIO()
            img.save(img_bytes, format='PNG')
            img_bytes.seek(0)
            
            return img_bytes
            
        except Exception as e:
            print(f"Error generating family tree image: {e}")
            # Return a simple error image
            img = Image.new('RGB', (400, 200), 'white')
            draw = ImageDraw.Draw(img)
            draw.text((10, 10), f"Error generating family tree: {str(e)}", fill='black')
            
            img_bytes = io.BytesIO()
            img.save(img_bytes, format='PNG')
            img_bytes.seek(0)
            return img_bytes

    def calculate_tree_levels(self, family_data, root_id):
        """Calculate the tree levels for proper layout"""
        levels = {}
        visited = set()
        
        # BFS to assign levels
        queue = [(root_id, 0)]
        
        while queue:
            user_id, level = queue.pop(0)
            
            if user_id in visited:
                continue
                
            visited.add(user_id)
            
            if level not in levels:
                levels[level] = []
            levels[level].append(user_id)
            
            user_info = family_data[user_id]
            
            # Add spouse to the same level
            if user_info['spouse'] and user_info['spouse'] not in visited:
                queue.append((user_info['spouse'], level))
            
            # Add parents to higher level
            for parent_id in user_info['parents']:
                if parent_id not in visited and parent_id in family_data:
                    queue.append((parent_id, level - 1))
            
            # Add children to lower level
            for child_id in user_info['children']:
                if child_id not in visited and child_id in family_data:
                    queue.append((child_id, level + 1))
        
        # Sort levels
        sorted_levels = {k: levels[k] for k in sorted(levels.keys())}
        return sorted_levels

    @marry.error
    async def marry_error(self, ctx, error):
        """Handle errors for marry command"""
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: Please mention someone to marry! Usage: `,marry @user`")
        elif isinstance(error, commands.MemberNotFound):
            await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: User not found! Please mention a valid user.")
        elif isinstance(error, commands.BadArgument):
            await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: Invalid user! Please mention a valid user.")

    @adopt.error
    async def adopt_error(self, ctx, error):
        """Handle errors for adopt command"""
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: Please mention someone to adopt! Usage: `,adopt @user`")
        elif isinstance(error, commands.MemberNotFound):
            await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: User not found! Please mention a valid user.")
        elif isinstance(error, commands.BadArgument):
            await ctx.send(f"<:warning:1365257382619250719> {ctx.author.mention}: Invalid user! Please mention a valid user.")

async def setup(bot):
    await bot.add_cog(MarriageCog(bot))