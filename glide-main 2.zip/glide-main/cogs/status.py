import discord
from discord.ext import commands

class Status(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="status")
    async def status(self, ctx, user: discord.User = None):
        """Check the current Discord status of a user."""
        user = user or ctx.author
        member = ctx.guild.get_member(user.id)

        if member is None:
            # Error embed (user not in server)
            error_embed = discord.Embed(
                description=f"<:Warning:1408771814100041738> {ctx.author.mention} : User not found in this server.",
                color=discord.Color.orange()
            )
            await ctx.send(embed=error_embed)
            return

        # Get status
        status = str(member.status).title()  # online, offline, idle, dnd → Online/Offline/Idle/Dnd
        activity_text = None

        if member.activity:
            if member.activity.type == discord.ActivityType.playing:
                activity_text = f"Playing **{member.activity.name}**"
            elif member.activity.type == discord.ActivityType.streaming:
                activity_text = f"Streaming **{member.activity.name}**"
            elif member.activity.type == discord.ActivityType.listening:
                activity_text = f"Listening to **{member.activity.name}**"
            elif member.activity.type == discord.ActivityType.watching:
                activity_text = f"Watching **{member.activity.name}**"
            else:
                activity_text = f"Doing **{member.activity.name}**"

        # Build main embed
        embed = discord.Embed(
            description=activity_text if activity_text else f"Status: **{status}**",
            color=discord.Color.white()
        )
        embed.set_author(
            name=f"{member.name}'s status",
            icon_url=member.avatar.url if member.avatar else member.default_avatar.url
        )

        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Status(bot))
