import discord
from discord.ext import commands
import json
import os
from datetime import datetime, timedelta
from collections import defaultdict

class MessageTracker(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.data_file = 'data/message_counts.json'
        self.user_data = defaultdict(lambda: {
            'daily': 0,
            'weekly': 0,
            'monthly': 0,
            'last_update': datetime.now().isoformat()
        })
        
        os.makedirs('data', exist_ok=True)
        self.load_data()

    def load_data(self):
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                for user_id, counts in data.items():
                    self.user_data[user_id] = counts

    def save_data(self):
        with open(self.data_file, 'w') as f:
            # Convert defaultdict to regular dict for JSON serialization
            json.dump({k: v for k, v in self.user_data.items()}, f)

    def reset_counts_if_needed(self, user_id):
        user_id = str(user_id)
        now = datetime.now()
        
        if user_id in self.user_data:
            last_update = datetime.fromisoformat(self.user_data[user_id]['last_update'])
            
            # Reset daily count if more than 1 day has passed
            if (now - last_update) >= timedelta(days=1):
                self.user_data[user_id]['daily'] = 0
            
            # Reset weekly count if more than 7 days have passed
            if (now - last_update) >= timedelta(days=7):
                self.user_data[user_id]['weekly'] = 0
            
            # Reset monthly count if more than 30 days have passed
            if (now - last_update) >= timedelta(days=30):
                self.user_data[user_id]['monthly'] = 0
        
        # Always update the last_update time
        self.user_data[user_id]['last_update'] = now.isoformat()

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
            
        user_id = str(message.author.id)
        self.reset_counts_if_needed(user_id)
        
        # Increment all counts
        self.user_data[user_id]['daily'] += 1
        self.user_data[user_id]['weekly'] += 1
        self.user_data[user_id]['monthly'] += 1
        
        self.save_data()

    @commands.command(aliases=['message', 'm'])
    async def messages(self, ctx, user: discord.User = None):
        """Show your message stats or another user's"""
        target = user or ctx.author
        user_id = str(target.id)
        
        # Ensure user exists in data
        if user_id not in self.user_data:
            self.user_data[user_id] = {
                'daily': 0,
                'weekly': 0,
                'monthly': 0,
                'last_update': datetime.now().isoformat()
            }
        
        self.reset_counts_if_needed(user_id)
        
        embed = discord.Embed(
            description=(
                f"_ _\n"
                f"> {target.mention}'s message stats:\n"
                f"> 1 day: **{self.user_data[user_id]['daily']}**\n"
                f"> 7 days: **{self.user_data[user_id]['weekly']}**\n"
                f"> 30 days: **{self.user_data[user_id]['monthly']}**\n"
                f"_ _"
            ),
            color=discord.Color.from_rgb(255, 255, 255)
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(MessageTracker(bot))