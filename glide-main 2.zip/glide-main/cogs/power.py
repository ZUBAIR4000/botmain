import discord
import os
import sys
from discord.ext import commands
from discord import ui

class PowerControls(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Add your user ID and the specified ID to the allowed list
        self.allowed_user_ids = [self.bot.owner_id, 1339387428498178132]

    def is_allowed_user(self, user_id):
        """Check if user is allowed to use power commands"""
        return user_id in self.allowed_user_ids

    class PowerView(ui.View):
        """View for power control buttons"""
        def __init__(self, bot):
            super().__init__(timeout=30.0)
            self.bot = bot
            self.action_taken = False

        @ui.button(emoji='<:power:1387443864649994301>', style=discord.ButtonStyle.danger)
        async def shutdown_button(self, interaction: discord.Interaction, button: ui.Button):
            """Shutdown the bot"""
            if not self.bot.get_cog('PowerControls').is_allowed_user(interaction.user.id):
                await interaction.response.send_message("no", ephemeral=True)
                return
                
            self.action_taken = True
            await interaction.response.send_message("done")
            await self.bot.close()
            # Exit the process
            sys.exit(0)

        @ui.button(emoji='<:renewableenergy:1387443894530084894>', style=discord.ButtonStyle.success)
        async def restart_button(self, interaction: discord.Interaction, button: ui.Button):
            """Restart the bot"""
            if not self.bot.get_cog('PowerControls').is_allowed_user(interaction.user.id):
                await interaction.response.send_message("no", ephemeral=True)
                return
                
            self.action_taken = True
            await interaction.response.send_message("restarting...")
            await self.bot.close()
            # Restart using the same command that started the bot
            os.execv(sys.executable, ['python'] + sys.argv)

        @ui.button(emoji='❌', style=discord.ButtonStyle.secondary)
        async def cancel_button(self, interaction: discord.Interaction, button: ui.Button):
            """Cancel power operation"""
            if not self.bot.get_cog('PowerControls').is_allowed_user(interaction.user.id):
                await interaction.response.send_message("no", ephemeral=True)
                return
                
            await interaction.response.send_message("ok")
            self.action_taken = True
            self.stop()

        async def on_timeout(self):
            """Disable buttons when view times out"""
            if not self.action_taken:
                for child in self.children:
                    child.disabled = True
                await self.message.edit(view=self)

    @commands.command(name="power")
    async def power_control(self, ctx):
        """Power management controls (Restricted)"""
        if not self.is_allowed_user(ctx.author.id):
            await ctx.send("no")
            return
            
        # Create and send view
        view = self.PowerView(self.bot)
        message = await ctx.send("관리자의 권한 남용을 방지하기 위해 핵무기 방지 시스템을 구축하는 것이 중요합니다. 이는 서버를 유해한 행위로부터 안전하게 보호할 수 있는 보안 조치입니다. 관리자의 권한 남용을 방지하기 위해 핵무기 방지 시스템을 구축하는 것이 중요합니다. 이는 서버를 유해한 행위로부터 안전하게 보호할 수 있는 보안 조치입니다.", view=view)
        view.message = message

async def setup(bot):
    await bot.add_cog(PowerControls(bot))