import discord
from discord.ext import commands
import asyncio
from datetime import datetime, timedelta

class DeadChatCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_channels = set()
        self.last_message_times = {}
        self.check_task = None

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def dcenable(self, ctx, channel: discord.TextChannel):
        """Enable dead chat detection in a channel"""
        self.active_channels.add(channel.id)
        self.last_message_times[channel.id] = datetime.now()
        
        if self.check_task is None or self.check_task.done():
            self.check_task = asyncio.create_task(self._check_dead_chats())
            
        await ctx.send(embed=discord.Embed(
            description=f"✅ Dead chat detection enabled in {channel.mention}",
            color=discord.Color.green()
        ))

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def dcdisable(self, ctx, channel: discord.TextChannel):
        """Disable dead chat detection in a channel"""
        self.active_channels.discard(channel.id)
        await ctx.send(embed=discord.Embed(
            description=f"❌ Dead chat detection disabled in {channel.mention}",
            color=discord.Color.red()
        ))

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.channel.id in self.active_channels:
            self.last_message_times[message.channel.id] = datetime.now()

    async def _check_dead_chats(self):
        while True:
            await asyncio.sleep(60)  # Check every minute
            
            for channel_id in list(self.active_channels):
                channel = self.bot.get_channel(channel_id)
                if not channel:
                    continue
                    
                last_msg_time = self.last_message_times.get(channel_id)
                if last_msg_time and datetime.now() - last_msg_time > timedelta(minutes=5):
                    # Find last non-bot message
                    try:
                        last_message = None
                        async for msg in channel.history(limit=10):
                            if not msg.author.bot:
                                last_message = msg
                                break
                                
                        if last_message:
                            await channel.send(
                                f"{last_message.author.mention} killed the chat <:Blobbored:1319675168833933432>"
                            )
                            self.last_message_times[channel_id] = datetime.now()
                    except discord.Forbidden:
                        self.active_channels.discard(channel_id)

async def setup(bot):
    await bot.add_cog(DeadChatCog(bot))