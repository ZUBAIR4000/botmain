import discord
from discord.ext import commands

class VCLinkCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="vc")
    async def vc(self, ctx):
        """Send the invite link of the voice channel the user is currently in"""
        # Check if the user is in a voice channel
        if ctx.author.voice and ctx.author.voice.channel:
            vc = ctx.author.voice.channel

            # Create an invite link for the voice channel
            try:
                invite = await vc.create_invite(max_age=300, max_uses=1, reason="VC link requested by user")
                await ctx.send(f"VC Link {invite.url}")
            except discord.Forbidden:
                await ctx.send("I don't have permission to create an invite for this voice channel.")
            except Exception as e:
                await ctx.send(f"An error occurred while creating the invite: {e}")
        else:
            await ctx.send("you are not in a vc")

async def setup(bot):
    await bot.add_cog(VCLinkCog(bot))