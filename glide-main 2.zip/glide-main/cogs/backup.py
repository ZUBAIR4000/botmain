import discord
from discord.ext import commands
import json
import os
from typing import Dict, List

class RoleBackup(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.backups: Dict[int, Dict[int, List[int]]] = {}  # {guild_id: {user_id: [role_ids]}}
        self.load_backups()

    def load_backups(self):
        """Load backups from file if it exists"""
        if os.path.exists('role_backups.json'):
            with open('role_backups.json', 'r') as f:
                self.backups = json.load(f)
                # Convert keys back to integers (JSON saves them as strings)
                self.backups = {
                    int(guild_id): {
                        int(user_id): role_ids 
                        for user_id, role_ids in users.items()
                    }
                    for guild_id, users in self.backups.items()
                }

    def save_backups(self):
        """Save backups to file"""
        with open('role_backups.json', 'w') as f:
            json.dump(self.backups, f)

    async def create_backup(self, user: discord.Member):
        """Create a backup of a user's roles"""
        guild_id = user.guild.id
        user_id = user.id
        
        # Remove @everyone role and bot roles
        roles = [role.id for role in user.roles if not role.is_bot_managed() and role != user.guild.default_role]
        
        # Initialize guild storage if needed
        if guild_id not in self.backups:
            self.backups[guild_id] = {}
        
        # Store the backup
        self.backups[guild_id][user_id] = roles
        self.save_backups()
        
        return len(roles)

    async def load_backup(self, user: discord.Member):
        """Load a user's role backup"""
        guild_id = user.guild.id
        user_id = user.id
        
        # Check if backup exists
        if guild_id not in self.backups or user_id not in self.backups[guild_id]:
            return False
        
        # Get current roles to remove (excluding @everyone and managed roles)
        current_roles = [role for role in user.roles if not role.is_bot_managed() and role != user.guild.default_role]
        
        # Get backup roles
        backup_role_ids = self.backups[guild_id][user_id]
        backup_roles = [user.guild.get_role(role_id) for role_id in backup_role_ids]
        backup_roles = [role for role in backup_roles if role is not None]  # Filter out deleted roles
        
        try:
            # Remove current roles
            if current_roles:
                await user.remove_roles(*current_roles, reason="Role backup restoration")
            
            # Add backup roles
            if backup_roles:
                await user.add_roles(*backup_roles, reason="Role backup restoration")
            
            return True
        except discord.Forbidden:
            return False

    @commands.command(name="backup")
    async def backup(self, ctx):
        """Create or load your role backup"""
        embed = discord.Embed(
            title="Roles Cloud Backup ",
            description="create or load a backup of your roles incase you get stripped by an admin. creating a new backup will override your previous one.Use backup load button to get stored roles from your most recent backup.",
            color=0x5865F2
        )
        
        # Check if user has a backup
        has_backup = (
            ctx.guild.id in self.backups and 
            ctx.author.id in self.backups[ctx.guild.id]
        )
        
        if has_backup:
            role_count = len(self.backups[ctx.guild.id][ctx.author.id])
            embed.add_field(
                name="Current Backup",
                value=f"You have a backup of {role_count} roles",
                inline=False
            )
        else:
            embed.add_field(
                name="Current Backup",
                value="You don't have any saved backups",
                inline=False
            )
        
        # Create view with buttons
        view = discord.ui.View(timeout=60)
        
        # Create Backup button
        create_button = discord.ui.Button(
            style=discord.ButtonStyle.green,
            label="Create Backup",
            emoji="💾"
        )
        
        async def create_callback(interaction):
            if interaction.user != ctx.author:
                embed_msg = discord.Embed(
                    description=f"<:no:1399080437556576356> {interaction.user.mention}: This isn't your backup menu!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed_msg, ephemeral=True)
                return
            
            role_count = await self.create_backup(ctx.author)
            embed_msg = discord.Embed(
                description=f"<:yes1:1389288766291574804> {interaction.user.mention} : Successfully backed up {role_count} roles",
                color=0x57F287
            )
            await interaction.response.send_message(embed=embed_msg, ephemeral=True)
            
            # Update the original message
            embed.set_field_at(
                0,
                name="My Backup",
                value=f"You have a backup of {role_count} roles",
                inline=False
            )
            await interaction.message.edit(embed=embed)

        create_button.callback = create_callback
        view.add_item(create_button)
        
        # Load Backup button (only enabled if backup exists)
        load_button = discord.ui.Button(
            style=discord.ButtonStyle.blurple,
            label="Load Backup",
            emoji="🔄",
            disabled=not has_backup
        )
        
        async def load_callback(interaction):
            if interaction.user != ctx.author:
                embed_msg = discord.Embed(
                    description=f"<:no:1399080437556576356> {interaction.user.mention}: This isn't your backup menu!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed_msg, ephemeral=True)
                return
            
            success = await self.load_backup(ctx.author)
            if success:
                embed_msg = discord.Embed(
                    description=f"<:yes1:1389288766291574804> {interaction.user.mention} : Successfully restored your roles!",
                    color=0x57F287
                )
                await interaction.response.send_message(embed=embed_msg, ephemeral=True)
            else:
                embed_msg = discord.Embed(
                    description=f"<:no:1399080437556576356> {interaction.user.mention}: Failed to restore roles. Do you have a backup?",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed_msg, ephemeral=True)

        load_button.callback = load_callback
        view.add_item(load_button)
        
        # Delete Backup button (only shown if backup exists)
        if has_backup:
            delete_button = discord.ui.Button(
                style=discord.ButtonStyle.red,
                label="Delete Backup",
                emoji="🗑️"
            )
            
            async def delete_callback(interaction):
                if interaction.user != ctx.author:
                    embed_msg = discord.Embed(
                        description=f"<:no:1399080437556576356> {interaction.user.mention}: This isn't your backup menu!",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=embed_msg, ephemeral=True)
                    return
                
                del self.backups[ctx.guild.id][ctx.author.id]
                self.save_backups()
                
                embed_msg = discord.Embed(
                    description=f"<:yes1:1389288766291574804> {interaction.user.mention} : Your backup has been deleted!",
                    color=0x57F287
                )
                await interaction.response.send_message(embed=embed_msg, ephemeral=True)
                
                # Update the original message
                embed.set_field_at(
                    0,
                    name="Current Backup",
                    value="You don't have any saved backups",
                    inline=False
                )
                await interaction.message.edit(embed=embed, view=view)

            delete_button.callback = delete_callback
            view.add_item(delete_button)
        
        await ctx.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(RoleBackup(bot))