import discord
from discord.ext import commands
from datetime import datetime, timedelta

class WorthCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.breakdown_data = {}  # Initialize the breakdown data storage

    @commands.command()
    async def worth(self, ctx):
        """Calculate the estimated worth of this server"""
        guild = ctx.guild
        
        # Initialize values
        total = 0.0
        breakdown = []
        
        # 1. Boosts calculation
        boost_count = guild.premium_subscription_count
        boost_value = boost_count * 3.99
        total += boost_value
        breakdown.append(f"Boosts ({boost_count}): ${boost_value:.2f}")
        
        # 2. Vanity URL calculation
        vanity_value = 0
        try:
            vanity = await guild.vanity_invite()
            if vanity and vanity.code:
                vanity_code = vanity.code
                if len(vanity_code) == 2:
                    vanity_value = 200
                elif len(vanity_code) == 3:
                    vanity_value = 120
                elif len(vanity_code) >= 4:
                    vanity_value = 50
                
                # Subtract for numbers in vanity
                number_count = sum(1 for char in vanity_code if char.isdigit())
                vanity_value -= number_count * 15
                vanity_value = max(0, vanity_value)  # Ensure not negative
                
                total += vanity_value
                breakdown.append(f"Vanity URL ('{vanity_code}'): ${vanity_value:.2f}")
        except:
            pass  # Server doesn't have a vanity URL or bot doesn't have permission
        
        # 3. Members calculation
        online_members = sum(1 for m in guild.members if m.status != discord.Status.offline and not m.bot)
        offline_members = sum(1 for m in guild.members if m.status == discord.Status.offline and not m.bot)
        
        online_value = online_members * 0.43
        offline_value = offline_members * 0.20
        total += online_value + offline_value
        breakdown.append(f"Online members ({online_members}): ${online_value:.2f}")
        breakdown.append(f"Offline members ({offline_members}): ${offline_value:.2f}")
        
        # 4. Special bot check
        special_bot = guild.get_member(593921296224747521)
        if special_bot:
            total += 31
            breakdown.append("Special bot: $31.00")
        
        # 5. Voice channel members
        vc_members = sum(len(vc.members) for vc in guild.voice_channels)
        vc_value = vc_members * 2
        total += vc_value
        breakdown.append(f"VC members ({vc_members}): ${vc_value:.2f}")
        
        # 6. Recent chatters (within 1 minute)
        recent_chatters = set()
        one_minute_ago = datetime.utcnow() - timedelta(minutes=1)
        
        for channel in guild.text_channels:
            try:
                async for message in channel.history(limit=100, after=one_minute_ago):
                    if not message.author.bot:
                        recent_chatters.add(message.author.id)
            except:
                continue
        
        recent_value = len(recent_chatters) * 5
        total += recent_value
        breakdown.append(f"Recent chatters ({len(recent_chatters)}): ${recent_value:.2f}")
        
        # 7. Discovery status
        if hasattr(guild, 'discovery_splash') and guild.discovery_splash:
            total += 15
            breakdown.append("Discovery enabled: $15.00")
        
        # 8. Partner/Verified status
        if hasattr(guild, 'partnered') and guild.partnered:
            total += 200
            breakdown.append("Discord Partner: $200.00")
        elif hasattr(guild, 'verified') and guild.verified:
            total += 200
            breakdown.append("Verified Server: $200.00")
        
        # Convert to PKR (approximate rate)
        pkr_value = total * 280  # Approximate USD to PKR conversion
        
        # Send initial message
        message = await ctx.send(f"Server Estimated Worth **${total:,.2f}** *(~PKR {pkr_value:,.2f})*")
        await message.add_reaction("ℹ️")
        
        # Store breakdown data for reaction
        self.breakdown_data[message.id] = {
            'breakdown': breakdown,
            'total': total,
            'pkr_value': pkr_value,
            'user_id': ctx.author.id
        }

    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
        if user.bot:
            return
        
        if str(reaction.emoji) == "ℹ️" and reaction.message.id in self.breakdown_data:
            data = self.breakdown_data[reaction.message.id]
            
            # Check if the reactor is the command user
            if user.id == data['user_id']:
                # Create embed with breakdown
                embed = discord.Embed(
                    title="💰 Server Worth Breakdown",
                    description="Detailed calculation of server valuation",
                    color=0x00ff00
                )
                
                for item in data['breakdown']:
                    embed.add_field(name="•", value=item, inline=False)
                
                embed.add_field(
                    name="Total",
                    value=f"**${data['total']:,.2f}** *(~PKR {data['pkr_value']:,.2f})*",
                    inline=False
                )
                
                try:
                    await user.send(embed=embed)
                except:
                    # If user has DMs disabled, send in channel
                    await reaction.message.channel.send(
                        f"{user.mention} I couldn't DM you the breakdown. Please enable DMs and try again.",
                        delete_after=10
                    )
                
                await reaction.message.remove_reaction(reaction.emoji, user)

async def setup(bot):
    await bot.add_cog(WorthCog(bot))