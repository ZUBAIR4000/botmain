import discord
import random
from discord.ext import commands
from discord import ui

GRADIENT_ROLES = [
    1388829798150705182, 1388829871949611038, 1388829858460733464,
    1388829816123555901, 1388829833638969405, 1388829775937671188,
    1388829746309103698, 1388829698192314449
]

class GradientCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.user_roles = {}  # {user_id: current_role_id}

    class GradientView(ui.View):
        def __init__(self, target_user_id, cog):
            super().__init__(timeout=None)
            self.target_user_id = target_user_id
            self.cog = cog

        @ui.button(label="Apply Gradient", style=discord.ButtonStyle.blurple, emoji="")
        async def apply_gradient(self, interaction: discord.Interaction, button: ui.Button):
            """Apply a new random gradient role"""
            # Verify it's the target user
            if interaction.user.id != self.target_user_id:
                await interaction.response.send_message(
                    "you dont have permission to do that",
                    ephemeral=True
                )
                return
                
            await interaction.response.defer(ephemeral=True)
            
            # Get the user as a member of the guild
            member = interaction.guild.get_member(self.target_user_id)
            if not member:
                await interaction.followup.send("nuh uh", ephemeral=True)
                return
                
            # Remove previous role if exists
            current_role_id = self.cog.user_roles.get(self.target_user_id)
            if current_role_id:
                current_role = interaction.guild.get_role(current_role_id)
                if current_role and current_role in member.roles:
                    try:
                        await member.remove_roles(current_role)
                    except discord.Forbidden:
                        await interaction.followup.send("perms erro", ephemeral=True)
                        return
                    except discord.HTTPException:
                        pass
            
            # Select a new random role (different from previous)
            available_roles = [r for r in GRADIENT_ROLES if r != current_role_id]
            if not available_roles:
                available_roles = GRADIENT_ROLES
                
            new_role_id = random.choice(available_roles)
            new_role = interaction.guild.get_role(new_role_id)
            
            if not new_role:
                await interaction.followup.send("roles unavailable", ephemeral=True)
                return
                
            # Apply new role
            try:
                await member.add_roles(new_role)
            except discord.Forbidden:
                await interaction.followup.send("nope", ephemeral=True)
                return
            except discord.HTTPException as e:
                await interaction.followup.send(f"couldnt {str(e)}", ephemeral=True)
                return
                
            # Update tracking
            self.cog.user_roles[self.target_user_id] = new_role_id
            
            await interaction.followup.send(
                f"Gradient set to {new_role.name}",
                ephemeral=True
            )

    @commands.command(name="gradient")
    @commands.has_permissions(manage_roles=True)
    async def gradient_role(self, ctx, user: discord.Member):
        """Apply a random gradient role to a user"""
        # Verify gradient roles exist
        for role_id in GRADIENT_ROLES:
            if not ctx.guild.get_role(role_id):
                await ctx.send(f" {role_id} not found in this server")
                return
                
        # Create view
        view = self.GradientView(user.id, self)
        
        # Create embed
        embed = discord.Embed(
            title="Gradient Roles",
            description=f"{user.mention} click 2 get a random gradient role \n"
                        "",
            color=0x6A0DAD
        )
        
        await ctx.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(GradientCommand(bot))