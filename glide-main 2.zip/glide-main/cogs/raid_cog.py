import discord
from discord.ext import commands
import random
import asyncio
import string
from utils import create_embed

class RaidCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_raids = {}

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def raid(self, ctx, channel: discord.TextChannel):
        """Spam a channel with random characters for 15 seconds"""
        # Check if raid is already active in this channel
        if channel.id in self.active_raids:
            await ctx.send(embed=create_embed("❌ A raid is already active in this channel!"))
            return
            
        # Confirm raid start
        await ctx.send(embed=create_embed(f"🔥 Starting raid in {channel.mention} for 15 seconds..."))
        
        # Start raid task
        self.active_raids[channel.id] = True
        raid_task = asyncio.create_task(self._execute_raid(channel))
        
        # Wait for raid to complete
        await raid_task
        
        # Cleanup
        if channel.id in self.active_raids:
            del self.active_raids[channel.id]

    async def _execute_raid(self, channel):
        """Core raid functionality"""
        messages = []
        
        try:
            # Generate and send random strings for 15 seconds
            end_time = asyncio.get_event_loop().time() + 15
            while asyncio.get_event_loop().time() < end_time:
                # Create random string (50-100 characters)
                length = random.randint(50, 100)
                random_string = ''.join(
                    random.choices(
                        string.ascii_letters + string.digits + string.punctuation,
                        k=length
                    )
                )
                
                # Send message
                try:
                    msg = await channel.send(random_string)
                    messages.append(msg)
                except discord.HTTPException:
                    pass  # Ignore send errors
                
                # Random delay between messages (0.05-0.2 seconds)
                await asyncio.sleep(random.uniform(0.05, 0.2))
        finally:
            # Delete all raid messages
            await self._cleanup_raid(channel, messages)

    async def _cleanup_raid(self, channel, messages):
        """Delete all raid messages in batches"""
        if not messages:
            return
            
        # Send cleanup notification
        notification = await channel.send(embed=create_embed("🧹 Cleaning up raid messages..."))
        
        # Delete messages in batches of 5 (Discord API limit)
        while messages:
            batch = messages[:5]
            messages = messages[5:]
            
            try:
                await channel.delete_messages(batch)
            except discord.HTTPException:
                pass  # Ignore delete errors
            
            # Wait to avoid rate limits
            await asyncio.sleep(1.2)
        
        # Delete cleanup notification
        try:
            await notification.delete()
        except discord.HTTPException:
            pass

    @raid.error
    async def raid_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send(embed=create_embed("❌ You need administrator permissions to use this command!"))
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(embed=create_embed("❌ Please mention a channel! Example: `,raid #general`"))
        elif isinstance(error, commands.ChannelNotFound):
            await ctx.send(embed=create_embed("❌ Channel not found! Please mention a valid text channel."))

async def setup(bot):
    await bot.add_cog(RaidCog(bot))