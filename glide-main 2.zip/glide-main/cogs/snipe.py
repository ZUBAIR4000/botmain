import discord
from discord.ext import commands
from datetime import datetime, timedelta
import discord.utils

snipe_data = {}

class SnipeView(discord.ui.View):
    def __init__(self, ctx, snipe_list):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.page = 0
        self.snipe_list = snipe_list
        self.message = None

        # Remove navigation buttons if only one entry
        if len(snipe_list) == 1:
            for child in self.children.copy():
                if isinstance(child, discord.ui.Button) and child.emoji:
                    if child.emoji.id in (1365038192931377212, 1365038148446589060):
                        self.remove_item(child)

    async def interaction_check(self, interaction):
        return interaction.user == self.ctx.author

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True
        await self.message.edit(view=self)

    def create_embed(self):
        snipe = self.snipe_list[self.page]
        time_ago = discord.utils.format_dt(snipe["deleted_at"], "R")
        
        embed = discord.Embed(color=0x000000())
        embed.set_author(name=f"{snipe['author']}", icon_url=snipe["author_avatar"])
        embed.description = snipe["content"] or "*[No text content]*"
        
        if snipe["attachments"]:
            attachment = snipe["attachments"][0]
            if attachment.url.lower().endswith(('png', 'jpeg', 'jpg', 'gif', 'webp')):
                embed.set_image(url=attachment.url)
            else:
                embed.add_field(name="Attachment", value=f"[{attachment.filename}]({attachment.url})")
        
        embed.set_footer(text=f"Deleted {time_ago} • Page {self.page + 1}/{len(self.snipe_list)}")
        return embed

    # Button order: Left, Right, Delete
    @discord.ui.button(emoji="<:arrowleft:1365038192931377212>", style=discord.ButtonStyle.grey)
    async def previous_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page = max(0, self.page - 1)
        await interaction.response.edit_message(embed=self.create_embed())

    @discord.ui.button(emoji="<:arrowright:1365038148446589060>", style=discord.ButtonStyle.grey)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page = min(len(self.snipe_list) - 1, self.page + 1)
        await interaction.response.edit_message(embed=self.create_embed())

    @discord.ui.button(emoji="<:close:1408772199950581903>", style=discord.ButtonStyle.grey)
    async def delete_snipe(self, interaction: discord.Interaction, button: discord.ui.Button):
        del self.snipe_list[self.page]
        if not self.snipe_list:
            await interaction.response.edit_message(content="removed by author.", embed=None, view=None)
            return
        
        # Adjust page number and remove navigation buttons if needed
        self.page = min(self.page, len(self.snipe_list) - 1)
        if len(self.snipe_list) == 1:
            for child in self.children.copy():
                if isinstance(child, discord.ui.Button) and child.emoji:
                    if child.emoji.id in (1365038192931377212, 1365038148446589060):
                        self.remove_item(child)
        
        await interaction.response.edit_message(embed=self.create_embed(), view=self)

class Snipe(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.author.bot:
            return
        
        channel_id = message.channel.id
        snipe_data.setdefault(channel_id, []).insert(0, {
            "content": message.content,
            "author": str(message.author),
            "author_avatar": message.author.display_avatar.url,
            "attachments": message.attachments,
            "deleted_at": datetime.now(),
            "deleter": None
        })

        # Prune old snipes
        snipe_data[channel_id] = [
            s for s in snipe_data[channel_id]
            if (datetime.now() - s["deleted_at"]) < timedelta(hours=8)
        ]

    @commands.command(aliases=['s'])
    async def snipe(self, ctx):
        """View deleted messages in this channel"""
        snipes = snipe_data.get(ctx.channel.id, [])
        
        if not snipes:
            await ctx.send("No deleted messages to snipe in this channel!")
            return
            
        view = SnipeView(ctx, snipes)
        view.message = await ctx.send(embed=view.create_embed(), view=view)

    @commands.command(aliases=['cs'])
    @commands.has_permissions(manage_messages=True)
    async def clearsnipe(self, ctx):
        """Clear all snipes in this channel"""
        channel_id = ctx.channel.id
        if channel_id in snipe_data:
            del snipe_data[channel_id]
        
        embed = discord.Embed(
            description=f"<:yes:1408771592292401232> {ctx.author.mention}: Cleared all snipes from this channel",
            color=0x2b2d31
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Snipe(bot))