import discord
from discord.ext import commands
import asyncio
import random
import re
from utils import create_embed

class UwuLockCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.uwu_locks = {}  # {guild_id: {user_id: (webhook, task)}}
        self.uwu_words = {
            'hello': 'hewwo',
            'hi': 'haiiiii',
            'you': 'chu',
            'your': 'chur',
            'the': 'da',
            'this': 'dis',
            'that': 'dat',
            'love': 'wuv',
            'what': 'wat',
            'riot': 'WIOTT!!',
            'no': 'nyo',
            'yes': 'yesssss',
            'please': 'pwease',
            'thanks': 'tank chuuuu',
            'thank you': 'tank chu so muchhh',
            'good': 'gud',
            'very': 'vewy',
            'really': 'weawwy',
            'are': 'r',
            'am': 'm',
            'my': 'mwy',
            'me': 'mi',
            'for': 'fow',
            'with': 'wif',
            'people': 'peepow',
            'some': 'sum',
            'come': 'cum',
            'cute': 'kawaii',
            'happy': 'happy-wappy'
        }
        self.uwu_symbols = [
            ' uwu', ' owo', ' >w<', ' ;3', ' x3', ' :3', ' ^w^', ' ^-^', 
            ' (◕‿◕✿)', ' (｡♥‿♥｡)', ' (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧', ' nyaa~', ' rawr xD',
            ' ≧◡≦', ' ʕ•ᴥ•ʔ', ' (づ｡◕‿‿◕｡)づ', ' (ﾉ´ヮ`)ﾉ*: ･ﾟ', ' ♡w♡',
            ' ✧･ﾟ: *✧･ﾟ:* *:･ﾟ✧*:･ﾟ✧', ' ~~', ' !!!!', ' ???', ' ...'
        ]

    def stretch_letters(self, word):
        """Randomly stretch letters in a word"""
        if len(word) <= 2 or random.random() > 0.4:
            return word
            
        # Choose letters to stretch (focus on vowels and ending consonants)
        stretchable = []
        for i, c in enumerate(word.lower()):
            if c in 'aeiouy':
                stretchable.append((i, c))
            elif i == len(word)-1 and c in 'mnrsz':
                stretchable.append((i, c))
        
        if not stretchable:
            return word
            
        # Stretch 1-3 random letters
        for _ in range(random.randint(1, 3)):
            if not stretchable:
                break
            i, c = random.choice(stretchable)
            stretch_length = random.randint(2, 5)
            word = word[:i] + (c * stretch_length).upper() + word[i+1:]
            stretchable.remove((i, c))
        
        return word

    def uwufy_text(self, text):
        """Convert text to extreme uwu speak"""
        # Skip if empty or just symbols
        if not text.strip():
            return text
            
        # Randomly uppercase entire message
        if random.random() < 0.1:
            text = text.upper()
        
        # Replace specific words first
        for word, replacement in self.uwu_words.items():
            if random.random() < 0.8:  # 80% chance to replace known words
                text = re.sub(r'\b' + re.escape(word) + r'\b', replacement, text, flags=re.IGNORECASE)
        
        # Process each word
        words = text.split()
        result = []
        for word in words:
            # Skip URLs and mentions
            if word.startswith(('http://', 'https://', '@', '#')):
                result.append(word)
                continue
                
            # Random letter stretching
            if random.random() < 0.3:
                word = self.stretch_letters(word)
            
            # Random uwu-ifications
            if random.random() < 0.5:
                word = word.replace('r', 'w').replace('l', 'w')
                word = word.replace('R', 'W').replace('L', 'W')
            
            # Random cute replacements
            if random.random() < 0.2:
                word = word.replace('na', 'nya').replace('ne', 'nye')
                word = word.replace('NA', 'NYA').replace('NE', 'NYE')
            
            result.append(word)
        
        text = ' '.join(result)
        
        # Add random uwu suffixes
        if random.random() < 0.7:
            text += random.choice(self.uwu_symbols)
            
            # Sometimes add multiple symbols
            if random.random() < 0.3:
                text += random.choice(self.uwu_symbols)
        
        # Random stutters
        if random.random() < 0.25 and len(text) > 3:
            text = text[0] + '-' + text
        
        # Random alternating caps
        if random.random() < 0.2:
            text = ''.join(
                c.upper() if i % 2 == 0 else c.lower() 
                for i, c in enumerate(text)
            )
        
        # Random exclamation
        if random.random() < 0.15:
            exclamations = [' NYA!!', ' UWU!!!', ' OWO!!', ' X3', ' !!!!1!', ' ^^']
            text += random.choice(exclamations)
        
        return text.capitalize()

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def uwulock(self, ctx, user: discord.User):
        """Uwulock a user for 15 minutes"""
        if ctx.guild.id not in self.uwu_locks:
            self.uwu_locks[ctx.guild.id] = {}
        
        if user.id in self.uwu_locks[ctx.guild.id]:
            return await ctx.send(embed=create_embed(f"{user.mention} is already uwulocked"))
        
        try:
            # Create webhook with user's appearance
            avatar = await user.avatar.read() if user.avatar else None
            webhook = await ctx.channel.create_webhook(
                name=user.display_name,
                avatar=avatar,
                reason=f"Uwulock for {user.name}"
            )
        except Exception as e:
            return await ctx.send(embed=create_embed(f"{e}"))
        
        # Store lock with timestamp
        self.uwu_locks[ctx.guild.id][user.id] = (webhook, asyncio.get_event_loop().time())
        
        # Auto-unlock after 15 minutes
        asyncio.create_task(self._auto_unlock(ctx.guild.id, user.id))
        
        await ctx.send(embed=create_embed(
            f"{user.mention} has been uwulocked for 15 minutes /n -# ,cuwulock @user"
           
        ))

    async def _auto_unlock(self, guild_id, user_id):
        """Automatically remove uwulock after 15 minutes"""
        await asyncio.sleep(900)  # 15 minutes
        
        if guild_id in self.uwu_locks and user_id in self.uwu_locks[guild_id]:
            webhook, _ = self.uwu_locks[guild_id][user_id]
            await self._cleanup_uwulock(guild_id, user_id, webhook)

    @commands.command(aliases=['cuwulock'])
    @commands.has_permissions(manage_messages=True)
    async def clearuwulock(self, ctx, user: discord.User = None):
        """Clear uwulocks from user or all users"""
        if ctx.guild.id not in self.uwu_locks or not self.uwu_locks[ctx.guild.id]:
            return await ctx.send(embed=create_embed("❌ No users are currently uwulocked! owo"))
        
        if user:
            if user.id in self.uwu_locks[ctx.guild.id]:
                webhook, _ = self.uwu_locks[ctx.guild.id][user.id]
                await self._cleanup_uwulock(ctx.guild.id, user.id, webhook)
                await ctx.send(embed=create_embed(f"removed uwulock from {user.mention} "))
            else:
                await ctx.send(embed=create_embed(f"{user.mention} isn't uwulocked! >w<"))
        else:
            # Clear all uwulocks
            for uid, (webhook, _) in list(self.uwu_locks[ctx.guild.id].items()):
                await self._cleanup_uwulock(ctx.guild.id, uid, webhook)
            await ctx.send(embed=create_embed("✅ Cleared ALL uwulocks in dis server!! UWU!!"))

    async def _cleanup_uwulock(self, guild_id, user_id, webhook):
        """Clean up uwulock resources"""
        try:
            await webhook.delete()
        except:
            pass
        
        if guild_id in self.uwu_locks and user_id in self.uwu_locks[guild_id]:
            del self.uwu_locks[guild_id][user_id]
            
            # Remove guild entry if empty
            if not self.uwu_locks[guild_id]:
                del self.uwu_locks[guild_id]

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
            
        guild_id = message.guild.id
        if guild_id in self.uwu_locks and message.author.id in self.uwu_locks[guild_id]:
            webhook, _ = self.uwu_locks[guild_id][message.author.id]
            
            try:
                # Delete original message
                await message.delete()
                
                # Create uwufied version
                uwu_text = self.uwufy_text(message.content)
                
                # Send through webhook
                await webhook.send(
                    content=uwu_text,
                    username=message.author.display_name,
                    avatar_url=message.author.avatar.url if message.author.avatar else None,
                    files=[await attachment.to_file() for attachment in message.attachments]
                )
            except Exception as e:
                print(f"Uwulock error: {e}")

async def setup(bot):
    await bot.add_cog(UwuLockCog(bot))