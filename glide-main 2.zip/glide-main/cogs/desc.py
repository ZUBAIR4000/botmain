import discord
from discord.ext import commands

class DescriptionCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(aliases=['abt', 'aboutme', 'description'])
    async def desc(self, ctx, user: discord.User = None):
        """Shows a user's profile description with their avatar and username"""
        # If no user is mentioned, use the command author
        if user is None:
            user = ctx.author

        # Fetch the user's profile (needed for about me/bio)
        try:
            # For Discord.py 2.0+, we need to fetch the user profile
            if isinstance(ctx.channel, discord.DMChannel):
                profile = None  # Can't fetch profile in DMs
            else:
                profile = await user.fetch_profile() if hasattr(user, 'fetch_profile') else None
        except:
            profile = None

        # Create embed
        embed = discord.Embed(color=user.accent_color or discord.Color.blurple())
        
        # Set author with username and avatar
        embed.set_author(name=f"{user.name}'s about me", icon_url=user.display_avatar.url)
        
        # Get the about me/bio if available
        about_me = "No description set."
        if profile and profile.bio:
            about_me = profile.bio
        elif user == ctx.author:
            # Try to get the connected account description (for newer Discord versions)
            try:
                if user.public_flags.verified_bot_developer:
                    about_me = getattr(user, "description", "No description set.")
            except:
                pass

        # Add the about me field
        embed.add_field(name="About Me", value=about_me, inline=False)
        
        # Set thumbnail to user's avatar
        embed.set_thumbnail(url=user.display_avatar.url)
        
        # Set footer with user ID
        embed.set_footer(text=f"User ID: {user.id}")
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(DescriptionCog(bot))