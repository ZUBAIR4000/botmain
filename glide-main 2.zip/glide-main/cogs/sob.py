import discord
from discord.ext import commands
import json
import os
import asyncio
from collections import defaultdict

class SobTracker(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.data_file = 'data/sob_reactions.json'
        self.server_user_counts = defaultdict(lambda: defaultdict(int))
        self.server_counts = defaultdict(int)
        self.emoji_left = "<:leftarrow:1387448445270360206>"
        self.emoji_right = "<:rightarrow:1387448549670654122>"
        
        os.makedirs('data', exist_ok=True)
        self.load_data()

    def load_data(self):
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                self.server_user_counts = defaultdict(
                    lambda: defaultdict(int),
                    {gid: defaultdict(int, users) 
                     for gid, users in data.get('server_user_counts', {}).items()}
                )
                self.server_counts = defaultdict(int, data.get('server_counts', {}))

    def save_data(self):
        with open(self.data_file, 'w') as f:
            json.dump({
                'server_user_counts': {gid: dict(users) 
                                     for gid, users in self.server_user_counts.items()},
                'server_counts': dict(self.server_counts)
            }, f)

    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
        if str(reaction.emoji) == '😭' and not user.bot and reaction.message.guild:
            guild_id = str(reaction.message.guild.id)
            author_id = str(reaction.message.author.id)
            
            self.server_user_counts[guild_id][author_id] += 1
            self.server_counts[guild_id] += 1
            self.save_data()

    @commands.Cog.listener()
    async def on_reaction_remove(self, reaction, user):
        if str(reaction.emoji) == '😭' and not user.bot and reaction.message.guild:
            guild_id = str(reaction.message.guild.id)
            author_id = str(reaction.message.author.id)
            
            self.server_user_counts[guild_id][author_id] = max(0, 
                self.server_user_counts[guild_id][author_id] - 1)
            self.server_counts[guild_id] = max(0, self.server_counts[guild_id] - 1)
            self.save_data()

    @commands.command(aliases=['sobs'])
    async def sob(self, ctx, user: discord.User = None):
        """Show your 😭 count or another user's in this server"""
        target = user or ctx.author
        guild_id = str(ctx.guild.id)
        count = self.server_user_counts[guild_id].get(str(target.id), 0)
        
        embed = discord.Embed(
            description=f"_ _\n> 😭 {target.mention} has **{count}** sobs\n> -# try ,leaderboard\n_ _",
            color=discord.Color.from_rgb(255, 255, 255)
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(aliases=['sobstats'])
    async def sob_server(self, ctx):
        """Show this server's total 😭 count"""
        guild_id = str(ctx.guild.id)
        count = self.server_counts.get(guild_id, 0)
        
        embed = discord.Embed(
            description=f"_ _\n> This server has **{count}** total sobs\n_ _",
            color=discord.Color.from_rgb(255, 255, 255)
        )
        embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else None)
        await ctx.send(embed=embed)

    @commands.command(aliases=['sobclear'])
    @commands.has_permissions(manage_guild=True)
    async def sobreset(self, ctx, user: discord.User = None):
        """Reset sob counts (manage server required)"""
        guild_id = str(ctx.guild.id)
        if user:
            self.server_user_counts[guild_id][str(user.id)] = 0
            await ctx.send(f"Reset 😭 count for {user.mention} in this server")
        else:
            self.server_counts[guild_id] = 0
            self.server_user_counts[guild_id] = defaultdict(int)
            await ctx.send("Reset all sob counts in this server")
        self.save_data()

    @commands.command(aliases=['leaderboard_sobs', 'leaderboardsob', 'sobleaderboard'])
    async def leaderboard(self, ctx):
        """Show this server's top 😭 users"""
        guild_id = str(ctx.guild.id)
        guild_users = self.server_user_counts.get(guild_id, {})
        
        sorted_users = sorted(guild_users.items(), key=lambda x: x[1], reverse=True)
        
        pages = []
        for i in range(0, len(sorted_users), 10):
            page_users = sorted_users[i:i+10]
            description = ""
            for rank, (user_id, count) in enumerate(page_users, start=i+1):
                user = self.bot.get_user(int(user_id))
                username = user.name if user else f"Unknown User ({user_id})"
                description += f"{rank}. {username} - **{count}** sobs\n"
            
            embed = discord.Embed(
                title=f"😭 {ctx.guild.name} Sob Leaderboard",
                description=description,
                color=discord.Color.from_rgb(255, 255, 255)
            )
            embed.set_footer(text=f"Page {i//10 + 1}/{(len(sorted_users)-1)//10 + 1}")
            embed.set_author(name=ctx.author.name, icon_url=ctx.author.display_avatar.url)
            pages.append(embed)
        
        if not pages:
            return await ctx.send("No sob data available for this server yet.")
        
        current_page = 0
        message = await ctx.send(embed=pages[current_page])
        
        if len(pages) > 1:
            for emoji in [self.emoji_left, self.emoji_right]:
                await message.add_reaction(emoji)
            
            def check(reaction, reactor):
                return (
                    reactor == ctx.author
                    and str(reaction.emoji) in [self.emoji_left, self.emoji_right]
                    and reaction.message.id == message.id
                )
            
            while True:
                try:
                    reaction, reactor = await self.bot.wait_for('reaction_add', timeout=60.0, check=check)
                    
                    if str(reaction.emoji) == self.emoji_left and current_page > 0:
                        current_page -= 1
                    elif str(reaction.emoji) == self.emoji_right and current_page < len(pages) - 1:
                        current_page += 1
                    else:
                        continue
                    
                    await message.edit(embed=pages[current_page])
                    await message.remove_reaction(reaction.emoji, reactor)
                        
                except asyncio.TimeoutError:
                    await message.clear_reactions()
                    break

async def setup(bot):
    await bot.add_cog(SobTracker(bot))