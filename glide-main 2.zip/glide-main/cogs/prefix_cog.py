import discord
from discord.ext import commands
from utils import create_embed

class PrefixCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def prefix(self, ctx, new_prefix: str):
        """Change bot prefix"""
        # Validate prefix length
        if len(new_prefix) > 5:
            return await ctx.send(embed=create_embed("❌ Prefix too long (max 5 characters)"))
        
        # Store prefix
        self.bot.custom_prefixes[ctx.guild.id] = new_prefix
        await ctx.send(embed=create_embed(
            f"✅ Prefix set to `{new_prefix}`\n"
            f"Try `{new_prefix}ping`"
        ))

    @prefix.error
    async def prefix_error(self, ctx, error):
        if isinstance(error, commands.MissingRequiredArgument):
            current = self.bot.custom_prefixes.get(ctx.guild.id, self.bot.DEFAULT_PREFIX)
            await ctx.send(embed=create_embed(
                f"Current prefix: `{current}`\n"
                f"Usage: `{current}prefix <new_prefix>`"
            ))

async def setup(bot):
    await bot.add_cog(PrefixCog(bot))