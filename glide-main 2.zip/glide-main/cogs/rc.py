import discord
from discord.ext import commands

class RoleCreator(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="rc")
    @commands.has_permissions(manage_roles=True)
    async def create_role(self, ctx, base_role_id: int, *, new_role_name: str):
        """Create a new role under a specified base role"""
        # Get base role
        base_role = ctx.guild.get_role(base_role_id)
        if not base_role:
            return await ctx.send(f"❌ Role with ID `{base_role_id}` not found")
            
        # Check if bot can manage roles
        if not ctx.guild.me.guild_permissions.manage_roles:
            return await ctx.send("❌ I don't have permission to manage roles")
            
        # Check bot's top role position
        if ctx.guild.me.top_role <= base_role:
            return await ctx.send("❌ My top role must be higher than the base role to create a role under it")
            
        # Calculate position for new role
        new_position = base_role.position - 1 if base_role.position > 0 else 0
        
        try:
            # Create the new role
            new_role = await ctx.guild.create_role(
                name=new_role_name,
                reason=f"Created by {ctx.author} via ,rc command"
            )
            
            # Move the role to the correct position
            await new_role.edit(position=new_position)
            
            await ctx.send(
                f"✅ Created new role {new_role.mention} at position `{new_position}` "
                f"(under {base_role.mention} at position `{base_role.position}`)"
            )
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to move roles")
        except discord.HTTPException as e:
            await ctx.send(f"❌ Failed to create role: {str(e)}")

async def setup(bot):
    await bot.add_cog(RoleCreator(bot))