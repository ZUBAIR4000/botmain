import discord
from discord.ext import commands, tasks
import aiohttp
import json
import os
import asyncio
from datetime import datetime
import random
from bs4 import BeautifulSoup
import re

class PinterestCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.autopost_file = "pinterest_autopost.json"
        self.autopost_settings = self.load_autopost_settings()
        self.pinterest_session = aiohttp.ClientSession()
        self.is_spamming = False

    def load_autopost_settings(self):
        if os.path.exists(self.autopost_file):
            try:
                with open(self.autopost_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_autopost_settings(self):
        with open(self.autopost_file, 'w') as f:
            json.dump(self.autopost_settings, f, indent=4)

    def cog_unload(self):
        self.autopost_loop.cancel()
        self.spam_loop.cancel()
        asyncio.create_task(self.pinterest_session.close())

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def autopost(self, ctx, channel: discord.TextChannel, pinterest_url: str, interval_minutes: int = 60):
        """Start autoposting Pinterest suggestions to a channel"""
        # Validate the Pinterest URL
        if not pinterest_url.startswith("https://www.pinterest.com/"):
            return await ctx.send("Invalid Pinterest URL! Please provide a valid Pinterest URL.")
        
        # Create or get webhook for the channel
        webhook = None
        webhooks = await channel.webhooks()
        for wh in webhooks:
            if wh.user.id == self.bot.user.id:
                webhook = wh
                break
        
        if not webhook:
            webhook = await channel.create_webhook(
                name=self.bot.user.name,
                avatar=await self.bot.user.avatar.read()
            )
        
        # Save autopost settings
        channel_id = str(channel.id)
        self.autopost_settings[channel_id] = {
            'webhook_url': webhook.url,
            'pinterest_url': pinterest_url,
            'interval_minutes': interval_minutes,
            'last_posted': None,
            'posted_pins': [],
            'spam_mode': False
        }
        self.save_autopost_settings()
        
        # Start the autopost loop if it's not already running
        if not self.autopost_loop.is_running():
            self.autopost_loop.start()
        
        await ctx.send(f"✅ Autopost started! Pinterest suggestions from {pinterest_url} will be posted in {channel.mention} every {interval_minutes} minutes.")

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def autopostspam(self, ctx, channel: discord.TextChannel, pinterest_url: str):
        """Start spamming Pinterest suggestions as fast as possible"""
        # Validate the Pinterest URL
        if not pinterest_url.startswith("https://www.pinterest.com/"):
            return await ctx.send("Invalid Pinterest URL! Please provide a valid Pinterest URL.")
        
        # Create or get webhook for the channel
        webhook = None
        webhooks = await channel.webhooks()
        for wh in webhooks:
            if wh.user.id == self.bot.user.id:
                webhook = wh
                break
        
        if not webhook:
            webhook = await channel.create_webhook(
                name=self.bot.user.name,
                avatar=await self.bot.user.avatar.read()
            )
        
        # Save autopost settings with spam mode enabled
        channel_id = str(channel.id)
        self.autopost_settings[channel_id] = {
            'webhook_url': webhook.url,
            'pinterest_url': pinterest_url,
            'interval_minutes': 0,  # 0 means spam mode
            'last_posted': None,
            'posted_pins': [],
            'spam_mode': True
        }
        self.save_autopost_settings()
        
        # Start the spam loop if it's not already running
        if not self.spam_loop.is_running():
            self.spam_loop.start()
        
        self.is_spamming = True
        await ctx.send(f"🚀 SPAM MODE ACTIVATED! Pinterest suggestions from {pinterest_url} will be spammed in {channel.mention} as fast as possible!")

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def autopoststop(self, ctx, channel: discord.TextChannel = None):
        """Stop autoposting Pinterest suggestions"""
        if channel:
            channel_id = str(channel.id)
            if channel_id in self.autopost_settings:
                # Check if it's in spam mode
                if self.autopost_settings[channel_id].get('spam_mode', False):
                    self.is_spamming = False
                
                del self.autopost_settings[channel_id]
                self.save_autopost_settings()
                await ctx.send(f"✅ Autopost stopped for {channel.mention}.")
            else:
                await ctx.send(f"❌ No autopost found for {channel.mention}.")
        else:
            # Stop all autoposts
            if self.autopost_settings:
                self.is_spamming = False
                self.autopost_settings = {}
                self.save_autopost_settings()
                await ctx.send("✅ All autoposts stopped.")
            else:
                await ctx.send("❌ No autoposts are currently running.")

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def autopostlist(self, ctx):
        """List all active autoposts"""
        if not self.autopost_settings:
            return await ctx.send("❌ No autoposts are currently running.")
        
        embed = discord.Embed(title="Active Pinterest Autoposts", color=0xE60023)
        
        for channel_id, settings in self.autopost_settings.items():
            channel = self.bot.get_channel(int(channel_id))
            if channel:
                mode = "🚀 SPAM MODE" if settings.get('spam_mode', False) else f"Every {settings['interval_minutes']} minutes"
                last_posted = settings['last_posted'] or "Never"
                embed.add_field(
                    name=f"#{channel.name}",
                    value=f"URL: {settings['pinterest_url']}\nMode: {mode}\nLast Posted: {last_posted}",
                    inline=False
                )
        
        await ctx.send(embed=embed)

    async def fetch_pinterest_suggestions(self, pin_url):
        """Fetch Pinterest suggestions for a given pin using multiple methods"""
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
        try:
            # Try Method 1: Direct API call to get related pins
            pin_id = pin_url.split('/pin/')[-1].strip('/')
            api_url = f"https://www.pinterest.com/resource/RelatedPinsResource/get/?source_url=%2Fpin%2F{pin_id}%2F&data=%7B%22options%22%3A%7B%22pin_id%22%3A%22{pin_id}%22%2C%22add_vase%22%3Atrue%2C%22field_set_key%22%3A%22react_grid_pin%22%2C%22is_own_profile_pins%22%3Afalse%2C%22page_size%22%3A25%2C%22prepend%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_={int(datetime.now().timestamp() * 1000)}"
            
            async with self.pinterest_session.get(api_url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    pins = self.parse_api_response(data)
                    if pins:
                        return pins, None
            
            # Try Method 2: Regular page scraping as fallback
            async with self.pinterest_session.get(pin_url, headers=headers) as response:
                if response.status == 200:
                    html = await response.text()
                    pins = self.parse_html_response(html, pin_url)
                    if pins:
                        return pins, None
            
            # Try Method 3: Search for similar content based on the pin
            search_pins = await self.search_related_content(pin_url)
            if search_pins:
                return search_pins, None
                
            return [], "No Pinterest suggestions found using any method"
                
        except Exception as e:
            return None, f"Error fetching Pinterest data: {str(e)}"

    def parse_api_response(self, data):
        """Parse the Pinterest API response"""
        pins = []
        try:
            if 'resource_response' in data and 'data' in data['resource_response']:
                for pin_data in data['resource_response']['data']:
                    if 'images' in pin_data and 'orig' in pin_data['images']:
                        pin_info = {
                            'url': f"https://www.pinterest.com/pin/{pin_data.get('id', '')}",
                            'image_url': pin_data['images']['orig']['url'],
                            'description': pin_data.get('description', 'Pinterest Suggestion') or 'Pinterest Suggestion',
                            'id': pin_data.get('id', hash(pin_data['images']['orig']['url']))
                        }
                        pins.append(pin_info)
        except Exception as e:
            print(f"Error parsing API response: {e}")
        
        return pins

    def parse_html_response(self, html, original_url):
        """Parse HTML response for Pinterest data"""
        pins = []
        try:
            soup = BeautifulSoup(html, 'html.parser')
            
            # Look for JSON data in script tags
            script_tags = soup.find_all('script')
            for script in script_tags:
                if script.string and '__PWS_DATA__' in script.string:
                    try:
                        # Extract the JSON part
                        json_str = script.string.split('__PWS_DATA__ = ')[-1].split(';')[0].strip()
                        data = json.loads(json_str)
                        
                        # Navigate through the complex JSON structure
                        if 'props' in data and 'initialReduxState' in data['props']:
                            redux_state = data['props']['initialReduxState']
                            if 'pins' in redux_state:
                                for pin_id, pin_data in redux_state['pins'].items():
                                    if 'images' in pin_data and 'orig' in pin_data['images']:
                                        pin_info = {
                                            'url': f"https://www.pinterest.com/pin/{pin_id}",
                                            'image_url': pin_data['images']['orig']['url'],
                                            'description': pin_data.get('description', 'Pinterest Suggestion') or 'Pinterest Suggestion',
                                            'id': pin_id
                                        }
                                        pins.append(pin_info)
                    except:
                        continue
            
            # If no pins found in JSON, try to find image tags
            if not pins:
                img_tags = soup.find_all('img', src=True)
                for img in img_tags:
                    src = img['src']
                    if 'pinimg.com' in src and ('/736x/' in src or '/564x/' in src or '/474x/' in src):
                        pin_info = {
                            'url': original_url,
                            'image_url': src,
                            'description': img.get('alt', 'Pinterest Suggestion') or 'Pinterest Suggestion',
                            'id': hash(src)
                        }
                        pins.append(pin_info)
                        
        except Exception as e:
            print(f"Error parsing HTML: {e}")
        
        return pins

    async def search_related_content(self, pin_url):
        """Search for related content as a fallback"""
        pins = []
        try:
            # Extract potential keywords from URL for search
            pin_id = pin_url.split('/pin/')[-1].strip('/')
            search_url = f"https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D{pin_id}%26rs%3Dtyped%26term_meta%5B%5D%3D{pin_id}%7Ctyped&data=%7B%22options%22%3A%7B%22query%22%3A%22{pin_id}%22%2C%22scope%22%3A%22pins%22%2C%22bookmarks%22%3A%5B%22%22%5D%7D%2C%22context%22%3A%7B%7D%7D&_={int(datetime.now().timestamp() * 1000)}"
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            async with self.pinterest_session.get(search_url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    if 'resource_response' in data and 'data' in data['resource_response']:
                        for item in data['resource_response']['data']['results']:
                            if 'images' in item and 'orig' in item['images']:
                                pin_info = {
                                    'url': f"https://www.pinterest.com/pin/{item.get('id', '')}",
                                    'image_url': item['images']['orig']['url'],
                                    'description': item.get('description', 'Pinterest Suggestion') or 'Pinterest Suggestion',
                                    'id': item.get('id', hash(item['images']['orig']['url']))
                                }
                                pins.append(pin_info)
        
        except Exception as e:
            print(f"Error in search fallback: {e}")
        
        return pins

    @tasks.loop(minutes=1.0)
    async def autopost_loop(self):
        """Background task to autopost Pinterest suggestions"""
        if not self.autopost_settings:
            return
        
        current_time = datetime.utcnow().isoformat()
        
        for channel_id, settings in self.autopost_settings.items():
            # Skip if in spam mode (handled by spam_loop)
            if settings.get('spam_mode', False):
                continue
                
            # Check if it's time to post
            last_posted = settings.get('last_posted')
            interval_minutes = settings.get('interval_minutes', 60)
            
            if last_posted:
                last_posted_dt = datetime.fromisoformat(last_posted)
                time_diff = (datetime.utcnow() - last_posted_dt).total_seconds() / 60
                if time_diff < interval_minutes:
                    continue
            
            # Fetch Pinterest suggestions
            pinterest_url = settings['pinterest_url']
            pins, error = await self.fetch_pinterest_suggestions(pinterest_url)
            
            if error:
                print(f"Error fetching Pinterest suggestions: {error}")
                continue
            
            if not pins:
                print(f"No Pinterest suggestions found for {pinterest_url}")
                continue
            
            # Filter out already posted pins
            posted_pins = settings.get('posted_pins', [])
            new_pins = [pin for pin in pins if pin['id'] not in posted_pins]
            
            if not new_pins:
                # If all pins have been posted, reset the list
                new_pins = pins
                posted_pins = []
            
            # Select a random pin to post
            pin = random.choice(new_pins)
            
            # Create embed
            embed = discord.Embed(
                title="Pinterest Suggestion",
                description=pin['description'][:200] + "..." if len(pin['description']) > 200 else pin['description'],
                color=0xE60023,  # Pinterest red color
                url=pin['url']
            )
            embed.set_image(url=pin['image_url'])
            embed.set_footer(text="Powered by Pinterest")
            
            # Send via webhook
            webhook_url = settings['webhook_url']
            async with aiohttp.ClientSession() as session:
                webhook = discord.Webhook.from_url(webhook_url, session=session)
                try:
                    await webhook.send(embed=embed, username=self.bot.user.name, avatar_url=self.bot.user.avatar.url)
                    
                    # Update settings
                    posted_pins.append(pin['id'])
                    self.autopost_settings[channel_id]['last_posted'] = current_time
                    self.autopost_settings[channel_id]['posted_pins'] = posted_pins
                    self.save_autopost_settings()
                    
                except Exception as e:
                    print(f"Error sending webhook: {e}")

    @tasks.loop(seconds=2.0)  # Post every 2 seconds in spam mode
    async def spam_loop(self):
        """Background task to spam Pinterest suggestions as fast as possible"""
        if not self.autopost_settings or not self.is_spamming:
            return
        
        current_time = datetime.utcnow().isoformat()
        
        for channel_id, settings in self.autopost_settings.items():
            # Only process channels in spam mode
            if not settings.get('spam_mode', False):
                continue
                
            # Fetch Pinterest suggestions
            pinterest_url = settings['pinterest_url']
            pins, error = await self.fetch_pinterest_suggestions(pinterest_url)
            
            if error:
                print(f"Error fetching Pinterest suggestions: {error}")
                continue
            
            if not pins:
                print(f"No Pinterest suggestions found for {pinterest_url}")
                continue
            
            # Filter out already posted pins
            posted_pins = settings.get('posted_pins', [])
            new_pins = [pin for pin in pins if pin['id'] not in posted_pins]
            
            if not new_pins:
                # If all pins have been posted, reset the list
                new_pins = pins
                posted_pins = []
            
            # Select a random pin to post
            pin = random.choice(new_pins)
            
            # Create embed
            embed = discord.Embed(
                title="Pinterest Suggestion",
                description=pin['description'][:200] + "..." if len(pin['description']) > 200 else pin['description'],
                color=0xE60023,  # Pinterest red color
                url=pin['url']
            )
            embed.set_image(url=pin['image_url'])
            embed.set_footer(text="Powered by Pinterest")
            
            # Send via webhook
            webhook_url = settings['webhook_url']
            async with aiohttp.ClientSession() as session:
                webhook = discord.Webhook.from_url(webhook_url, session=session)
                try:
                    await webhook.send(embed=embed, username=self.bot.user.name, avatar_url=self.bot.user.avatar.url)
                    
                    # Update settings
                    posted_pins.append(pin['id'])
                    self.autopost_settings[channel_id]['last_posted'] = current_time
                    self.autopost_settings[channel_id]['posted_pins'] = posted_pins
                    self.save_autopost_settings()
                    
                except Exception as e:
                    print(f"Error sending webhook: {e}")
                    # If we're getting rate limited, wait a bit
                    if "rate limited" in str(e).lower():
                        await asyncio.sleep(5)

    @autopost_loop.before_loop
    async def before_autopost_loop(self):
        await self.bot.wait_until_ready()

    @spam_loop.before_loop
    async def before_spam_loop(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    await bot.add_cog(PinterestCog(bot))