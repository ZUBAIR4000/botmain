import discord
from discord.ext import commands
import json
import os
from typing import Dict, List, Optional

class HelpSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.command_data = self.load_command_data()
        self.help_sessions = {}

    def load_command_data(self) -> Dict:
        """Load command data from JSON file"""
        try:
            with open('command_data.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}
        except json.JSONDecodeError:
            return {}

    async def generate_command_embed(self, ctx, command_name: str, page: int = 0) -> discord.Embed:
        """Generate embed for a specific command"""
        command = self.command_data.get(command_name)
        if not command:
            return None
        
        # Get subcommands if available
        subcommands = command.get('subcommands', [])
        total_pages = len(subcommands) + 1
        
        # Create embed
        embed = discord.Embed(color=discord.Color.from_rgb(255, 255, 255))
        embed.set_author(name="Command Help", icon_url=self.bot.user.avatar.url)
        embed.title = f"`{command_name}`" + (f" (Page {page+1}/{total_pages})" if total_pages > 1 else "")
        
        # Main command info
        if page == 0:
            embed.description = command.get('description', 'N/A')
            
            # Aliases
            aliases = ', '.join(command.get('aliases', [])) or 'N/A'
            embed.add_field(name="Aliases", value=aliases, inline=True)
            
            # Permissions
            perms = ', '.join(command.get('permissions', [])) or 'N/A'
            embed.add_field(name="Permissions", value=perms, inline=True)
            
            # Usage
            usage = command.get('usage', 'N/A')
            embed.add_field(name="Usage", value=f"```{usage}```", inline=False)
        else:
            # Subcommand info
            subcommand = subcommands[page - 1]
            embed.description = subcommand.get('description', 'N/A')
            
            # Aliases
            aliases = ', '.join(subcommand.get('aliases', [])) or 'N/A'
            embed.add_field(name="Aliases", value=aliases, inline=True)
            
            # Permissions
            perms = ', '.join(subcommand.get('permissions', [])) or 'N/A'
            embed.add_field(name="Permissions", value=perms, inline=True)
            
            # Usage
            usage = subcommand.get('usage', 'N/A')
            embed.add_field(name="Usage", value=f"```{usage}```", inline=False)
        
        # Footer with user info
        embed.set_footer(text=f"{ctx.author.display_name}", icon_url=ctx.author.avatar.url)
        
        return embed

    @commands.command(name="help")
    async def help_command(self, ctx, *, command_name: Optional[str] = None):
        """Show help for commands"""
        self.command_data = self.load_command_data()  # <-- Reload data here
        if not command_name:
            # Send link to web interface
            await ctx.send("Commands @ https://glidebot.netlify.app/commands.html")
            return
        
        # Normalize command name
        command_name = command_name.lower()
        
        # Create view with buttons
        view = HelpView(ctx.author, command_name)
        embed = await self.generate_command_embed(ctx, command_name, 0)
        
        if not embed:
            await ctx.send(f"Command `{command_name}` not found.")
            return
        
        message = await ctx.send(embed=embed, view=view)
        self.help_sessions[message.id] = {
            'command': command_name,
            'page': 0,
            'message': message
        }

class HelpView(discord.ui.View):
    def __init__(self, requester: discord.User, command_name: str):
        super().__init__(timeout=120)
        self.requester = requester
        self.command_name = command_name

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Ensure only the requester can interact with buttons"""
        return interaction.user.id == self.requester.id

    @discord.ui.button(emoji="<:leftarrow:1387448445270360206>", style=discord.ButtonStyle.secondary)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.change_page(interaction, -1)

    @discord.ui.button(emoji="<:rightarrow:1387448549670654122>", style=discord.ButtonStyle.secondary)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.change_page(interaction, 1)

    @discord.ui.button(emoji="<:close:1387448637964947646>", style=discord.ButtonStyle.danger)
    async def close_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.message.delete()
        self.stop()

    async def change_page(self, interaction: discord.Interaction, direction: int):
        # Get current page from message
        help_cog = interaction.client.get_cog("HelpSystem")
        session = help_cog.help_sessions.get(interaction.message.id)
        
        if not session:
            await interaction.response.send_message("Session expired.", ephemeral=True)
            return
        
        # Calculate new page
        command = help_cog.command_data.get(self.command_name)
        total_pages = len(command.get('subcommands', [])) + 1
        new_page = (session['page'] + direction) % total_pages
        
        # Update session
        session['page'] = new_page
        help_cog.help_sessions[interaction.message.id] = session
        
        # Update embed
        embed = await help_cog.generate_command_embed(
            interaction.channel, 
            self.command_name, 
            new_page
        )
        
        if embed:
            await interaction.response.edit_message(embed=embed)

async def setup(bot):
    await bot.add_cog(HelpSystem(bot))
