import discord
from discord.ext import commands
import json
import os
from datetime import datetime
import asyncio

class AFKCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.afk_file = "afk_data.json"
        self.afk_data = self.load_afk_data()
        self.ping_count = {}  # Track pings per user
        self.recent_afk_commands = set()  # Track recent AFK commands to prevent immediate removal

    def load_afk_data(self):
        """Load AFK data from JSON file"""
        if os.path.exists(self.afk_file):
            try:
                with open(self.afk_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_afk_data(self):
        """Save AFK data to JSON file"""
        with open(self.afk_file, 'w') as f:
            json.dump(self.afk_data, f, indent=4)

    def format_duration(self, start_time):
        """Format time duration for display"""
        now = datetime.utcnow()
        start = datetime.fromisoformat(start_time)
        duration = now - start
        
        seconds = duration.total_seconds()
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        if hours >= 1:
            return f"{int(hours)}h {int(minutes)}m ago"
        elif minutes >= 1:
            return f"{int(minutes)}m {int(seconds)}s ago"
        else:
            return f"{int(seconds)}s ago"

    @commands.command(name='afk')
    async def afk(self, ctx, *, status=None):
        """Set your AFK status"""
        user_id = str(ctx.author.id)
        
        # Check if user is already AFK
        if user_id in self.afk_data:
            await ctx.send(f"{ctx.author.mention}: You are already AFK!")
            return
        
        # Set AFK data
        self.afk_data[user_id] = {
            'status': status,
            'start_time': datetime.utcnow().isoformat(),
            'guild_id': str(ctx.guild.id)
        }
        self.save_afk_data()
        
        # Initialize ping count
        self.ping_count[user_id] = 0
        
        # Add to recent AFK commands to prevent immediate removal
        self.recent_afk_commands.add(user_id)
        
        # Create response embed
        embed = discord.Embed(color=0xffffff)
        
        if status:
            embed.description = f"<:yes:1408771592292401232> {ctx.author.mention}: You are now AFK with status \"{status}\""
        else:
            embed.description = f"<:yes:1408771592292401232> {ctx.author.mention}: You are now AFK"
        
        afk_message = await ctx.send(embed=embed)
        
        # Remove from recent AFK commands after a short delay
        await asyncio.sleep(2)
        if user_id in self.recent_afk_commands:
            self.recent_afk_commands.remove(user_id)

    @commands.Cog.listener()
    async def on_message(self, message):
        """Handle AFK status checks and responses"""
        # Ignore bot messages (this prevents the AFK message from triggering removal)
        if message.author.bot:
            return
        
        user_id = str(message.author.id)
        
        # Check if user is returning from AFK
        if user_id in self.afk_data and user_id not in self.recent_afk_commands:
            # User is no longer AFK
            pings_received = self.ping_count.get(user_id, 0)
            
            # Remove AFK status
            afk_status = self.afk_data[user_id]['status']
            del self.afk_data[user_id]
            self.save_afk_data()
            
            # Send return message
            embed = discord.Embed(color=0xffffff)
            
            if pings_received == 0:
                embed.description = f"{message.author.mention} AFK removed. You received **ZERO** pings."
            else:
                embed.description = f"{message.author.mention} AFK removed. You received **{pings_received}** pings."
            
            await message.channel.send(embed=embed)
            
            # Reset ping count
            if user_id in self.ping_count:
                del self.ping_count[user_id]
            
            return
        
        # Check if message mentions any AFK users
        for mentioned_user in message.mentions:
            mentioned_id = str(mentioned_user.id)
            
            if mentioned_id in self.afk_data:
                # User mentioned is AFK
                afk_info = self.afk_data[mentioned_id]
                status = afk_info.get('status', '')
                start_time = afk_info.get('start_time', '')
                
                # Increment ping count
                if mentioned_id in self.ping_count:
                    self.ping_count[mentioned_id] += 1
                else:
                    self.ping_count[mentioned_id] = 1
                
                # Create response embed
                embed = discord.Embed(color=0xffffff)
                
                if status:
                    duration = self.format_duration(start_time)
                    embed.description = f"{mentioned_user.mention} went AFK {duration}. \"{status}\""
                else:
                    duration = self.format_duration(start_time)
                    embed.description = f"{mentioned_user.mention} went AFK {duration}."
                
                # Send as a reply if it's a reply to the AFK user
                if message.reference:
                    try:
                        replied_message = await message.channel.fetch_message(message.reference.message_id)
                        if replied_message.author.id == mentioned_user.id:
                            await message.reply(embed=embed, mention_author=False)
                            return
                    except:
                        pass  # If we can't fetch the message, just send a regular message
                
                await message.channel.send(embed=embed)

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        """Handle edited messages that might mention AFK users"""
        # Only process if the content changed and author is not a bot
        if before.content != after.content and not after.author.bot:
            await self.on_message(after)

async def setup(bot):
    await bot.add_cog(AFKCog(bot))