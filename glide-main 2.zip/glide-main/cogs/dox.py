import discord
import asyncio
from discord.ext import commands

class DoxCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.social_platforms = {
            "Instagram": "https://instagram.com/{}",
            "Twitter": "https://twitter.com/{}",
            "Facebook": "https://facebook.com/{}",
            "TikTok": "https://tiktok.com/@{}",
            "Snapchat": "https://snapchat.com/add/{}",
            "YouTube": "https://youtube.com/{}",
            "LinkedIn": "https://linkedin.com/in/{}",
            "GitHub": "https://github.com/{}",
            "Reddit": "https://reddit.com/user/{}",
            "Twitch": "https://twitch.tv/{}"
        }

    def clean_username(self, username):
        """Clean username for URL use"""
        # Remove spaces and special characters
        return ''.join(char for char in username if char.isalnum()).lower()

    @commands.command(name="dox")
    async def dox_user(self, ctx, user: discord.Member = None):
        """Find social media profiles associated with a username"""
        if user is None:
            user = ctx.author

        # Send initial loading message
        loading_msg = await ctx.send(
            f"<a:loading_circle:1387477958570148021> searching for {user.display_name}'s data from darkweb database"
        )
        # Simulate search time
        await asyncio.sleep(5)
        
        # Clean username for URL (use user's username instead of display name)
        clean_name = self.clean_username(user.name)
        
        # Generate social media links
        socials = []
        for platform, url_template in self.social_platforms.items():
            socials.append(f"**{platform}:** [**{clean_name}**]({url_template.format(clean_name)})")

        # Create result embed
        embed = discord.Embed(
            title=f"🔍 Social Media Profiles for {user.display_name}",
            description="\n".join(socials),
            color=0x3498db
        )
        
        # Edit the original message with results
        await loading_msg.edit(content=None, embed=embed)

async def setup(bot):
    await bot.add_cog(DoxCommand(bot))
