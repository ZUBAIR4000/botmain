import discord
from discord.ext import commands
from collections import defaultdict

class NitroDetectorCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.user_message_counts = defaultdict(int)
        self.boost_reminder_sent = set()

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if member.premium_since is not None:  # User has nitro
            self.user_message_counts[member.id] = 0
            self.boost_reminder_sent.discard(member.id)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
            
        if message.author.id in self.user_message_counts:
            self.user_message_counts[message.author.id] += 1
            
            if self.user_message_counts[message.author.id] >= 10 and message.author.id not in self.boost_reminder_sent:
                self.boost_reminder_sent.add(message.author.id)
                await message.channel.send(
                    f"{message.author.mention} boost the server for custom **gradient** roles, "
                    f"**immunity**, **image perms** and [more](https://discord.com/channels/1267031864539873372/1302392157918990367)"
                )

async def setup(bot):
    await bot.add_cog(NitroDetectorCog(bot))