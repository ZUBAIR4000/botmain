import discord
from discord.ext import commands
import random

class PP(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(aliases=["dih"])
    async def pp(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        size = random.randint(0, 20)
        pp_display = "8" + "=" * size + "D"
        await ctx.send(f"**{user.name}'s pp 🤭:** {pp_display}")

    @commands.command(name="rpp")
    async def rpp_command(self, ctx, user: discord.Member = None):
        """
        Shows a random pp using custom emojis.
        Usage: ,rpp @user or ,rpp
        """
        user = user or ctx.author
        size = random.randint(0, 20)
        ball = "<:ball:1387498391319216258>"
        block = "<:block:1387498440572797039>"
        tip = "<:tip:1387498467928178849>"
        rpp_display = ball + (block * size) + tip
        await ctx.send(f"**{user.name}'s rtx pp 🤭:** {rpp_display}")

async def setup(bot):
    await bot.add_cog(PP(bot))
