import discord
from discord.ext import commands

class VoiceChatCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_vcs = set()

    @commands.command()
    async def vcjoin(self, ctx, *, channel: discord.VoiceChannel):
        """Make the bot join a voice channel"""
        if channel.id in self.active_vcs:
            await ctx.send("I'm already in that VC!")
            return
            
        try:
            await channel.connect()
            self.active_vcs.add(channel.id)
            await ctx.send(f"Joined {channel.mention}!")
        except Exception as e:
            await ctx.send(f"Failed to join: {e}")

    @commands.command(name='clearvcjoin', aliases=['cvcjoin'])
    async def clearvcjoin(self, ctx):
        """Make the bot leave all voice channels"""
        for channel_id in list(self.active_vcs):
            channel = self.bot.get_channel(channel_id)
            if channel and channel.guild.voice_client:
                try:
                    await channel.guild.voice_client.disconnect()
                except Exception:
                    pass
                self.active_vcs.discard(channel_id)
                
        await ctx.send("Left all voice channels!")

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if member.id == self.bot.user.id and after.channel is None and before.channel:
            self.active_vcs.discard(before.channel.id)

async def setup(bot):
    await bot.add_cog(VoiceChatCog(bot))