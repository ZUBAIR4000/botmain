import discord
from discord.ext import commands
import asyncio

class AutoThread(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.processing = False

    @commands.command(name='comment')
    @commands.has_permissions(manage_threads=True)
    @commands.bot_has_permissions(manage_threads=True, send_messages_in_threads=True)
    async def create_comment_threads(self, ctx, channel: discord.TextChannel = None):
        """Create comment threads under all posts in a channel"""
        if not channel:
            return await ctx.send("❌ Please specify a channel: `,comment #channel`")
            
        if self.processing:
            return await ctx.send("⚠️ Already processing another channel")
            
        self.processing = True
        
        # Get confirmation
        embed = discord.Embed(
            title="Thread Creation Confirmation",
            description=f"This will create public threads under all messages in {channel.mention} that don't have threads.",
            color=discord.Color.blue()
        )
        embed.set_footer(text="Type 'confirm' to proceed or wait 30 seconds to cancel")
        confirm_msg = await ctx.send(embed=embed)
        
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.lower() == 'confirm'
            
        try:
            await self.bot.wait_for('message', check=check, timeout=30)
        except asyncio.TimeoutError:
            self.processing = False
            return await confirm_msg.edit(content="cancelled", embed=None)
            
        # Start processing
        progress_msg = await ctx.send(f"<a:loading_circle:1387477958570148021> configuring")
        
        count = 0
        async for message in channel.history(limit=200):
            if not message.flags.has_thread and not message.is_system():
                try:
                    thread = await message.create_thread(
                        name=f"{message.author.display_name}'s Comments",
                        auto_archive_duration=10080,  # 7 days
                        reason="Auto thread creation"
                    )
                    await thread.send("Leave a comment")
                    count += 1
                    await asyncio.sleep(1)  # Rate limit protection
                    
                    # Update progress every 10 threads
                    if count % 10 == 0:
                        await progress_msg.edit(content=f"<a:loading_circle:1387477958570148021> Created {count} threads.")
                        
                except discord.HTTPException as e:
                    print(f" {e}")
                    continue
                    
        # Final result
        self.processing = False
        await progress_msg.edit(content=f"<:yes1:1389288766291574804> created {count} threads {channel.mention}")

    @create_comment_threads.error
    async def thread_error(self, ctx, error):
        self.processing = False
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("no")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("nuh uh")

async def setup(bot):
    await bot.add_cog(AutoThread(bot))