import discord
from discord.ext import commands, tasks
import json
import random
import asyncio
from datetime import datetime, timedelta
import os

class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.data_file = "economy.json"
        self.user_data = {}
        self.load_data()
        
        # Start daily streak reset task
        self.reset_daily_streaks.start()
        
        # Predefined thumbnail URL
        self.balance_thumbnail = "https://i.pinimg.com/1200x/40/46/f4/4046f4e0f41be7732e4f2c92d0f06712.jpg"
        
    def load_data(self):
        """Load user data from JSON file"""
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r') as f:
                self.user_data = json.load(f)
        else:
            self.user_data = {}
    
    def save_data(self):
        """Save user data to JSON file"""
        with open(self.data_file, 'w') as f:
            json.dump(self.user_data, f, indent=4)
    
    def get_user_data(self, user_id):
        """Get or create user data entry"""
        user_id = str(user_id)
        if user_id not in self.user_data:
            self.user_data[user_id] = {
                "cash": 0,
                "card": 0,
                "last_daily": None,
                "daily_streak": 0,
                "last_bonus": None,
                "bonus_streak": 0,
                "last_strip": None,
                "last_steal": {},
                "daily_base": 2000,
                "bonus_base": 1000
            }
        return self.user_data[user_id]
    
    def can_claim(self, last_claim, cooldown_hours):
        """Check if user can claim a reward"""
        if last_claim is None:
            return True
        last_claim_dt = datetime.fromisoformat(last_claim)
        return datetime.utcnow() > last_claim_dt + timedelta(hours=cooldown_hours)
    
    def get_cooldown(self, last_claim, cooldown_hours):
        """Get remaining cooldown time"""
        if last_claim is None:
            return "Now"
        last_claim_dt = datetime.fromisoformat(last_claim)
        next_claim = last_claim_dt + timedelta(hours=cooldown_hours)
        remaining = next_claim - datetime.utcnow()
        return f"{int(remaining.total_seconds() // 3600)}h {int((remaining.total_seconds() % 3600) // 60)}m"
    
    def format_money(self, amount):
        """Format money with commas"""
        return f"${amount:,}"
    
    @tasks.loop(minutes=5)
    async def reset_daily_streaks(self):
        """Reset streaks if user misses daily claim"""
        now = datetime.utcnow()
        for user_id, data in self.user_data.items():
            # Daily streak reset
            if data["last_daily"]:
                last_daily = datetime.fromisoformat(data["last_daily"])
                if now > last_daily + timedelta(hours=48):
                    data["daily_streak"] = 0
                    data["daily_base"] = 2000
            
            # Bonus streak reset
            if data["last_bonus"]:
                last_bonus = datetime.fromisoformat(data["last_bonus"])
                if now > last_bonus + timedelta(hours=48):
                    data["bonus_streak"] = 0
                    data["bonus_base"] = 1000
        
        self.save_data()
    
    @reset_daily_streaks.before_loop
    async def before_reset_streaks(self):
        await self.bot.wait_until_ready()
    
    async def create_embed(self, ctx, title, description, color=discord.Color.default()):
        """Create a basic embed"""
        embed = discord.Embed(
            title=title,
            description=description,
            color=color
        )
        return embed
    
    async def send_balance_embed(self, ctx, member):
        """Send balance embed for a user"""
        user_data = self.get_user_data(member.id)
        
        embed = discord.Embed(color=discord.Color.blue())
        embed.set_author(
            name=f"{member.display_name}'s Balance",
            icon_url=member.display_avatar.url
        )
        
        embed.add_field(
            name=":pound: **Cash Balance:**",
            value=f"{self.format_money(user_data['cash'])}",
            inline=False
        )
        
        embed.add_field(
            name="<:cashapp:1399085109134495744> **Card Balance:**",
            value=f"{self.format_money(user_data['card'])}",
            inline=False
        )
        
        embed.set_thumbnail(url=self.balance_thumbnail)
        
        await ctx.send(embed=embed)
    
    @commands.command(aliases=['bal', 'cash', 'money'])
    async def balance(self, ctx, member: discord.Member = None):
        """Check your or another user's balance"""
        member = member or ctx.author
        await self.send_balance_embed(ctx, member)
    
    @commands.command()
    async def daily(self, ctx):
        """Claim your daily reward"""
        user_data = self.get_user_data(ctx.author.id)
        now = datetime.utcnow().isoformat()
        
        if not self.can_claim(user_data["last_daily"], 24):
            cooldown = self.get_cooldown(user_data["last_daily"], 24)
            embed = await self.create_embed(
                ctx,
                "⏳ Daily Cooldown",
                f"You can claim your next daily in {cooldown}",
                discord.Color.orange()
            )
            await ctx.send(embed=embed)
            return
        
        # Calculate reward based on streak
        base = user_data["daily_base"]
        reward = random.randint(base, base * 3)
        streak = user_data["daily_streak"] + 1
        
        # Update user data
        user_data["cash"] += reward
        user_data["last_daily"] = now
        user_data["daily_streak"] = streak
        user_data["daily_base"] = int(base * 1.5)  # Increase base for next time
        
        self.save_data()
        
        embed = await self.create_embed(
            ctx,
            "💰 Daily Reward Claimed!",
            f"You received **{self.format_money(reward)}**!\n"
            f"Streak: **{streak} days**\n"
            f"Next daily base: **{self.format_money(user_data['daily_base'])}**",
            discord.Color.green()
        )
        
        await ctx.send(embed=embed)
    
    @commands.command(aliases=['transfer', 'send'])
    async def give(self, ctx, member: discord.Member, amount: int):
        """Send money to another user with 7% tax"""
        if amount <= 0:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: You must send a positive amount",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
            
        sender_data = self.get_user_data(ctx.author.id)
        receiver_data = self.get_user_data(member.id)
        
        tax = max(10, int(amount * 0.07))  # At least $10 tax
        total = amount + tax
        
        if sender_data["cash"] < total:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: You need {self.format_money(total)} (Amount + Tax) but only have {self.format_money(sender_data['cash'])} cash",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        # Create confirmation embed
        embed = discord.Embed(
            title="💸 Transfer Confirmation",
            description=(
                f"You are about to send **{self.format_money(amount)}** to {member.mention}\n"
                f"Tax: **{self.format_money(tax)}**\n"
                f"Total deducted: **{self.format_money(total)}**"
            ),
            color=discord.Color.blue()
        )
        
        # Create view with buttons
        view = discord.ui.View()
        
        async def confirm_callback(interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("This is not your transaction!", ephemeral=True)
                return
                
            # Process transaction
            sender_data["cash"] -= total
            receiver_data["cash"] += amount
            
            self.save_data()
            
            # Update embed
            embed.title = None
            embed.description = f"<:yes1:1389288766291574804> {ctx.author.mention}: Sent **{self.format_money(amount)}** to {member.mention}\nTax paid: **{self.format_money(tax)}**"
            embed.color = discord.Color.green()
            
            # Disable buttons
            for item in view.children:
                item.disabled = True
                
            await interaction.response.edit_message(embed=embed, view=view)
            
            # Send notification to receiver
            try:
                notify_embed = discord.Embed(
                    description=f"<:yes1:1389288766291574804> {ctx.author.mention}: sent you **{self.format_money(amount)}**",
                    color=discord.Color.green()
                )
                await member.send(embed=notify_embed)
            except discord.Forbidden:
                pass
            
        async def cancel_callback(interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("This is not your transaction!", ephemeral=True)
                return
                
            # Update embed
            embed.title = None
            embed.description = f"<:no:1399080437556576356> {ctx.author.mention}: Transfer Cancelled"
            embed.color = discord.Color.red()
            
            # Disable buttons
            for item in view.children:
                item.disabled = True
                
            await interaction.response.edit_message(embed=embed, view=view)
        
        # Add buttons
        confirm_button = discord.ui.Button(label="Confirm", style=discord.ButtonStyle.green)
        confirm_button.callback = confirm_callback
        
        cancel_button = discord.ui.Button(label="Cancel", style=discord.ButtonStyle.red)
        cancel_button.callback = cancel_callback
        
        view.add_item(confirm_button)
        view.add_item(cancel_button)
        
        await ctx.send(embed=embed, view=view)
    
    @commands.command()
    async def bonus(self, ctx):
        """Claim your bonus reward"""
        user_data = self.get_user_data(ctx.author.id)
        now = datetime.utcnow().isoformat()
        
        # Change bonus cooldown to 3 hours
        if not self.can_claim(user_data["last_bonus"], 3):
            cooldown = self.get_cooldown(user_data["last_bonus"], 3)
            embed = await self.create_embed(
                ctx,
                "⏳ Bonus Cooldown",
                f"You can claim your next bonus in {cooldown}",
                discord.Color.orange()
            )
            await ctx.send(embed=embed)
            return
        
        # Calculate reward based on streak
        base = user_data["bonus_base"]
        reward = random.randint(base, base * 4)
        streak = user_data["bonus_streak"] + 1
        
        # Update user data
        user_data["cash"] += reward
        user_data["last_bonus"] = now
        user_data["bonus_streak"] = streak
        user_data["bonus_base"] = int(base * 1.5)  # Increase base for next time
        
        self.save_data()
        
        embed = await self.create_embed(
            ctx,
            "🎁 Bonus Reward Claimed!",
            f"You received **{self.format_money(reward)}**!\n"
            f"Streak: **{streak} days**\n"
            f"Next bonus base: **{self.format_money(user_data['bonus_base'])}**",
            discord.Color.green()
        )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def strip(self, ctx):
        """Claim your strip club reward"""
        user_data = self.get_user_data(ctx.author.id)
        now = datetime.utcnow().isoformat()
        
        # Change strip cooldown to 3 hours
        if not self.can_claim(user_data["last_strip"], 3):
            cooldown = self.get_cooldown(user_data["last_strip"], 3)
            embed = discord.Embed(
                description=f"⏳ {ctx.author.mention}: You can visit the strip club again in {cooldown}",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
            return
        
        # Calculate reward
        reward = random.randint(2000, 6000)
        
        # Update user data
        user_data["cash"] += reward
        user_data["last_strip"] = now
        
        self.save_data()
        
        embed = discord.Embed(
            description=f"💋 {ctx.author.mention}: You made **{self.format_money(reward)}** at the strip club!",
            color=discord.Color.white()
        )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def deposit(self, ctx, amount: str):
        """Deposit money to your card"""
        user_data = self.get_user_data(ctx.author.id)
        
        # Handle "all" or "max"
        if amount.lower() in ["all", "max"]:
            amount = user_data["cash"]
        else:
            try:
                amount = int(amount)
            except ValueError:
                embed = discord.Embed(
                    description=f"<:no:1399080437556576356> {ctx.author.mention}: Please enter a valid number or 'all'",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
        
        if amount <= 0:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: You must deposit a positive amount",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
            
        if user_data["cash"] < amount:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: insufficent funds!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        # Process deposit
        user_data["cash"] -= amount
        user_data["card"] += amount
        
        self.save_data()
        
        embed = discord.Embed(
            description=f"<:yes1:1389288766291574804> {ctx.author.mention}: Deposited **{self.format_money(amount)}** to your card",
            color=discord.Color.green()
        )
        
        await ctx.send(embed=embed)
    
    @commands.command()
    async def steal(self, ctx, member: discord.Member):
        """Attempt to steal from another user"""
        # Can't steal from yourself
        if member.id == ctx.author.id:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: You cant rob yourself silly!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
            
        thief_data = self.get_user_data(ctx.author.id)
        victim_data = self.get_user_data(member.id)
        
        # Check victim has cash
        if victim_data["cash"] <= 0:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: {member.display_name} has no cash to steal!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
            
        # Check cooldown for this victim
        last_steal = thief_data["last_steal"].get(str(member.id))
        now = datetime.utcnow().isoformat()
        
        if last_steal and not self.can_claim(last_steal, 3):
            cooldown = self.get_cooldown(last_steal, 3)
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: You can steal again in {cooldown}",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
            return
        
        # Update cooldown
        thief_data["last_steal"][str(member.id)] = now
        
        # 30% chance of success
        if random.random() <= 0.3:
            # Successful steal
            steal_percent = random.randint(1, 50) / 100
            amount = min(victim_data["cash"], int(victim_data["cash"] * steal_percent))
            
            victim_data["cash"] -= amount
            thief_data["cash"] += amount
            
            self.save_data()
            
            embed = discord.Embed(
                description=f"<:yes1:1389288766291574804> {ctx.author.mention}: You stole **{self.format_money(amount)}** from {member.mention} ({steal_percent*100:.0f}% of their cash!)",
                color=discord.Color.green()
            )
        else:
            # Failed steal - 35% penalty
            penalty_percent = 0.35
            penalty = 0
            
            # Take from cash first, then card
            if thief_data["cash"] > 0:
                penalty = min(thief_data["cash"], int(thief_data["cash"] * penalty_percent))
                thief_data["cash"] -= penalty
            else:
                penalty = min(thief_data["card"], int(thief_data["card"] * penalty_percent))
                thief_data["card"] -= penalty
                
            self.save_data()
            
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: You were caught trying to steal and are fined {self.format_money(penalty)}",
                color=discord.Color.red()
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(aliases=['cf'])
    async def coinflip(self, ctx, amount: str, choice: str = None):
        """Flip a coin for double or nothing"""
        user_data = self.get_user_data(ctx.author.id)
        
        # Handle "all" or "max"
        if amount.lower() in ["all", "max"]:
            amount = user_data["cash"]
        else:
            try:
                amount = int(amount)
            except ValueError:
                embed = discord.Embed(
                    description=f"<:no:1399080437556576356> {ctx.author.mention}: Please enter a valid number or 'all'",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return
        
        if amount <= 0:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: invalid amount",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
            
        if user_data["cash"] < amount:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: You only have {self.format_money(user_data['cash'])} cash",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        # Validate choice
        choice = choice.lower() if choice else None
        if choice not in [None, "h", "head", "heads", "t", "tail", "tails"]:
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: Please choose heads (h) or tails (t)",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
            
        # Set default choice if not provided
        if choice is None:
            choice = random.choice(["heads", "tails"])
            embed = discord.Embed(
                description=f"<:yes1:1389288766291574804> {ctx.author.mention}: You didn't choose a side, so I chose **{choice}** for you!",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            await asyncio.sleep(1)
        
        # Simplify choice
        if choice in ["h", "head", "heads"]:
            choice = "heads"
        else:
            choice = "tails"
        
        # Send initial embed
        embed = discord.Embed(
            title=f"🪙 Flipping Coin for {self.format_money(amount)}...",
            description=f"Your choice: **{choice.capitalize()}**",
            color=discord.Color.blue()
        )
        message = await ctx.send(embed=embed)
        await asyncio.sleep(2)
        
        # Flip coin
        result = random.choice(["heads", "tails"])
        
        # Determine outcome
        if result == choice:
            # Win
            user_data["cash"] += amount
            embed = discord.Embed(
                description=f"<:yes1:1389288766291574804> {ctx.author.mention}: The coin landed on **{result.capitalize()}**! You won **{self.format_money(amount)}**!",
                color=discord.Color.green()
            )
        else:
            # Lose
            user_data["cash"] -= amount
            embed = discord.Embed(
                description=f"<:no:1399080437556576356> {ctx.author.mention}: Coin landed on **{result.capitalize()}**. You lost {self.format_money(amount)}.",
                color=discord.Color.red()
            )
        
        self.save_data()
        
        await message.edit(embed=embed)

async def setup(bot):
    await bot.add_cog(Economy(bot))