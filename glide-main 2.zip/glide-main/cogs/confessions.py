import discord
from discord.ext import commands
import random
import datetime
from typing import Optional

class Confessions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.confession_channels = {}
        self.log_channels = {}
        self.confession_counters = {}
        self.notification_settings = {}
        self.persistent_views = {}

    def generate_random_color(self):
        return discord.Color(random.randint(0, 0xFFFFFF))

    @commands.group(name="confessions", aliases=["confession"], invoke_without_command=True)
    async def confessions(self, ctx):
        """Confession system management"""
        await ctx.send_help(ctx.command)

    @confessions.command(name="set")
    @commands.has_permissions(manage_guild=True)
    async def set_confession_channel(
        self, 
        ctx, 
        channel: discord.TextChannel, 
        log_channel: Optional[discord.TextChannel] = None, 
        starting_number: int = 1
    ):
        """Set the confession channel and optional log channel"""
        self.confession_channels[ctx.guild.id] = channel.id
        if log_channel:
            self.log_channels[ctx.guild.id] = log_channel.id
        self.confession_counters[ctx.guild.id] = starting_number
        
        embed = discord.Embed(
            title=f"Anonymous Confession (#{starting_number})",
            description="yo",
            color=self.generate_random_color()
        )
        
        view = discord.ui.View(timeout=None)
        view.add_item(ConfessionButton(self.bot, "Submit a Confession", discord.ButtonStyle.primary, "submit"))
        view.add_item(ConfessionButton(self.bot, "Reply", discord.ButtonStyle.secondary, "reply"))
        
        message = await channel.send(embed=embed, view=view)
        self.persistent_views[ctx.guild.id] = message.id
        
        await ctx.send(
            f"Confession channel set to {channel.mention}" + 
            (f" with logs in {log_channel.mention}" if log_channel else "") +
            f" starting at #{starting_number}"
        )

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if not interaction.data or "custom_id" not in interaction.data:
            return
            
        custom_id = interaction.data["custom_id"]
        
        if custom_id.startswith("confession_submit"):
            await self.handle_confession_submit(interaction)
        elif custom_id.startswith("confession_reply"):
            await self.handle_confession_reply(interaction)
        elif custom_id == "disable_notifications":
            await self.handle_disable_notifications(interaction)

    async def handle_confession_submit(self, interaction: discord.Interaction):
        modal = ConfessionModal(title="Submit a Confession")
        await interaction.response.send_modal(modal)
        await modal.wait()
        
        if not modal.content.value:
            return
        
        guild_id = interaction.guild.id
        confession_channel = self.bot.get_channel(self.confession_channels[guild_id])
        
        if guild_id in self.persistent_views:
            try:
                old_message = await confession_channel.fetch_message(self.persistent_views[guild_id])
                await old_message.edit(view=None)
            except:
                pass
        
        self.confession_counters[guild_id] += 1
        confession_id = self.confession_counters[guild_id]
        
        embed = discord.Embed(
            title=f"Anonymous Confession (#{confession_id})",
            description=modal.content.value,
            color=self.generate_random_color()
        )
        
        if modal.attachment_url.value:
            embed.set_image(url=modal.attachment_url.value)
        
        view = discord.ui.View(timeout=None)
        view.add_item(ConfessionButton(self.bot, "Submit a Confession", discord.ButtonStyle.primary, "submit"))
        view.add_item(ConfessionButton(self.bot, "Reply", discord.ButtonStyle.secondary, "reply"))
        
        message = await confession_channel.send(embed=embed, view=view)
        self.persistent_views[guild_id] = message.id
        
        if guild_id in self.log_channels:
            log_channel = self.bot.get_channel(self.log_channels[guild_id])
            if log_channel:
                log_embed = discord.Embed(
                    title=f"Confession Added (#{confession_id})",
                    description=f"[Link to Confession]({message.jump_url})\n\n{modal.content.value}",
                    color=discord.Color(0xFFC0CB)
                )
                log_embed.set_author(
                    name=str(interaction.user),
                    icon_url=interaction.user.display_avatar.url
                )
                log_embed.set_footer(
                    text=f"User ID: {interaction.user.id} • {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                )
                await log_channel.send(embed=log_embed)
        
        # ✅ Close the modal with a success message
        await interaction.followup.send("✅ Your confession was submitted anonymously.", ephemeral=True)

    async def handle_confession_reply(self, interaction: discord.Interaction):
        modal = ReplyModal(title="Reply to Confession")
        await interaction.response.send_modal(modal)
        await modal.wait()
        
        if not modal.reply.value:
            return
            
        guild_id = interaction.guild.id
        confession_channel = self.bot.get_channel(self.confession_channels[guild_id])
        
        confession_id = None
        if modal.confession_id.value and modal.confession_id.value.isdigit():
            confession_id = int(modal.confession_id.value)
        
        target_message = None
        if confession_id:
            async for message in confession_channel.history(limit=200):
                if message.embeds and message.embeds[0].title and f"#{confession_id}" in message.embeds[0].title:
                    target_message = message
                    break
        
        if not target_message:
            async for message in confession_channel.history(limit=1):
                if message.embeds and message.embeds[0].title and "Anonymous Confession" in message.embeds[0].title:
                    target_message = message
                    break
        
        if not target_message:
            await interaction.followup.send("Could not find confession to reply to.", ephemeral=True)
            return
        
        if not target_message.thread:
            thread = await target_message.create_thread(
                name=f"Replies to Confession #{confession_id}" if confession_id else "Replies to Confession"
            )
        else:
            thread = target_message.thread
        
        self.confession_counters[guild_id] += 1
        reply_id = self.confession_counters[guild_id]
        
        embed = discord.Embed(
            title=f"Confession Reply (#{reply_id})",
            description=modal.reply.value,
            color=self.generate_random_color()
        )

        # ✅ Do not add buttons on replies
        reply_message = await thread.send(embed=embed)
        
        if guild_id in self.log_channels:
            log_channel = self.bot.get_channel(self.log_channels[guild_id])
            if log_channel:
                log_embed = discord.Embed(
                    title=f"Confession Reply Added (#{reply_id})",
                    description=f"[Link to Reply]({reply_message.jump_url})\n\n{modal.reply.value}",
                    color=discord.Color(0xFFC0CB)
                )
                log_embed.set_author(
                    name=str(interaction.user),
                    icon_url=interaction.user.display_avatar.url
                )
                log_embed.set_footer(
                    text=f"User ID: {interaction.user.id} • {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                )
                await log_channel.send(embed=log_embed)
        
        original_author = None
        if guild_id in self.log_channels:
            log_channel = self.bot.get_channel(self.log_channels[guild_id])
            if log_channel:
                async for log_message in log_channel.history(limit=200):
                    if log_message.embeds and log_message.embeds[0].title and f"#{confession_id}" in log_message.embeds[0].title:
                        try:
                            original_author_id = int(log_message.embeds[0].footer.text.split("User ID: ")[1].split(" •")[0])
                            original_author = interaction.guild.get_member(original_author_id)
                        except:
                            continue
                        break
        
        if original_author and original_author.id != interaction.user.id:
            if str(original_author.id) not in self.notification_settings or self.notification_settings[str(original_author.id)]:
                try:
                    view = discord.ui.View(timeout=None)
                    view.add_item(DisableNotificationsButton())
                    
                    dm_embed = discord.Embed(
                        title="New Reply to Your Confession",
                        description=f"Someone replied to [your confession]({target_message.jump_url}).\n\n[Jump to reply]({reply_message.jump_url})",
                        color=discord.Color.blurple()
                    )
                    await original_author.send(embed=dm_embed, view=view)
                except:
                    pass

        # ✅ Close the modal with a success message
        await interaction.followup.send("✅ Your reply was submitted anonymously.", ephemeral=True)

    async def handle_disable_notifications(self, interaction: discord.Interaction):
        self.notification_settings[str(interaction.user.id)] = False
        await interaction.response.send_message(
            "You will no longer receive DM notifications for replies to your confessions.",
            ephemeral=True
        )

class ConfessionButton(discord.ui.Button):
    def __init__(self, bot, label, style, action_type):
        super().__init__(
            label=label,
            style=style,
            custom_id=f"confession_{action_type}"
        )
        self.bot = bot

    async def callback(self, interaction: discord.Interaction):
        pass  # Handled in on_interaction

class DisableNotificationsButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="Disable Notifications",
            style=discord.ButtonStyle.danger,
            custom_id="disable_notifications"
        )

    async def callback(self, interaction: discord.Interaction):
        pass  # Handled in on_interaction

class ConfessionModal(discord.ui.Modal):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        self.content = discord.ui.TextInput(
            label="Confession Content",
            placeholder="Type your confession here...",
            style=discord.TextStyle.long,
            required=True
        )
        self.add_item(self.content)
        
        self.attachment_url = discord.ui.TextInput(
            label="Attachment URL (Optional)",
            placeholder="Paste an image URL here if needed...",
            style=discord.TextStyle.short,
            required=False
        )
        self.add_item(self.attachment_url)

class ReplyModal(discord.ui.Modal):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        self.reply = discord.ui.TextInput(
            label="Reply",
            placeholder="Type your reply here...",
            style=discord.TextStyle.long,
            required=True
        )
        self.add_item(self.reply)
        
        self.confession_id = discord.ui.TextInput(
            label="Confession ID to reply to (Optional)",
            placeholder="Leave blank to reply to most recent confession",
            style=discord.TextStyle.short,
            required=False
        )
        self.add_item(self.confession_id)

async def setup(bot):
    await bot.add_cog(Confessions(bot))
