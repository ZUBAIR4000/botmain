import discord
from discord.ext import commands
import asyncio
import json
import os
from datetime import datetime, timedelta

class AntinukeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.antinuke_file = "antinuke_config.json"
        self.config = self.load_config()
        self.action_log = {}
        self.emoji = "<:antinuke_glide:1410789302312501278>"

    def load_config(self):
        """Load antinuke configuration from JSON file"""
        if os.path.exists(self.antinuke_file):
            try:
                with open(self.antinuke_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_config(self):
        """Save antinuke configuration to JSON file"""
        with open(self.antinuke_file, 'w') as f:
            json.dump(self.config, f, indent=4)

    def init_guild_config(self, guild_id):
        """Initialize default configuration for a guild"""
        if str(guild_id) not in self.config:
            self.config[str(guild_id)] = {
                'enabled': False,
                'modules': {
                    'massmention': False,
                    'webhook': False,
                    'bot': False,
                    'channel': False,
                    'members': False,
                    'role': False,
                    'spam': False
                },
                'whitelist': [],
                'action_log': {}
            }
            self.save_config()

    def is_whitelisted(self, guild_id, user_id):
        """Check if user is whitelisted or owner"""
        guild = self.bot.get_guild(guild_id)
        if not guild:
            return False
        
        # Check if user is guild owner
        if user_id == guild.owner_id:
            return True
        
        # Check if user is in whitelist
        if str(user_id) in self.config.get(str(guild_id), {}).get('whitelist', []):
            return True
        
        return False

    async def punish_user(self, guild, user, reason, channel=None):
        """Punish a user with timeout and role removal"""
        try:
            member = guild.get_member(user.id)
            if not member:
                return False
            
            # Remove all roles
            if len(member.roles) > 1:  # More than just @everyone
                try:
                    await member.edit(roles=[], reason=f"Antinuke: {reason}")
                except:
                    pass  # Couldn't remove roles
            
            # Timeout for 2 minutes
            try:
                timeout_until = datetime.utcnow() + timedelta(minutes=2)
                await member.timeout(timeout_until, reason=f"Antinuke: {reason}")
            except:
                pass  # Couldn't timeout
            
            # Send embed to channel if provided
            if channel:
                embed = discord.Embed(
                    description=f"{self.emoji} {user.mention} punished for {reason}",
                    color=0xff0000
                )
                await channel.send(embed=embed)
            
            # Send DM to whitelisted users and owner
            punishment_msg = f"{self.emoji} {user.mention} punished for {reason} in {guild.name}"
            
            # Notify owner
            try:
                owner = guild.owner
                if owner:
                    await owner.send(punishment_msg)
            except:
                pass
            
            # Notify whitelisted users
            for whitelist_id in self.config.get(str(guild.id), {}).get('whitelist', []):
                try:
                    whitelist_member = guild.get_member(int(whitelist_id))
                    if whitelist_member:
                        await whitelist_member.send(punishment_msg)
                except:
                    pass
            
            return True
        except Exception as e:
            print(f"Error punishing user: {e}")
            return False

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Handle new bot joins"""
        guild_id = member.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        if not guild_config.get('enabled', False) or not guild_config['modules'].get('bot', False):
            return
        
        # Check if joined member is a bot and not whitelisted
        if member.bot and not self.is_whitelisted(guild_id, member.id):
            try:
                # Kick and ban the bot
                await member.ban(reason="Unauthorized bot addition")
                await member.guild.unban(member, reason="Antinuke: Kicking unauthorized bot")
                
                # Send notification
                embed = discord.Embed(
                    description=f"{self.emoji} {member.mention} was kicked and banned for unauthorized bot addition",
                    color=0xff0000
                )
                
                # Find a channel to send the message
                for channel in member.guild.text_channels:
                    if channel.permissions_for(member.guild.me).send_messages:
                        await channel.send(embed=embed)
                        break
            except Exception as e:
                print(f"Error handling bot join: {e}")

    @commands.Cog.listener()
    async def on_webhook_update(self, channel):
        """Handle webhook creation"""
        guild_id = channel.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        if not guild_config.get('enabled', False) or not guild_config['modules'].get('webhook', False):
            return
        
        # Check recent webhook creations
        try:
            async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.webhook_create):
                if (datetime.utcnow() - entry.created_at).total_seconds() < 10:  # Within last 10 seconds
                    if not self.is_whitelisted(guild_id, entry.user.id):
                        # Delete the webhook
                        webhooks = await channel.webhooks()
                        for webhook in webhooks:
                            if webhook.user == entry.user:
                                await webhook.delete(reason="Antinuke: Unauthorized webhook creation")
                        
                        # Punish the user
                        await self.punish_user(channel.guild, entry.user, "unauthorized webhook creation", channel)
                        break
        except:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        """Handle channel creation"""
        guild_id = channel.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        if not guild_config.get('enabled', False) or not guild_config['modules'].get('channel', False):
            return
        
        # Check recent channel creations
        try:
            async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_create):
                if (datetime.utcnow() - entry.created_at).total_seconds() < 10:  # Within last 10 seconds
                    if not self.is_whitelisted(guild_id, entry.user.id):
                        # Delete the channel
                        await channel.delete(reason="Antinuke: Unauthorized channel creation")
                        
                        # Punish the user
                        await self.punish_user(channel.guild, entry.user, "unauthorized channel creation", channel.guild.system_channel)
                        break
        except:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        """Handle channel deletion"""
        guild_id = channel.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        if not guild_config.get('enabled', False) or not guild_config['modules'].get('channel', False):
            return
        
        # Check recent channel deletions
        try:
            async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_delete):
                if (datetime.utcnow() - entry.created_at).total_seconds() < 10:  # Within last 10 seconds
                    if not self.is_whitelisted(guild_id, entry.user.id):
                        # Punish the user
                        await self.punish_user(channel.guild, entry.user, "unauthorized channel deletion", channel.guild.system_channel)
                        break
        except:
            pass

    @commands.Cog.listener()
    async def on_message(self, message):
        """Handle mass mentions and spam"""
        if message.author.bot:
            return
        
        guild_id = message.guild.id if message.guild else None
        if not guild_id:
            return
        
        self.init_guild_config(guild_id)
        guild_config = self.config.get(str(guild_id), {})
        
        # Check for mass mentions
        if guild_config.get('enabled', False) and guild_config['modules'].get('massmention', False):
            if not self.is_whitelisted(guild_id, message.author.id):
                mention_count = sum(1 for word in message.content.split() if word in ['@everyone', '@here'])
                if mention_count > 0:
                    await self.punish_user(message.guild, message.author, "mentioning the server", message.channel)
                    return
        
        # Check for spam
        if guild_config.get('enabled', False) and guild_config['modules'].get('spam', False):
            if not self.is_whitelisted(guild_id, message.author.id):
                user_id = str(message.author.id)
                
                # Initialize spam tracking
                if user_id not in self.action_log:
                    self.action_log[user_id] = {'messages': [], 'last_warning': None}
                
                # Add message to log
                self.action_log[user_id]['messages'].append(datetime.utcnow())
                
                # Remove messages older than 10 seconds
                self.action_log[user_id]['messages'] = [
                    msg_time for msg_time in self.action_log[user_id]['messages']
                    if (datetime.utcnow() - msg_time).total_seconds() < 10
                ]
                
                # Check if超过8 messages in 10 seconds
                if len(self.action_log[user_id]['messages']) >= 8:
                    # Check if we recently warned this user
                    last_warning = self.action_log[user_id].get('last_warning')
                    if not last_warning or (datetime.utcnow() - last_warning).total_seconds() > 30:
                        await self.punish_user(message.guild, message.author, "spamming", message.channel)
                        self.action_log[user_id]['last_warning'] = datetime.utcnow()

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Handle mass kicks/bans"""
        guild_id = member.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        if not guild_config.get('enabled', False) or not guild_config['modules'].get('members', False):
            return
        
        # Check recent ban/kick actions
        try:
            async for entry in member.guild.audit_logs(limit=10, action=discord.AuditLogAction.ban):
                if (datetime.utcnow() - entry.created_at).total_seconds() < 10:  # Within last 10 seconds
                    if not self.is_whitelisted(guild_id, entry.user.id):
                        # Track actions per user
                        user_id = str(entry.user.id)
                        if user_id not in self.action_log:
                            self.action_log[user_id] = {'bans': []}
                        
                        self.action_log[user_id]['bans'].append(datetime.utcnow())
                        
                        # Remove actions older than 10 seconds
                        self.action_log[user_id]['bans'] = [
                            action_time for action_time in self.action_log[user_id]['bans']
                            if (datetime.utcnow() - action_time).total_seconds() < 10
                        ]
                        
                        # Check if超过3 bans in 10 seconds
                        if len(self.action_log[user_id]['bans']) >= 3:
                            await self.punish_user(member.guild, entry.user, "mass banning", member.guild.system_channel)
                            break
        except:
            pass
        
        try:
            async for entry in member.guild.audit_logs(limit=10, action=discord.AuditLogAction.kick):
                if (datetime.utcnow() - entry.created_at).total_seconds() < 10:  # Within last 10 seconds
                    if not self.is_whitelisted(guild_id, entry.user.id):
                        # Track actions per user
                        user_id = str(entry.user.id)
                        if user_id not in self.action_log:
                            self.action_log[user_id] = {'kicks': []}
                        
                        self.action_log[user_id]['kicks'].append(datetime.utcnow())
                        
                        # Remove actions older than 10 seconds
                        self.action_log[user_id]['kicks'] = [
                            action_time for action_time in self.action_log[user_id]['kicks']
                            if (datetime.utcnow() - action_time).total_seconds() < 10
                        ]
                        
                        # Check if超过3 kicks in 10 seconds
                        if len(self.action_log[user_id]['kicks']) >= 3:
                            await self.punish_user(member.guild, entry.user, "mass kicking", member.guild.system_channel)
                            break
        except:
            pass

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        """Handle role creation"""
        guild_id = role.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        if not guild_config.get('enabled', False) or not guild_config['modules'].get('role', False):
            return
        
        # Check recent role creations
        try:
            async for entry in role.guild.audit_logs(limit=5, action=discord.AuditLogAction.role_create):
                if (datetime.utcnow() - entry.created_at).total_seconds() < 10:  # Within last 10 seconds
                    if not self.is_whitelisted(guild_id, entry.user.id):
                        # Check if role has dangerous permissions
                        dangerous_perms = [
                            role.permissions.administrator,
                            role.permissions.manage_guild,
                            role.permissions.manage_roles,
                            role.permissions.manage_channels,
                            role.permissions.manage_webhooks,
                            role.permissions.ban_members,
                            role.permissions.kick_members
                        ]
                        
                        if any(dangerous_perms):
                            # Delete the role
                            await role.delete(reason="Antinuke: Dangerous role creation")
                            
                            # Punish the user
                            await self.punish_user(role.guild, entry.user, "creating dangerous role", role.guild.system_channel)
                        break
        except:
            pass

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        """Handle role deletion"""
        guild_id = role.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        if not guild_config.get('enabled', False) or not guild_config['modules'].get('role', False):
            return
        
        # Check recent role deletions
        try:
            async for entry in role.guild.audit_logs(limit=5, action=discord.AuditLogAction.role_delete):
                if (datetime.utcnow() - entry.created_at).total_seconds() < 10:  # Within last 10 seconds
                    if not self.is_whitelisted(guild_id, entry.user.id):
                        # Punish the user
                        await self.punish_user(role.guild, entry.user, "unauthorized role deletion", role.guild.system_channel)
                        break
        except:
            pass

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        """Handle role permission changes"""
        guild_id = after.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        if not guild_config.get('enabled', False) or not guild_config['modules'].get('role', False):
            return
        
        # Check if permissions were added
        if before.permissions != after.permissions:
            # Check recent role updates
            try:
                async for entry in after.guild.audit_logs(limit=5, action=discord.AuditLogAction.role_update):
                    if (datetime.utcnow() - entry.created_at).total_seconds() < 10:  # Within last 10 seconds
                        if not self.is_whitelisted(guild_id, entry.user.id):
                            # Check if dangerous permissions were added
                            dangerous_perms = [
                                after.permissions.administrator,
                                after.permissions.manage_guild,
                                after.permissions.manage_roles,
                                after.permissions.manage_channels,
                                after.permissions.manage_webhooks,
                                after.permissions.ban_members,
                                after.permissions.kick_members
                            ]
                            
                            if any(dangerous_perms):
                                # Revert role permissions
                                await after.edit(permissions=before.permissions, reason="Antinuke: Dangerous permission change")
                                
                                # Punish the user
                                await self.punish_user(after.guild, entry.user, "adding dangerous permissions to role", after.guild.system_channel)
                            break
            except:
                pass

    @commands.group(name='antinuke', invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def antinuke(self, ctx):
        """Antinuke system management"""
        await ctx.send_help(ctx.command)

    @antinuke.command(name='enable')
    @commands.has_permissions(administrator=True)
    async def antinuke_enable(self, ctx, module: str = None):
        """Enable antinuke modules"""
        guild_id = ctx.guild.id
        self.init_guild_config(guild_id)
        
        if module is None:
            # Enable all modules
            for mod in self.config[str(guild_id)]['modules']:
                self.config[str(guild_id)]['modules'][mod] = True
            self.config[str(guild_id)]['enabled'] = True
            self.save_config()
            
            embed = discord.Embed(
                description=f"{self.emoji} {ctx.author.mention} Antinuke (all features) has been activated for your server",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        else:
            # Enable specific module
            module = module.lower()
            aliases = {
                'mention': 'massmention',
                'massmention': 'massmention',
                'webhook': 'webhook',
                'bot': 'bot',
                'channel': 'channel',
                'members': 'members',
                'role': 'role',
                'spam': 'spam'
            }
            
            if module in aliases:
                module_key = aliases[module]
                if module_key in self.config[str(guild_id)]['modules']:
                    self.config[str(guild_id)]['modules'][module_key] = True
                    self.config[str(guild_id)]['enabled'] = True
                    self.save_config()
                    
                    embed = discord.Embed(
                        description=f"{self.emoji} {ctx.author.mention} Antinuke ({module_key}) has been activated for your server",
                        color=0x00ff00
                    )
                    await ctx.send(embed=embed)
                else:
                    await ctx.send("Invalid module name.")
            else:
                await ctx.send("Available modules: massmention, webhook, bot, channel, members, role, spam")

    @antinuke.command(name='disable')
    @commands.has_permissions(administrator=True)
    async def antinuke_disable(self, ctx, module: str = None):
        """Disable antinuke modules"""
        guild_id = ctx.guild.id
        self.init_guild_config(guild_id)
        
        if module is None:
            # Disable all modules
            for mod in self.config[str(guild_id)]['modules']:
                self.config[str(guild_id)]['modules'][mod] = False
            
            # Check if all modules are disabled
            all_disabled = all(not enabled for enabled in self.config[str(guild_id)]['modules'].values())
            if all_disabled:
                self.config[str(guild_id)]['enabled'] = False
            
            self.save_config()
            
            embed = discord.Embed(
                description=f"{self.emoji} {ctx.author.mention} Antinuke (all features) has been deactivated for your server",
                color=0xff0000
            )
            await ctx.send(embed=embed)
        else:
            # Disable specific module
            module = module.lower()
            aliases = {
                'mention': 'massmention',
                'massmention': 'massmention',
                'webhook': 'webhook',
                'bot': 'bot',
                'channel': 'channel',
                'members': 'members',
                'role': 'role',
                'spam': 'spam'
            }
            
            if module in aliases:
                module_key = aliases[module]
                if module_key in self.config[str(guild_id)]['modules']:
                    self.config[str(guild_id)]['modules'][module_key] = False
                    self.save_config()
                    
                    # Check if all modules are disabled
                    all_disabled = all(not enabled for enabled in self.config[str(guild_id)]['modules'].values())
                    if all_disabled:
                        self.config[str(guild_id)]['enabled'] = False
                        self.save_config()
                    
                    embed = discord.Embed(
                        description=f"{self.emoji} {ctx.author.mention} Antinuke ({module_key}) has been deactivated for your server",
                        color=0xff0000
                    )
                    await ctx.send(embed=embed)
                else:
                    await ctx.send("Invalid module name.")
            else:
                await ctx.send("Available modules: massmention, webhook, bot, channel, members, role, spam")

    @antinuke.command(name='whitelist')
    @commands.has_permissions(administrator=True)
    async def antinuke_whitelist(self, ctx, user: discord.Member):
        """Whitelist a user from antinuke protections"""
        guild_id = ctx.guild.id
        self.init_guild_config(guild_id)
        
        user_id = str(user.id)
        if user_id not in self.config[str(guild_id)]['whitelist']:
            self.config[str(guild_id)]['whitelist'].append(user_id)
            self.save_config()
            
            embed = discord.Embed(
                description=f"{self.emoji} {user.mention} has been whitelisted from antinuke protections",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                description=f"{self.emoji} {user.mention} is already whitelisted",
                color=0xff0000
            )
            await ctx.send(embed=embed)

    @antinuke.command(name='unwhitelist')
    @commands.has_permissions(administrator=True)
    async def antinuke_unwhitelist(self, ctx, user: discord.Member):
        """Remove a user from antinuke whitelist"""
        guild_id = ctx.guild.id
        self.init_guild_config(guild_id)
        
        user_id = str(user.id)
        if user_id in self.config[str(guild_id)]['whitelist']:
            self.config[str(guild_id)]['whitelist'].remove(user_id)
            self.save_config()
            
            embed = discord.Embed(
                description=f"{self.emoji} {user.mention} has been removed from antinuke whitelist",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                description=f"{self.emoji} {user.mention} is not whitelisted",
                color=0xff0000
            )
            await ctx.send(embed=embed)

    @antinuke.command(name='status')
    @commands.has_permissions(administrator=True)
    async def antinuke_status(self, ctx):
        """Show current antinuke status"""
        guild_id = ctx.guild.id
        self.init_guild_config(guild_id)
        
        guild_config = self.config.get(str(guild_id), {})
        
        embed = discord.Embed(title="Antinuke Status", color=0x00ff00 if guild_config.get('enabled', False) else 0xff0000)
        embed.add_field(name="Overall Status", value="Enabled" if guild_config.get('enabled', False) else "Disabled", inline=False)
        
        modules_status = ""
        for module, enabled in guild_config.get('modules', {}).items():
            modules_status += f"{module}: {'✅' if enabled else '❌'}\n"
        
        if modules_status:
            embed.add_field(name="Modules", value=modules_status, inline=False)
        
        whitelist_count = len(guild_config.get('whitelist', []))
        embed.add_field(name="Whitelisted Users", value=str(whitelist_count), inline=True)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AntinukeCog(bot))