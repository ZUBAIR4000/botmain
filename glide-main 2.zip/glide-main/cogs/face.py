import discord
from discord.ext import commands
import random
import asyncio
from typing import Optional

class FaceID(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.selfie_channels = [1314944895022010448, 1309879762839408640]  # Selfie channel IDs
        self.smash_emoji_id = 1310688554623434762  # Smash emoji ID
        self.pass_emoji_id = 1310688797251338261  # Pass emoji ID

    async def get_user_images(self, user_id):
        """Get all images sent by a user in selfie channels"""
        images = []
        for channel_id in self.selfie_channels:
            channel = self.bot.get_channel(channel_id)
            if not channel:
                continue
                
            async for message in channel.history(limit=500):
                if message.author.id == user_id and message.attachments:
                    for attachment in message.attachments:
                        if any(attachment.filename.lower().endswith(ext) for ext in ['.jpg', '.jpeg', '.png', '.gif']):
                            images.append({
                                'url': attachment.url,
                                'message': message
                            })
        return images

    async def count_reactions(self, messages, emoji_id):
        """Count total reactions of a specific emoji across messages"""
        count = 0
        for msg_data in messages:
            message = msg_data['message']
            for reaction in message.reactions:
                if isinstance(reaction.emoji, (discord.Emoji, discord.PartialEmoji)):
                    if reaction.emoji.id == emoji_id:
                        count += reaction.count
                elif str(reaction.emoji) == str(emoji_id):
                    count += reaction.count
        return count

    class EnlargeView(discord.ui.View):
        def __init__(self, user_id, image_url, target_user):
            super().__init__(timeout=60)
            self.user_id = user_id
            self.image_url = image_url
            self.target_user = target_user

        @discord.ui.button(label="Enlarge Image", style=discord.ButtonStyle.primary)
        async def enlarge(self, interaction: discord.Interaction, button: discord.ui.Button):
            if interaction.user.id != self.user_id:
                await interaction.response.send_message("You are not the author of this embed", ephemeral=True)
                return
                
            embed = discord.Embed(
                title=f"{self.target_user.display_name}'s Enlarged FACE ID",
                color=discord.Color.blurple()
            )
            embed.set_image(url=self.image_url)
            embed.set_author(
                name=interaction.user.name,
                icon_url=interaction.user.avatar.url
            )
            
            await interaction.response.send_message(embed=embed)
            self.stop()

    @commands.command(name="face")
    async def face(self, ctx, user: Optional[discord.Member] = None):
        """Show a random selfie with interaction stats"""
        target_user = user or ctx.author
        await ctx.trigger_typing()

        # Get all user images
        user_images = await self.get_user_images(target_user.id)
        if not user_images:
            return await ctx.send(f"No Face ID data found for {target_user.display_name}")

        # Select random image
        selected = random.choice(user_images)
        image_url = selected['url']

        # Count reactions
        smash_count = await self.count_reactions(user_images, self.smash_emoji_id)
        pass_count = await self.count_reactions(user_images, self.pass_emoji_id)
        total_interactions = smash_count + pass_count

        # Create embed
        embed = discord.Embed(
            title=f"{target_user.display_name}'s FACE ID",
            color=discord.Color.from_rgb(255, 255, 255)  # White color
        )
        embed.set_thumbnail(url=image_url)
        embed.add_field(
            name="Smashes",
            value=f"<:smash:{self.smash_emoji_id}> {smash_count}",
            inline=True
        )
        embed.add_field(
            name="Passes",
            value=f"<:pass:{self.pass_emoji_id}> {pass_count}",
            inline=True
        )
        embed.add_field(
            name="Interactions",
            value=f" {total_interactions}",
            inline=False
        )
        embed.set_footer(text=f"Requested by {ctx.author.display_name}")

        # Send embed with view
        view = self.EnlargeView(ctx.author.id, image_url, target_user)
        message = await ctx.send(embed=embed, view=view)

        # Add reaction emojis
        smash_emoji = self.bot.get_emoji(self.smash_emoji_id) or "🔨"
        pass_emoji = self.bot.get_emoji(self.pass_emoji_id) or "✋"
        
        try:
            await message.add_reaction(smash_emoji)
            await message.add_reaction(pass_emoji)
        except:
            pass

async def setup(bot):
    await bot.add_cog(FaceID(bot))