import discord
from discord.ext import commands
import json
import os
import random
import asyncio
from datetime import datetime

class LearningCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.learning_file = "learned_messages.json"
        self.learning_config = "learning_config.json"
        self.learned_messages = self.load_data(self.learning_file)
        self.learning_channels = self.load_data(self.learning_config)
        
        # Initialize if files don't exist
        if not self.learned_messages:
            self.learned_messages = {}
        if not self.learning_channels:
            self.learning_channels = {}

    def load_data(self, filename):
        """Load data from JSON file"""
        if os.path.exists(filename):
            try:
                with open(filename, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_data(self, filename, data):
        """Save data to JSON file"""
        with open(filename, 'w') as f:
            json.dump(data, f, indent=4)

    @commands.command(name='gpt')
    @commands.has_permissions(manage_channels=True)
    async def gpt_toggle(self, ctx, action: str, channel: discord.TextChannel = None):
        """Enable or disable learning mode for a channel"""
        if action.lower() not in ['enable', 'disable']:
            await ctx.send("Please specify 'enable' or 'disable'.")
            return
            
        if not channel:
            channel = ctx.channel
            
        channel_id = str(channel.id)
        
        if action.lower() == 'enable':
            self.learning_channels[channel_id] = {
                'enabled': True,
                'channel_name': channel.name,
                'enabled_by': ctx.author.name,
                'enabled_at': datetime.utcnow().isoformat()
            }
            await ctx.send(f"ok {channel.mention}. ")
        else:
            if channel_id in self.learning_channels:
                del self.learning_channels[channel_id]
                await ctx.send(f"✅ Learning mode disabled for {channel.mention}.")
            else:
                await ctx.send(f"❌ Learning mode was not enabled for {channel.mention}.")
        
        self.save_data(self.learning_config, self.learning_channels)

    @commands.Cog.listener()
    async def on_message(self, message):
        """Learn from human messages and respond when pinged"""
        # Ignore bot messages
        if message.author.bot:
            return
            
        channel_id = str(message.channel.id)
        
        # Check if learning is enabled for this channel
        if channel_id not in self.learning_channels or not self.learning_channels[channel_id].get('enabled', False):
            return
            
        # Learn from human messages (ignore commands)
        if not message.content.startswith(self.bot.command_prefix):
            # Save the message
            user_id = str(message.author.id)
            if user_id not in self.learned_messages:
                self.learned_messages[user_id] = {
                    'username': str(message.author),
                    'messages': []
                }
            
            # Add message if it's not empty and not too long
            if message.content.strip() and len(message.content) <= 2000:
                self.learned_messages[user_id]['messages'].append({
                    'content': message.content,
                    'timestamp': datetime.utcnow().isoformat(),
                    'message_id': str(message.id)
                })
                
                # Limit stored messages per user to prevent excessive memory usage
                if len(self.learned_messages[user_id]['messages']) > 100:
                    self.learned_messages[user_id]['messages'] = self.learned_messages[user_id]['messages'][-100:]
                
                self.save_data(self.learning_file, self.learned_messages)
        
        # Check if bot is mentioned
        if self.bot.user in message.mentions:
            async with message.channel.typing():
                # Add a small delay to make typing indicator more natural
                await asyncio.sleep(1)
                
                # If this is a reply to the bot's message, use learned responses
                if message.reference and message.reference.message_id:
                    try:
                        replied_message = await message.channel.fetch_message(message.reference.message_id)
                        if replied_message.author.id == self.bot.user.id:
                            # Respond with a random learned message
                            await self.send_learned_response(message)
                            return
                    except:
                        pass
                
                # First time ping - send greeting
                await message.reply("lol", mention_author=False)

    async def send_learned_response(self, message):
        """Send a response using learned messages"""
        # Get all learned messages
        all_messages = []
        for user_data in self.learned_messages.values():
            all_messages.extend(user_data['messages'])
        
        if not all_messages:
            await message.reply("ok", mention_author=False)
            return
            
        # Select a random message
        random_message = random.choice(all_messages)
        
        # Send the response
        try:
            await message.reply(random_message['content'], mention_author=False)
        except discord.HTTPException:
            # If message is too long or contains invalid content
            await message.reply("uh", mention_author=False)

    @commands.command(name='gpt_stats')
    async def gpt_stats(self, ctx):
        """Show statistics about learned messages"""
        total_messages = 0
        total_users = len(self.learned_messages)
        
        for user_data in self.learned_messages.values():
            total_messages += len(user_data['messages'])
        
        embed = discord.Embed(
            title="stats",
            description=f"GPT Scan {total_messages} messages from {total_users} users.",
            color=0xFAFAFAFA
        )
        
        # Add top users by message count
        if self.learned_messages:
            top_users = sorted(
                [(data['username'], len(data['messages'])) for data in self.learned_messages.values()],
                key=lambda x: x[1],
                reverse=True
            )[:5]
            
            if top_users:
                embed.add_field(
                    name="Top Contributors",
                    value="\n".join([f"{user}: {count} messages" for user, count in top_users]),
                    inline=False
                )
        
        # Add active learning channels
        active_channels = []
        for channel_id, config in self.learning_channels.items():
            if config.get('enabled', False):
                channel = self.bot.get_channel(int(channel_id))
                if channel:
                    active_channels.append(channel.mention)
        
        if active_channels:
            embed.add_field(
                name="Active Learning Channels",
                value="\n".join(active_channels),
                inline=False
            )
        
        await ctx.send(embed=embed)

    @commands.command(name='gpt_clear')
    @commands.has_permissions(manage_channels=True)
    async def gpt_clear(self, ctx, user: discord.Member = None):
        """Clear learned messages for a specific user or all users"""
        if user:
            user_id = str(user.id)
            if user_id in self.learned_messages:
                count = len(self.learned_messages[user_id]['messages'])
                del self.learned_messages[user_id]
                self.save_data(self.learning_file, self.learned_messages)
                await ctx.send(f"{count} dataset wiped from {user.display_name}.")
            else:
                await ctx.send(f"couldnt {user.display_name}.")
        else:
            count = sum(len(data['messages']) for data in self.learned_messages.values())
            self.learned_messages = {}
            self.save_data(self.learning_file, self.learned_messages)
            await ctx.send(f"cleared ({count}")

async def setup(bot):
    await bot.add_cog(LearningCog(bot))