import discord
from discord.ext import commands
import asyncio
from datetime import datetime

class DMCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.dm_tasks = {}
        self.excluded_role_id = 898793009469071392  # Role ID to exclude from DMs

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def dm(self, ctx, *, message_content: str):
        """Send a DM to all members of a selected server"""
        # Create guild selection dropdown
        options = []
        
        for guild in self.bot.guilds:
            # Only show guilds where the bot has permissions
            if guild.get_member(ctx.author.id) and guild.me.guild_permissions.manage_messages:
                options.append(discord.SelectOption(
                    label=guild.name[:100],
                    description=f"{guild.member_count} members"[:100],
                    value=str(guild.id)
                ))
        
        if not options:
            return await ctx.send("❌ No available servers to DM.")
        
        # Create select menu
        select = discord.ui.Select(
            placeholder="Select a server to DM...",
            options=options[:25]  # Discord limits to 25 options
        )
        
        async def select_callback(interaction):
            if interaction.user.id != ctx.author.id:
                await interaction.response.send_message("This menu is not for you!", ephemeral=True)
                return
            
            guild_id = int(select.values[0])
            guild = self.bot.get_guild(guild_id)
            
            if not guild:
                await interaction.response.send_message("Server not found!", ephemeral=True)
                return
            
            # Confirm before sending DMs
            confirm_embed = discord.Embed(
                title="⚠️ Confirm DM Campaign",
                description=f"Are you sure you want to DM all members of **{guild.name}**?",
                color=0xffcc00
            )
            confirm_embed.add_field(
                name="Message Content",
                value=message_content[:1024],
                inline=False
            )
            confirm_embed.set_footer(text="This action cannot be undone!")
            
            # Create confirmation buttons
            confirm_view = discord.ui.View()
            
            yes_button = discord.ui.Button(style=discord.ButtonStyle.danger, label="Yes, Send DMs")
            no_button = discord.ui.Button(style=discord.ButtonStyle.secondary, label="Cancel")
            
            async def yes_callback(interaction):
                if interaction.user.id != ctx.author.id:
                    await interaction.response.send_message("This confirmation is not for you!", ephemeral=True)
                    return
                
                await interaction.response.edit_message(content="🚀 Starting DM campaign...", embed=None, view=None)
                await self.start_dm_campaign(ctx, guild, message_content)
            
            async def no_callback(interaction):
                if interaction.user.id != ctx.author.id:
                    await interaction.response.send_message("This confirmation is not for you!", ephemeral=True)
                    return
                
                await interaction.response.edit_message(content="❌ DM campaign cancelled.", embed=None, view=None)
            
            yes_button.callback = yes_callback
            no_button.callback = no_callback
            
            confirm_view.add_item(yes_button)
            confirm_view.add_item(no_button)
            
            await interaction.response.send_message(embed=confirm_embed, view=confirm_view, ephemeral=True)
        
        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)
        
        await ctx.send("Select a server to send DMs to:", view=view)

    async def start_dm_campaign(self, ctx, guild, message_content):
        """Start the DM campaign for a specific guild"""
        # Get all members except excluded ones
        members_to_dm = []
        restricted_members = []
        
        for member in guild.members:
            # Skip bots
            if member.bot:
                continue
            
            # Skip users with Administrator permission
            if member.guild_permissions.administrator:
                restricted_members.append(member)
                continue
            
            # Skip server owners
            if member.id == guild.owner_id:
                restricted_members.append(member)
                continue
            
            # Skip users with the excluded role
            excluded_role = guild.get_role(self.excluded_role_id)
            if excluded_role and excluded_role in member.roles:
                restricted_members.append(member)
                continue
            
            # Skip users who can't receive DMs
            if member.is_on_mobile() or member.status == discord.Status.offline:
                # Check if we can actually DM this user
                try:
                    await member.send("Testing DM capabilities...", delete_after=0.1)
                except:
                    restricted_members.append(member)
                    continue
            
            members_to_dm.append(member)
        
        total_members = len(members_to_dm)
        restricted_count = len(restricted_members)
        
        # Create progress embed
        progress_embed = discord.Embed(
            title="📨 DM Campaign Progress",
            color=0x00ff00
        )
        progress_embed.add_field(name="Server", value=guild.name, inline=True)
        progress_embed.add_field(name="Total Members", value=str(total_members), inline=True)
        progress_embed.add_field(name="Restricted DMs", value=f"0/{restricted_count}", inline=True)
        progress_embed.add_field(name="Progress", value="0% (0/0)", inline=True)
        progress_embed.add_field(name="Status", value="Starting...", inline=True)
        progress_embed.add_field(name="Completed", value="No", inline=True)
        progress_embed.set_footer(text="DM campaign in progress")
        
        progress_message = await ctx.send(embed=progress_embed)
        
        # Store task information
        task_id = f"{ctx.guild.id}_{ctx.channel.id}_{progress_message.id}"
        self.dm_tasks[task_id] = {
            "total": total_members,
            "completed": 0,
            "failed": 0,
            "restricted": restricted_count,
            "start_time": datetime.utcnow(),
            "message": progress_message
        }
        
        # Send DMs
        successful_dms = 0
        failed_dms = 0
        
        for i, member in enumerate(members_to_dm):

            
            try:
                await member.send(message_content)
                successful_dms += 1

            except discord.Forbidden:
                failed_dms += 1
                
            except discord.Forbidden:
                # Cannot send DM to this user
                failed_dms += 1
            except discord.HTTPException:
                # Other errors
                failed_dms += 1
            except Exception as e:
                print(f"couldnt dm {member}: {e}")
                failed_dms += 1
            
            # Update progress every 10 members or if it's the last member
            if (i + 1) % 10 == 0 or i == len(members_to_dm) - 1:
                await self.update_progress_embed(
                    task_id, guild.name, total_members, restricted_count, 
                    successful_dms, failed_dms, i + 1
                )
            
            # Small delay to avoid rate limiting
            await asyncio.sleep(0.5)
        
        # Final update
        await self.update_progress_embed(
            task_id, guild.name, total_members, restricted_count,
            successful_dms, failed_dms, len(members_to_dm), completed=True
        )
        
        # Clean up
        if task_id in self.dm_tasks:
            del self.dm_tasks[task_id]

    async def update_progress_embed(self, task_id, guild_name, total_members, restricted_count, 
                                  successful_dms, failed_dms, processed, completed=False):
        """Update the progress embed"""
        if task_id not in self.dm_tasks:
            return
        
        task = self.dm_tasks[task_id]
        
        # Calculate percentages and stats
        progress_percent = (processed / total_members * 100) if total_members > 0 else 0
        elapsed_time = (datetime.utcnow() - task["start_time"]).total_seconds()
        
        # Update progress embed
        progress_embed = discord.Embed(
            title="Progress",
            color=0x00ff00 if not completed else 0x00ff00
        )
        progress_embed.add_field(name="Server", value=guild_name, inline=True)
        progress_embed.add_field(name="Total Members", value=str(total_members), inline=True)
        progress_embed.add_field(name="Restricted DMs", value=f"{restricted_count}/{restricted_count}", inline=True)
        progress_embed.add_field(name="Progress", value=f"{progress_percent:.1f}% ({processed}/{total_members})", inline=True)
        progress_embed.add_field(name="Successful", value=str(successful_dms), inline=True)
        progress_embed.add_field(name="Failed", value=str(failed_dms), inline=True)
        progress_embed.add_field(name="Status", value="Completed ✅" if completed else "In Progress...", inline=True)
        progress_embed.add_field(name="Elapsed Time", value=f"{elapsed_time:.1f}s", inline=True)
        progress_embed.add_field(name="Completed", value="Yes" if completed else "No", inline=True)
        
        if completed:
            progress_embed.set_footer(text="completed")
        else:
            progress_embed.set_footer(text="on it")
        
        try:
            await task["message"].edit(embed=progress_embed)
        except:
            pass

    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        """Update DM tasks when bot joins a new guild"""
        # This ensures the guild list stays updated for the dropdown
        pass

    @commands.Cog.listener()
    async def on_guild_remove(self, guild):
        """Update DM tasks when bot leaves a guild"""
        # This ensures the guild list stays updated for the dropdown
        pass

async def setup(bot):
    await bot.add_cog(DMCog(bot))