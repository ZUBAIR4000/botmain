import discord
import random
import asyncio
import aiohttp
import json
import os
import math
from discord.ext import commands
from discord import ui

# Leaderboard file path
LEADERBOARD_FILE = "flag_leaderboard.json"

class FlagGame(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_games = {}
        self.countries = []
        self.leaderboard = self.load_leaderboard()
        self.bot.loop.create_task(self.initialize_countries())
        
        # Popular country codes for easy mode
        self.POPULAR_COUNTRY_CODES = {
            'us', 'gb', 'ca', 'au', 'de', 'fr', 'it', 'jp', 'br', 'in', 
            'cn', 'ru', 'mx', 'es', 'za', 'kr', 'eg', 'ng', 'se', 'nl', 
            'ch', 'tr', 'sa', 'ae'
        }

    def load_leaderboard(self):
        """Load leaderboard from JSON file"""
        if os.path.exists(LEADERBOARD_FILE):
            try:
                with open(LEADERBOARD_FILE, 'r') as f:
                    return json.load(f)
            except:
                return {}
        return {}

    def save_leaderboard(self):
        """Save leaderboard to JSON file"""
        with open(LEADERBOARD_FILE, 'w') as f:
            json.dump(self.leaderboard, f, indent=4)

    def update_score(self, user_id: int):
        """Update user's score in leaderboard - fixed tracking"""
        user_id = str(user_id)
        username = str(self.bot.get_user(int(user_id)) or f"Unknown-{user_id}")
        
        if user_id not in self.leaderboard:
            self.leaderboard[user_id] = {"username": username, "score": 0}
        
        self.leaderboard[user_id]["score"] += 1
        self.leaderboard[user_id]["username"] = username
        self.save_leaderboard()

    def get_leaderboard_embed(self, page=1, guild=None):
        """Create leaderboard embed with precise tracking and user mentions, paginated"""
        per_page = 10
        sorted_users = sorted(
            self.leaderboard.items(),
            key=lambda x: x[1]["score"],
            reverse=True
        )
        total_pages = max(1, math.ceil(len(sorted_users) / per_page))
        page = max(1, min(page, total_pages))
        start = (page - 1) * per_page
        end = start + per_page
        embed = discord.Embed(
            title=",flags leaderboard",
            color=discord.Color.gold(),
            description="Top flag guessers in the server"
        )
        embed.set_footer(text=f"Page {page}/{total_pages}")

        if not sorted_users:
            embed.description = "No scores yet! Play some flag games to appear here."
            return embed

        for i, (user_id, data) in enumerate(sorted_users[start:end], start + 1):
            # Try to mention user if possible
            user_mention = f"<@{user_id}>"
            embed.add_field(
                name=f"{i}. {data['username']} — **{data['score']}** points",
                value="",
                inline=False
            )
        return embed

    class LeaderboardView(ui.View):
        def __init__(self, game, author_id, guild, page=1):
            super().__init__(timeout=60)
            self.game = game
            self.author_id = author_id
            self.guild = guild
            self.page = page
            self.message = None

        async def interaction_check(self, interaction: discord.Interaction) -> bool:
            if interaction.user.id != self.author_id:
                await interaction.response.send_message(
                    "nigga this aint ur game ur a fucking fag sorry :sob: ",
                    ephemeral=True
                )
                return False
            return True

        @ui.button(emoji='<:leftarrow:1387448445270360206>', style=discord.ButtonStyle.grey)
        async def left(self, interaction: discord.Interaction, button: ui.Button):
            if self.page > 1:
                self.page -= 1
                embed = self.game.get_leaderboard_embed(self.page, self.guild)
                await interaction.response.edit_message(embed=embed, view=self)
            else:
                await interaction.response.defer()

        @ui.button(emoji='<:rightarrow:1387448549670654122>', style=discord.ButtonStyle.grey)
        async def right(self, interaction: discord.Interaction, button: ui.Button):
            per_page = 10
            total = len(self.game.leaderboard)
            total_pages = max(1, math.ceil(total / per_page))
            if self.page < total_pages:
                self.page += 1
                embed = self.game.get_leaderboard_embed(self.page, self.guild)
                await interaction.response.edit_message(embed=embed, view=self)
            else:
                await interaction.response.defer()

        @ui.button(emoji='<:close:1387448637964947646>', style=discord.ButtonStyle.red)
        async def close(self, interaction: discord.Interaction, button: ui.Button):
            await interaction.message.delete()
            self.stop()

    def get_alt_names(self, name, code):
        """Generate alternative names for country guessing"""
        alt_names = {name.lower(), code.lower()}
        # Add common alternate names
        if code == 'us': alt_names.update(['usa', 'america', 'united states'])
        elif code == 'gb': alt_names.update(['uk', 'britain', 'united kingdom'])
        elif code == 'kr': alt_names.add('south korea')
        elif code == 'kp': alt_names.add('north korea')
        elif code == 'tw': alt_names.add('taiwan')
        elif code == 'ir': alt_names.update(['iran', 'persia'])
        elif code == 'ru': alt_names.add('russia')
        return list(alt_names)

    async def initialize_countries(self):
        """Fetch all countries from Flagpedia's API"""
        try:
            async with aiohttp.ClientSession() as session:
                # Get country code mapping from FlagCDN
                async with session.get('https://flagcdn.com/en/codes.json') as response:
                    if response.status == 200:
                        data = await response.json()
                        self.countries = [
                            {
                                'name': name,
                                'code': code.lower(),
                                'alt_names': self.get_alt_names(name, code)
                            }
                            for code, name in data.items()
                        ]
                        print(f"Loaded {len(self.countries)} countries from FlagCDN")
                    else:
                        print(f"FlagCDN failed ({response.status}), using REST Countries")
                        await self.load_restcountries()
        except Exception as e:
            print(f"Error initializing countries: {e}")
            await self.load_restcountries()

    async def load_restcountries(self):
        """Fallback to REST Countries API"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://restcountries.com/v3.1/all') as response:
                    if response.status == 200:
                        data = await response.json()
                        self.countries = [
                            {
                                'name': country['name']['common'],
                                'code': country['cca2'].lower(),
                                'alt_names': [
                                    country['name']['common'].lower(),
                                    country['cca2'].lower(),
                                    *[alt.lower() for alt in country.get('altSpellings', [])]
                                ]
                            }
                            for country in data
                        ]
                        print(f"Loaded {len(self.countries)} countries from REST Countries")
                    else:
                        await self.load_backup_countries()
        except Exception:
            await self.load_backup_countries()

    async def load_backup_countries(self):
        """Final fallback with extended country list"""
        extended_countries = [
            ('Afghanistan', 'af'), ('Albania', 'al'), ('Algeria', 'dz'), ('Andorra', 'ad'),
            ('Angola', 'ao'), ('Antigua and Barbuda', 'ag'), ('Argentina', 'ar'), ('Armenia', 'am'),
            ('Australia', 'au'), ('Austria', 'at'), ('Azerbaijan', 'az'), ('Bahamas', 'bs'),
            ('Bahrain', 'bh'), ('Bangladesh', 'bd'), ('Barbados', 'bb'), ('Belarus', 'by'),
            ('Belgium', 'be'), ('Belize', 'bz'), ('Benin', 'bj'), ('Bhutan', 'bt'),
            ('Bolivia', 'bo'), ('Bosnia and Herzegovina', 'ba'), ('Botswana', 'bw'), ('Brazil', 'br'),
            ('Brunei', 'bn'), ('Bulgaria', 'bg'), ('Burkina Faso', 'bf'), ('Burundi', 'bi'),
            ('Cabo Verde', 'cv'), ('Cambodia', 'kh'), ('Cameroon', 'cm'), ('Canada', 'ca'),
            ('Central African Republic', 'cf'), ('Chad', 'td'), ('Chile', 'cl'), ('China', 'cn'),
            ('Colombia', 'co'), ('Comoros', 'km'), ('Congo', 'cg'), ('Costa Rica', 'cr'),
            ('Croatia', 'hr'), ('Cuba', 'cu'), ('Cyprus', 'cy'), ('Czechia', 'cz'),
            ('Denmark', 'dk'), ('Djibouti', 'dj'), ('Dominica', 'dm'), ('Dominican Republic', 'do'),
            ('Ecuador', 'ec'), ('Egypt', 'eg'), ('El Salvador', 'sv'), ('Equatorial Guinea', 'gq'),
            ('Eritrea', 'er'), ('Estonia', 'ee'), ('Eswatini', 'sz'), ('Ethiopia', 'et'),
            ('Fiji', 'fj'), ('Finland', 'fi'), ('France', 'fr'), ('Gabon', 'ga'),
            ('Gambia', 'gm'), ('Georgia', 'ge'), ('Germany', 'de'), ('Ghana', 'gh'),
            ('Greece', 'gr'), ('Grenada', 'gd'), ('Guatemala', 'gt'), ('Guinea', 'gn'),
            ('Guinea-Bissau', 'gw'), ('Guyana', 'gy'), ('Haiti', 'ht'), ('Honduras', 'hn'),
            ('Hungary', 'hu'), ('Iceland', 'is'), ('India', 'in'), ('Indonesia', 'id'),
            ('Iran', 'ir'), ('Iraq', 'iq'), ('Ireland', 'ie'), ('Israel', 'il'),
            ('Italy', 'it'), ('Jamaica', 'jm'), ('Japan', 'jp'), ('Jordan', 'jo'),
            ('Kazakhstan', 'kz'), ('Kenya', 'ke'), ('Kiribati', 'ki'), ('Kuwait', 'kw'),
            ('Kyrgyzstan', 'kg'), ('Laos', 'la'), ('Latvia', 'lv'), ('Lebanon', 'lb'),
            ('Lesotho', 'ls'), ('Liberia', 'lr'), ('Libya', 'ly'), ('Liechtenstein', 'li'),
            ('Lithuania', 'lt'), ('Luxembourg', 'lu'), ('Madagascar', 'mg'), ('Malawi', 'mw'),
            ('Malaysia', 'my'), ('Maldives', 'mv'), ('Mali', 'ml'), ('Malta', 'mt'),
            ('Marshall Islands', 'mh'), ('Mauritania', 'mr'), ('Mauritius', 'mu'), ('Mexico', 'mx'),
            ('Micronesia', 'fm'), ('Moldova', 'md'), ('Monaco', 'mc'), ('Mongolia', 'mn'),
            ('Montenegro', 'me'), ('Morocco', 'ma'), ('Mozambique', 'mz'), ('Myanmar', 'mm'),
            ('Namibia', 'na'), ('Nauru', 'nr'), ('Nepal', 'np'), ('Netherlands', 'nl'),
            ('New Zealand', 'nz'), ('Nicaragua', 'ni'), ('Niger', 'ne'), ('Nigeria', 'ng'),
            ('North Korea', 'kp'), ('North Macedonia', 'mk'), ('Norway', 'no'), ('Oman', 'om'),
            ('Pakistan', 'pk'), ('Palau', 'pw'), ('Panama', 'pa'), ('Papua New Guinea', 'pg'),
            ('Paraguay', 'py'), ('Peru', 'pe'), ('Philippines', 'ph'), ('Poland', 'pl'),
            ('Portugal', 'pt'), ('Qatar', 'qa'), ('Romania', 'ro'), ('Russia', 'ru'),
            ('Rwanda', 'rw'), ('Saint Kitts and Nevis', 'kn'), ('Saint Lucia', 'lc'),
            ('Samoa', 'ws'), ('San Marino', 'sm'), ('Sao Tome and Principe', 'st'), ('Saudi Arabia', 'sa'),
            ('Senegal', 'sn'), ('Serbia', 'rs'), ('Seychelles', 'sc'), ('Sierra Leone', 'sl'),
            ('Singapore', 'sg'), ('Slovakia', 'sk'), ('Slovenia', 'si'), ('Solomon Islands', 'sb'),
            ('Somalia', 'so'), ('South Africa', 'za'), ('South Korea', 'kr'), ('South Sudan', 'ss'),
            ('Spain', 'es'), ('Sri Lanka', 'lk'), ('Sudan', 'sd'), ('Suriname', 'sr'),
            ('Sweden', 'se'), ('Switzerland', 'ch'), ('Syria', 'sy'), ('Tajikistan', 'tj'),
            ('Tanzania', 'tz'), ('Thailand', 'th'), ('Timor-Leste', 'tl'), ('Togo', 'tg'),
            ('Tonga', 'to'), ('Trinidad and Tobago', 'tt'), ('Tunisia', 'tn'), ('Turkey', 'tr'),
            ('Turkmenistan', 'tm'), ('Tuvalu', 'tv'), ('Uganda', 'ug'), ('Ukraine', 'ua'),
            ('United Arab Emirates', 'ae'), ('United Kingdom', 'gb'), ('United States', 'us'), ('Uruguay', 'uy'),
            ('Uzbekistan', 'uz'), ('Vanuatu', 'vu'), ('Vatican City', 'va'), ('Venezuela', 've'),
            ('Vietnam', 'vn'), ('Yemen', 'ye'), ('Zambia', 'zm'), ('Zimbabwe', 'zw')
        ]
        self.countries = [{
            'name': name,
            'code': code,
            'alt_names': self.get_alt_names(name, code)
        } for name, code in extended_countries]
        print(f"Loaded {len(self.countries)} countries from backup")

    def get_popular_countries(self):
        """Get popular/well-known countries for easy mode"""
        return [c for c in self.countries if c['code'] in self.POPULAR_COUNTRY_CODES]

    class FlagView(ui.View):
        """View for flag game buttons"""
        def __init__(self, game, country, player_id):
            super().__init__(timeout=10.0)  # Match game timeout
            self.game = game
            self.country = country
            self.player_id = player_id

        @ui.button(emoji='<:hint:1387209031608696882>', style=discord.ButtonStyle.grey)
        async def hint_button(self, interaction: discord.Interaction, button: ui.Button):
            """Show hint about the country"""
            # Verify it's the game starter
            if interaction.user.id != self.player_id:
                await interaction.response.send_message(
                    "❌ Only the game starter can use this button!",
                    ephemeral=True
                )
                return
                
            # Generate hint
            name = self.country['name']
            hint = f"🇺🇳 Hint: `{name[0]}{'*'*(len(name)-2)}{name[-1]}` ({len(name)} letters)"
            
            # Send as a regular message (only once)
            await interaction.response.send_message(
                f"{interaction.user.mention} requested a hint:\n{hint}"
            )

        @ui.button(emoji='<:leaderboard:1387209077284929658>', style=discord.ButtonStyle.grey)
        async def leaderboard_button(self, interaction: discord.Interaction, button: ui.Button):
            """Show flag guessing leaderboard"""
            embed = self.game.get_leaderboard_embed()
            await interaction.response.send_message(embed=embed)
            
        async def on_timeout(self):
            """Disable buttons when game ends"""
            for child in self.children:
                child.disabled = True
            try:
                await self.message.edit(view=self)
            except discord.NotFound:
                pass  # Message already deleted

    async def run_flag_game(self, ctx, country_list, starter=None, easy_mode=False):
        """Core flag game logic"""
        if ctx.channel.id in self.active_games:
            await ctx.send(f"{ctx.author.mention} wait for the current game to end.")
            return
            
        if not country_list:
            await ctx.send("⚠️ Country data still loading. Try again in 10 seconds.")
            return
            
        # Select random country
        country = random.choice(country_list)
        flag_url = f"https://flagcdn.com/w320/{country['code']}.png"
        
        # Create view with buttons
        view = self.FlagView(self, country, ctx.author.id)
        
        # Create embed
        embed_title = "Flags (Easy Mode)" if easy_mode else "Guess the Flag"
        embed = discord.Embed(title=embed_title, color=discord.Color.yellow())
        embed.set_thumbnail(url=flag_url)
        embed.set_footer(text="You have 10 seconds to guess! try ,flageasy")
        
        # Mention the user above the embed in the same message
        message = await ctx.send(
            content=f"{(starter or ctx.author).mention} ",
            embed=embed,
            view=view
        )
        view.message = message
        
        # Store active game
        self.active_games[ctx.channel.id] = {
            'country': country,
            'player_id': ctx.author.id,
            'view': view
        }
        
        # Validate guesses
        def check(m):
            return (
                m.channel.id == ctx.channel.id and
                m.author.id == ctx.author.id and
                not m.author.bot
            )
        
        try:
            correct_guessed = False
            timeout = 10.0
            start_time = asyncio.get_event_loop().time()
            
            while (asyncio.get_event_loop().time() - start_time) < timeout:
                remaining = timeout - (asyncio.get_event_loop().time() - start_time)
                try:
                    msg = await self.bot.wait_for('message', timeout=remaining, check=check)
                    
                    # Check if guess matches any valid name
                    guess = msg.content.lower()
                    if guess in country['alt_names']:
                        await msg.add_reaction('✅')
                        correct_guessed = True
                        
                        # Update leaderboard with precise tracking
                        self.update_score(ctx.author.id)
                        break
                        
                except asyncio.TimeoutError:
                    break
                    
            if not correct_guessed:
                await ctx.send(
                    f"⏰ {ctx.author.mention} Time's up! "
                    f"The correct answer was: **{country['name']}**\n"
                )
                
        finally:
            # Clean up game state
            self.active_games.pop(ctx.channel.id, None)

    @commands.command(name="flag", aliases=["flags"])
    async def flag_normal(self, ctx):
        """Normal flag guessing with all countries"""
        await self.run_flag_game(ctx, self.countries, starter=ctx.author)

    @commands.command(name="flagseasy", aliases=["flageasy", "flags easy"])
    async def flags_easy(self, ctx):
        """Easy mode with popular flags"""
        popular_countries = self.get_popular_countries()
        if not popular_countries:
            await ctx.send("⚠️ Popular country data not loaded yet. Using normal mode.")
            popular_countries = self.countries[:20]  # Fallback to first 20

        await self.run_flag_game(ctx, popular_countries, starter=ctx.author, easy_mode=True)

    @commands.command(
        name="flagsleaderboard",
        aliases=["leaderboardflags", "flags leaderboard", "flagsrank", "flags rank"]
    )
    async def flags_leaderboard(self, ctx):
        """Show the flag guessing leaderboard with pages"""
        embed = self.get_leaderboard_embed(page=1, guild=ctx.guild)
        view = self.LeaderboardView(self, ctx.author.id, ctx.guild, page=1)
        msg = await ctx.send(embed=embed, view=view)
        view.message = msg

async def setup(bot):
    await bot.add_cog(FlagGame(bot))