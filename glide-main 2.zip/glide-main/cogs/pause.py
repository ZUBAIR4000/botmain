import discord
from discord.ext import commands
import asyncio

class ChannelControl(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.control_user_id = 1339387428498178132  # Your user ID
        self.paused_channels = {}  # {channel_id: {"original_overwrites": overwrites, "resume_message": message_id}}
        self.locks = {}  # Channel locks to prevent race conditions

    def get_channel_lock(self, channel_id):
        """Get or create a lock for a channel"""
        if channel_id not in self.locks:
            self.locks[channel_id] = asyncio.Lock()
        return self.locks[channel_id]

    async def delete_messages_after(self, channel, after_id):
        """Delete all messages after the pause message"""
        async for message in channel.history(limit=None, after=discord.Object(id=after_id)):
            try:
                if message.id != after_id:  # Don't delete the pause message itself
                    await message.delete()
            except discord.NotFound:
                pass  # Message already deleted
            except discord.Forbidden:
                print(f"no")
                break
            except discord.HTTPException:
                await asyncio.sleep(1)  # Rate limit handling

    async def restore_permissions(self, channel, original_overwrites):
        """Restore channel permissions to original state"""
        try:
            # Reset permissions for all roles and members
            for target, overwrite in original_overwrites.items():
                await channel.set_permissions(target, overwrite=overwrite)
            
            # Remove any permissions set during pause
            for target in channel.overwrites:
                if target not in original_overwrites:
                    await channel.set_permissions(target, overwrite=None)
        except discord.Forbidden:
            print(f"cant {channel.name}")
        except discord.HTTPException as e:
            print(f"couldnt {e}")

    @commands.Cog.listener()
    async def on_message(self, message):
        # Ignore messages from bots or not in a guild
        if message.author.bot or not message.guild:
            return
        
        # Handle pause command
        if message.content.lower() == "pause" and message.author.id == self.control_user_id:
            async with self.get_channel_lock(message.channel.id):
                # Check if channel is already paused
                if message.channel.id in self.paused_channels:
                    await message.add_reaction("❌")
                    return
                
                await message.add_reaction("😭")  # Sob emoji
                
                # Store original permissions
                original_overwrites = message.channel.overwrites.copy()
                
                # Disable send messages for all roles and members
                try:
                    # Disable for everyone role
                    everyone = message.guild.default_role
                    await message.channel.set_permissions(everyone, send_messages=False)
                    
                    # Disable for all roles
                    for role in message.guild.roles:
                        if role != everyone:
                            await message.channel.set_permissions(role, send_messages=False)
                    
                    # Disable for all members (except control user)
                    for member in message.channel.members:
                        if member.id != self.control_user_id:
                            await message.channel.set_permissions(member, send_messages=False)
                except discord.Forbidden:
                    await message.channel.send("no")
                    return
                
                # Save state
                self.paused_channels[message.channel.id] = {
                    "original_overwrites": original_overwrites,
                    "pause_message": message.id
                }
                
                # Start background task to delete any messages that come through
                self.bot.loop.create_task(self.delete_messages_after(message.channel, message.id))
        
        # Handle resume command
        elif message.content.lower() == "resume" and message.author.id == self.control_user_id:
            async with self.get_channel_lock(message.channel.id):
                # Check if channel is paused
                if message.channel.id not in self.paused_channels:
                    await message.add_reaction("❌")
                    return
                
                await message.add_reaction("✅")  # Check emoji
                
                # Get original state
                channel_data = self.paused_channels.pop(message.channel.id)
                
                # Restore permissions
                await self.restore_permissions(message.channel, channel_data["original_overwrites"])
                
                # Delete any messages that came after the pause
                await self.delete_messages_after(message.channel, channel_data["pause_message"])
        
        # Handle message deletion in paused channels
        elif message.channel.id in self.paused_channels:
            try:
                # Only delete messages from non-control users
                if message.author.id != self.control_user_id:
                    await message.delete()
            except discord.NotFound:
                pass  # Message already deleted
            except discord.Forbidden:
                print(f"Missing permissions to delete messages in {message.channel.name}")

async def setup(bot):
    await bot.add_cog(ChannelControl(bot))