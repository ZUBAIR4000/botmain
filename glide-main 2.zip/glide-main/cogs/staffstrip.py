import discord
from discord.ext import commands
import asyncio

class RoleCleaner(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cleaning_active = False
        self.target_roles = [
            1310597015599583273,
            1352583413516992542,
            1313192121347477615,
            1298345542925160459,
            1333211653562699929
        ]

    @commands.command(name='sa')
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def strip_admin_roles(self, ctx):
        """Remove specific roles from all members (Admin only)"""
        if self.cleaning_active:
            return await ctx.send("⚠️ A role cleaning operation is already in progress.")
            
        self.cleaning_active = True
        
        # Get confirmation
        confirm_embed = discord.Embed(
            title="Confirmation SA",
            description="This action is IRREVERSIBLE",
            color=discord.Color.orange()
        )
        confirm_embed.add_field(
            name="Target Roles",
            value="\n".join(f"• <@&{role_id}>" for role_id in self.target_roles),
            inline=False
        )
        confirm_embed.set_footer(text="Type 'confirm' in the next 30 seconds to proceed")
        
        await ctx.send(embed=confirm_embed)
        
        # Wait for confirmation
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.lower() == 'confirm'
        
        try:
            await self.bot.wait_for('message', check=check, timeout=30)
        except asyncio.TimeoutError:
            self.cleaning_active = False
            return await ctx.send("🚫 Role removal cancelled (timeout).")

        # Start removal process
        progress_msg = await ctx.send("🔍 Scanning members...")
        affected_members = 0
        processed_members = 0
        
        # Get all target roles that exist in the server
        target_roles = [role for role in ctx.guild.roles if role.id in self.target_roles]
        if not target_roles:
            self.cleaning_active = False
            return await progress_msg.edit(content="no.")
        
        async for member in ctx.guild.fetch_members(limit=None):
            if not self.cleaning_active:  # Allow cancellation
                break
                
            processed_members += 1
            roles_to_remove = [role for role in member.roles if role.id in self.target_roles]
            
            if roles_to_remove:
                try:
                    await member.remove_roles(*roles_to_remove, reason="clearing")
                    affected_members += 1
                    
                    # Update progress every 10 members
                    if affected_members % 10 == 0:
                        await progress_msg.edit(content=f"<a:loading_circle:1387477958570148021> {processed_members} / {affected_members}")
                    
                    # Rate limit protection
                    await asyncio.sleep(0.5)
                    
                except discord.Forbidden:
                    continue
                except discord.HTTPException:
                    continue
        
        # Final result
        result_embed = discord.Embed(
            title="ok",
            color=discord.Color.green()
        )
        result_embed.add_field(
            name="qty:",
            value=str(processed_members),
            inline=True
        )
        result_embed.add_field(
            name="valid qty:",
            value=str(affected_members),
            inline=True
        )
        result_embed.add_field(
            name="subtract qty:",
            value="\n".join(f"<@&{role.id}>" for role in target_roles),
            inline=False
        )
        
        await progress_msg.edit(content=None, embed=result_embed)
        self.cleaning_active = False

    @commands.command(name='cancelcleanup')
    async def cancel_cleanup(self, ctx):
        """Cancel an ongoing role cleanup"""
        if self.cleaning_active:
            self.cleaning_active = False
            await ctx.send("ok")
        else:
            await ctx.send("?")

    @strip_admin_roles.error
    async def strip_roles_error(self, ctx, error):
        self.cleaning_active = False
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("no")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("nah.")

async def setup(bot):
    await bot.add_cog(RoleCleaner(bot))