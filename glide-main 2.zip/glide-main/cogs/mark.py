import discord
from discord.ext import commands
import asyncio
from utils import create_embed

class FlagCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.flagged_users = {}  # {guild_id: {user_id: emoji}}
        self.lock = asyncio.Lock()

    @commands.command(name="mark")  # Changed from flag to mark
    @commands.has_permissions(manage_messages=True)
    async def mark(self, ctx, user: discord.User, emoji):
        """Flag a user to have reactions added to their messages"""
        # Validate emoji
        try:
            # Try to convert to emoji object
            emoji = await commands.EmojiConverter().convert(ctx, emoji)
        except commands.EmojiNotFound:
            try:
                # Try as unicode emoji
                await ctx.message.add_reaction(emoji)
            except:
                return await ctx.send(embed=create_embed("❌ Invalid emoji! Please use a server emoji or standard emoji."))

        async with self.lock:
            # Initialize guild dict if not exists
            if ctx.guild.id not in self.flagged_users:
                self.flagged_users[ctx.guild.id] = {}
            
            # Add/update flagged user
            self.flagged_users[ctx.guild.id][user.id] = str(emoji)
            
        await ctx.send(embed=create_embed(
            f"✅ {user.mention} has been flagged with {emoji}\n"
            f"All their messages will now be reacted with this emoji."
        ))

    @commands.command(aliases=['cflag'])
    @commands.has_permissions(manage_messages=True)
    async def clearflag(self, ctx, user: discord.User = None):
        """Clear flags from a user or all users"""
        async with self.lock:
            if ctx.guild.id not in self.flagged_users:
                return await ctx.send(embed=create_embed("❌ No users are currently flagged in this server."))
            
            if user:
                if user.id in self.flagged_users[ctx.guild.id]:
                    del self.flagged_users[ctx.guild.id][user.id]
                    await ctx.send(embed=create_embed(f"✅ Removed flag from {user.mention}"))
                else:
                    await ctx.send(embed=create_embed(f"❌ {user.mention} is not flagged"))
            else:
                self.flagged_users[ctx.guild.id].clear()
                await ctx.send(embed=create_embed("✅ Cleared all flags in this server"))

    @commands.Cog.listener()
    async def on_message(self, message):
        # Ignore bots and DMs
        if message.author.bot or not message.guild:
            return
        
        # Check if user is flagged
        async with self.lock:
            if (message.guild.id in self.flagged_users and 
                message.author.id in self.flagged_users[message.guild.id]):
                
                emoji = self.flagged_users[message.guild.id][message.author.id]
                
                try:
                    await message.add_reaction(emoji)
                except discord.HTTPException as e:
                    print(f"Failed to add reaction: {e}")

    @mark.error  # Changed from @flag.error to @mark.error
    async def mark_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send(embed=create_embed("❌ You need manage messages permissions to use this command!"))
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(embed=create_embed("❌ Please mention a user and provide an emoji! Example: `,mark @user 😂`"))
        elif isinstance(error, commands.UserNotFound):
            await ctx.send(embed=create_embed("❌ User not found! Please mention a valid user or use their ID."))

    @clearflag.error
    async def clearflag_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send(embed=create_embed("❌ You need manage messages permissions to use this command!"))

async def setup(bot):
    await bot.add_cog(FlagCog(bot))