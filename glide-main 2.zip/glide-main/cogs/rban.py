import discord
from discord.ext import commands
from collections import defaultdict

class ReactionBan(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.reaction_banned = set()
        self.reaction_counts = defaultdict(int)
        self.message_owners = {}

    @commands.command(name="rban", aliases=["reactionban"])
    @commands.has_permissions(manage_messages=True)
    async def reaction_ban(self, ctx, user: discord.User):
        """Ban a user from receiving reactions"""
        if user.id in self.reaction_banned:
            embed = discord.Embed(
                description=f"{user.mention} is already reaction banned",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        self.reaction_banned.add(user.id)
        
        embed = discord.Embed(
 
            description=f"{user.mention} has been reaction banned",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)

    @commands.command(name="runban", aliases=["reactionunban"])
    @commands.has_permissions(manage_messages=True)
    async def reaction_unban(self, ctx, user: discord.User):
        """Unban a user from receiving reactions"""
        if user.id not in self.reaction_banned:
            await ctx.send(f"{user.mention} isn't reaction banned")
            return

        self.reaction_banned.remove(user.id)
        
        embed = discord.Embed(
            
            description=f"{user.mention} has been reaction unbanned",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        """Track message owners for reaction banning"""
        if message.author.id in self.reaction_banned:
            self.message_owners[message.id] = message.author.id

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        """Monitor reactions on reaction-banned users' messages"""
        # Ignore reactions in DMs
        if not payload.guild_id:
            return

        # Check if the message belongs to a reaction-banned user
        if payload.message_id not in self.message_owners:
            return

        user_id = self.message_owners[payload.message_id]
        if user_id not in self.reaction_banned:
            return

        # Get the message
        channel = self.bot.get_channel(payload.channel_id)
        try:
            message = await channel.fetch_message(payload.message_id)
        except discord.NotFound:
            return

        # Increment reaction count
        self.reaction_counts[payload.message_id] += 1

        # Check if we've reached the threshold (5 reactions)
        if self.reaction_counts[payload.message_id] >= 5:
            try:
                # Clear all reactions
                await message.clear_reactions()
                
                # Reset count for this message
                self.reaction_counts[payload.message_id] = 0
                # No notification sent
            except discord.Forbidden:
                # Bot doesn't have permission to clear reactions
                pass
            except Exception as e:
                # Log or handle other exceptions if needed
                pass

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload):
        """Decrement count when reactions are removed"""
        if payload.message_id in self.reaction_counts:
            self.reaction_counts[payload.message_id] = max(0, self.reaction_counts[payload.message_id] - 1)

    @commands.Cog.listener()
    async def on_raw_message_delete(self, payload):
        """Clean up tracking when messages are deleted"""
        if payload.message_id in self.message_owners:
            del self.message_owners[payload.message_id]
        if payload.message_id in self.reaction_counts:
            del self.reaction_counts[payload.message_id]

async def setup(bot):
    await bot.add_cog(ReactionBan(bot))