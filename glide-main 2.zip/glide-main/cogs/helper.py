import os
import json
import inspect
import discord
from discord.ext import commands

def generate_command_data(bot):
    """Generate command documentation from all cogs"""
    command_data = {}
    prefix = ","  # Set your actual prefix here

    # Get all commands
    for cog_name, cog in bot.cogs.items():
        for command in cog.get_commands():
            # Skip hidden commands
            if command.hidden:
                continue
                
            # Get command info
            cmd_info = {
                "name": command.name,
                "description": command.description or "N/A",
                "aliases": command.aliases or [],
                "permissions": [],
                "usage": f"{prefix}{command.name} {command.signature}",
                "cog": cog_name,
                "subcommands": []
            }
            
            # Handle subcommands
            if isinstance(command, commands.Group):
                for subcommand in command.commands:
                    sub_info = {
                        "name": subcommand.name,
                        "description": subcommand.description or "N/A",
                        "aliases": subcommand.aliases or [],
                        "permissions": [],
                        "usage": f"{prefix}{command.name} {subcommand.name} {subcommand.signature}",
                    }
                    
                    # Get subcommand permissions
                    for check in subcommand.checks:
                        if hasattr(check, '__name__') and check.__name__ == 'has_permissions':
                            sub_info["permissions"] = [
                                perm.replace('_', ' ').title() 
                                for perm in check.__closure__[0].cell_contents.keys()
                            ]
                    
                    cmd_info["subcommands"].append(sub_info)
            
            command_data[command.name] = cmd_info
    
    # Save to file
    with open('command_data.json', 'w') as f:
        json.dump(command_data, f, indent=2)
    
    print(f"Generated documentation for {len(command_data)} commands")

# Usage in your main bot file:
# from help_system import generate_command_data
# 
# @bot.event
# async def on_ready():
#     generate_command_data(bot)

async def setup(bot):
    pass  # No commands/classes to add, but this satisfies the loader

if __name__ == "__main__":
    print("This file is intended to be imported as a cog or module, not run directly.")