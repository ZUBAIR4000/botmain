import discord
from discord.ext import commands
from discord import ui
import asyncio
from datetime import datetime

# Custom Emojis
VM_EMOJIS = {
    "lock": "<:vm_lock:1365361456522072174>",
    "unlock": "<:vm_unlock:1365361497890619452>",
    "hide": "<:vm_hide:1365361402797232128>",
    "reveal": "<:vm_eye:1365361339358253106>",
    "claim": "<:vm_claim:1365361378491367444>",
    "disconnect": "<:vm_disconnect:1365361324590370886>",
    "activity": "<:vm_activity:1365361357167398992>",
    "info": "<:vm_info:1365361437001908328>",
    "increase": "<:increase:1365361307401977918>",
    "decrease": "<:decrease:1365361474788393025>"
}

class VoiceControlView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # Set timeout to None for persistence

    # Lock/Unlock
    @ui.button(emoji=VM_EMOJIS["[**__`lock`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="lock_channel")
    async def lock_channel(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(LockModal())

    @ui.button(emoji=VM_EMOJIS["[**__`unlock`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="unlock_channel")
    async def unlock_channel(self, interaction: discord.Interaction, button: ui.Button):
        vc = interaction.user.voice.channel
        await vc.set_permissions(interaction.guild.default_role, connect=True)
        await interaction.response.send_message("🔓 Channel unlocked!", ephemeral=True)

    # Visibility
    @ui.button(emoji=VM_EMOJIS["[**__`hide`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="hide_channel")
    async def hide_channel(self, interaction: discord.Interaction, button: ui.Button):
        vc = interaction.user.voice.channel
        await vc.set_permissions(interaction.guild.default_role, view_channel=False)
        await interaction.response.send_message("👻 Channel hidden!", ephemeral=True)

    @ui.button(emoji=VM_EMOJIS["[**__`reveal`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="reveal_channel")
    async def reveal_channel(self, interaction: discord.Interaction, button: ui.Button):
        vc = interaction.user.voice.channel
        await vc.set_permissions(interaction.guild.default_role, view_channel=True)
        await interaction.response.send_message("👀 Channel revealed!", ephemeral=True)

    # Claim Ownership
    @ui.button(emoji=VM_EMOJIS["[**__`claim`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="claim_channel")
    async def claim_channel(self, interaction: discord.Interaction, button: ui.Button):
        vc = interaction.user.voice.channel
        cog = interaction.client.get_cog("VoiceMaster")
        if vc.id in cog.vc_owners:
            owner_id = cog.vc_owners[vc.id]
            owner = interaction.guild.get_member(owner_id)
            if not owner or owner not in vc.members:
                cog.vc_owners[vc.id] = interaction.user.id
                await interaction.response.send_message("✅ Channel ownership claimed!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ Current owner is still present!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ This channel isn't managed!", ephemeral=True)

    # Disconnect Member
    @ui.button(emoji=VM_EMOJIS["[**__`disconnect`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="disconnect_member")
    async def disconnect_member(self, interaction: discord.Interaction, button: ui.Button):
        vc = interaction.user.voice.channel
        options = [discord.SelectOption(label=str(member), value=str(member.id)) 
                   for member in vc.members if member != interaction.user]
        
        if not options:
            return await interaction.response.send_message("❌ No members to disconnect!", ephemeral=True)
        
        await interaction.response.send_message(
            view=DisconnectView(options),
            ephemeral=True
        )

    # User Limit Controls
    @ui.button(emoji=VM_EMOJIS["[**__`increase`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="increase_limit")
    async def increase_limit(self, interaction: discord.Interaction, button: ui.Button):
        vc = interaction.user.voice.channel
        new_limit = vc.user_limit + 1 if vc.user_limit else 1
        await vc.edit(user_limit=new_limit)
        await interaction.response.send_message(f"⬆ User limit increased to {new_limit}", ephemeral=True)

    @ui.button(emoji=VM_EMOJIS["[**__`decrease`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="decrease_limit")
    async def decrease_limit(self, interaction: discord.Interaction, button: ui.Button):
        vc = interaction.user.voice.channel
        if vc.user_limit > 0:
            new_limit = vc.user_limit - 1
            await vc.edit(user_limit=new_limit)
            await interaction.response.send_message(f"⬇ User limit decreased to {new_limit}", ephemeral=True)
        else:
            await interaction.response.send_message("❌ User limit already unlimited!", ephemeral=True)

    # Channel Info
    @ui.button(emoji=VM_EMOJIS["[**__`info`__**](https://discord.gg/505s)"], style=discord.ButtonStyle.gray, custom_id="channel_info")
    async def channel_info(self, interaction: discord.Interaction, button: ui.Button):
        vc = interaction.user.voice.channel
        created_at = vc.created_at.strftime("%Y-%m-%d %H:%M:%S")
        embed = discord.Embed(
            title="Channel Information",
            description=f"**Name:** {vc.name}\n**Created:** {created_at}\n**User Limit:** {vc.user_limit or 'Unlimited'}",
            color=0x2b2d31
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

class LockModal(ui.Modal):
    def __init__(self):
        super().__init__(title="Channel Settings", timeout=None)
        self.password = ui.TextInput(label="Password (optional)", required=False)
        self.add_item(self.password)
        self.name = ui.TextInput(label="Channel Name", default="Voice Channel")
        self.add_item(self.name)

    async def on_submit(self, interaction: discord.Interaction):
        vc = interaction.user.voice.channel
        await vc.edit(name=self.name.value)
        if self.password.value:
            await vc.set_permissions(interaction.guild.default_role, connect=False)
        await interaction.response.send_message("✅ Channel updated!", ephemeral=True)

class DisconnectView(ui.View):
    def __init__(self, options):
        super().__init__(timeout=None)  # Set timeout to None for persistence
        self.add_item(DisconnectSelect(options))

class DisconnectSelect(ui.Select):
    def __init__(self, options):
        super().__init__(placeholder="Select member to disconnect...", options=options, custom_id="disconnect_select")

    async def callback(self, interaction: discord.Interaction):
        member = interaction.guild.get_member(int(self.values[0]))
        if member and member.voice and member.voice.channel == interaction.user.voice.channel:
            await member.move_to(None)
            await interaction.response.send_message(f"✅ {member} disconnected!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Member not found!", ephemeral=True)

class VoiceMaster(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.vc_owners = {}
        self.restricted = {}
        self.bot.add_view(VoiceControlView())  # Register the persistent view

    @commands.group(aliases=['vm'])
    async def voicemaster(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send_help(ctx.command)

    @voicemaster.command(aliases=['setup'])
    @commands.has_permissions(administrator=True)
    async def setup_vm(self, ctx):
        try:
            category = await ctx.guild.create_category("Voice Master")
            overwrites = {
                ctx.guild.default_role: discord.PermissionOverwrite(
                    send_messages=False,
                    view_channel=True
                )
            }
            
            interface = await category.create_text_channel("interface", overwrites=overwrites)
            join_channel = await category.create_voice_channel("Join 2 Create")
            
            embed = discord.Embed(
                title="Voice Master Interface",
                description="Use the buttons below to control your voice channel.",
                color=0x2b2d31
            )
            embed.set_thumbnail(url="https://i.postimg.cc/nL3PDPRB/vm-icon.webp")
            embed.add_field(
                name="**Button Usage**",
                value=(f"{VM_EMOJIS['lock']} - Lock/Configure channel\n"
                       f"{VM_EMOJIS['unlock']} - Unlock channel\n"
                       f"{VM_EMOJIS['hide']} - Hide channel\n"
                       f"{VM_EMOJIS['reveal']} - Reveal channel\n"
                       f"{VM_EMOJIS['claim']} - Claim ownership\n"
                       f"{VM_EMOJIS['disconnect']} - Disconnect member\n"
                       f"{VM_EMOJIS['increase']} - Increase user limit\n"
                       f"{VM_EMOJIS['decrease']} - Decrease user limit\n"
                       f"{VM_EMOJIS['info']} - Channel info"),
                inline=False
            )
            
            await interface.send(embed=embed, view=VoiceControlView())
            await ctx.send("✅ VoiceMaster setup complete!")
        except Exception as e:
            await ctx.send(f"❌ Error: {str(e)}")

    @voicemaster.command(aliases=['ban', 'restrict'])
    async def restrict_user(self, ctx, member: discord.Member):
        if ctx.author.voice and ctx.author.voice.channel:
            vc = ctx.author.voice.channel
            await vc.set_permissions(member, connect=False)
            await ctx.send(f"🔒 {member.mention} restricted from joining!")
        else:
            await ctx.send("❌ You're not in a voice channel!")

    @voicemaster.command(aliases=['permit', 'allow'])
    async def permit_user(self, ctx, member: discord.Member):
        if ctx.author.voice and ctx.author.voice.channel:
            vc = ctx.author.voice.channel
            await vc.set_permissions(member, connect=None)
            await ctx.send(f"🔓 {member.mention} allowed to join!")
        else:
            await ctx.send("❌ You're not in a voice channel!")

    @voicemaster.command(aliases=['reset'])
    async def reset_vm(self, ctx):
        category = discord.utils.get(ctx.guild.categories, name="Voice Master")
        if category:
            for channel in category.channels:
                await channel.delete()
            await category.delete()
            await ctx.send("✅ VoiceMaster system reset!")
        else:
            await ctx.send("❌ VoiceMaster not set up!")

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        # Handle channel creation
        if after.channel and after.channel.name == "Join 2 Create":
            category = after.channel.category
            try:
                vc = await category.create_voice_channel(
                    f"{member.display_name}'s VC",
                    overwrites={member: discord.PermissionOverwrite(manage_channels=True)}
                )
                await member.move_to(vc)
                self.vc_owners[vc.id] = member.id
            except Exception as e:
                print(f"Error creating VC: {e}")

        # Handle channel deletion
        if before.channel and before.channel.id in self.vc_owners:
            if len(before.channel.members) == 0:
                await before.channel.delete()
                del self.vc_owners[before.channel.id]

async def setup(bot):
    await bot.add_cog(VoiceMaster(bot))