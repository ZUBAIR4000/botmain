import discord
import asyncio
from discord.ext import commands
import json
import os

class RemoteServer(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.source_channel_id = 1309879760326754385
        self.dest_channel_id = 1394021710147354634
        self.webhook_cache = {}
        self.message_mapping = {}
        self.data_file = "remote_server_data.json"
        self.load_data()

    def load_data(self):
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                self.message_mapping = {int(k): v for k, v in data.get('message_mapping', {}).items()}
                self.webhook_cache = data.get('webhook_cache', {})

    def save_data(self):
        data = {
            'message_mapping': self.message_mapping,
            'webhook_cache': self.webhook_cache
        }
        with open(self.data_file, 'w') as f:
            json.dump(data, f, indent=2)

    async def get_or_create_webhook(self, channel, user):
        # Check existing webhook cache
        if user.id in self.webhook_cache:
            try:
                return discord.Webhook.from_url(
                    self.webhook_cache[user.id],
                    session=self.bot.http._HTTPClient__session
                )
            except discord.NotFound:
                del self.webhook_cache[user.id]

        # Create new webhook if needed
        webhooks = await channel.webhooks()
        for webhook in webhooks:
            if webhook.name == f"Remote-{user.id}":
                self.webhook_cache[user.id] = webhook.url
                return webhook

        # Manage webhook limit (15 per channel)
        if len(webhooks) >= 15:
            oldest_webhook = min(webhooks, key=lambda w: w.created_at)
            await oldest_webhook.delete(reason="Cleaning unused webhooks")
            await asyncio.sleep(0.5)  # Prevent rate limiting

        # Create new webhook
        webhook = await channel.create_webhook(
            name=f"Remote-{user.id}",
            avatar=await user.avatar.read() if user.avatar else None,
            reason="Remote server forwarding"
        )
        self.webhook_cache[user.id] = webhook.url
        return webhook

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.channel.id != self.source_channel_id:
            return
        if message.author.bot:
            return

        dest_channel = self.bot.get_channel(self.dest_channel_id)
        if not dest_channel:
            return

        try:
            webhook = await self.get_or_create_webhook(dest_channel, message.author)
            files = [await attachment.to_file() for attachment in message.attachments]
            
            sent_msg = await webhook.send(
                content=message.content,
                username=message.author.display_name,
                avatar_url=message.author.avatar.url if message.author.avatar else None,
                files=files,
                embeds=message.embeds,
                wait=True
            )
            
            self.message_mapping[message.id] = sent_msg.id
            self.save_data()
        except Exception as e:
            print(f"Error forwarding message: {e}")

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if after.channel.id != self.source_channel_id:
            return
        if after.id not in self.message_mapping:
            return

        dest_channel = self.bot.get_channel(self.dest_channel_id)
        if not dest_channel:
            return

        try:
            webhook = await self.get_or_create_webhook(dest_channel, after.author)
            dest_message_id = self.message_mapping[after.id]
            
            await webhook.edit_message(
                dest_message_id,
                content=after.content,
                embeds=after.embeds
            )
        except Exception as e:
            print(f"Error editing message: {e}")

    def cog_unload(self):
        self.save_data()

async def setup(bot):
    await bot.add_cog(RemoteServer(bot))