import discord
from discord.ext import commands
import json
import os
import random
from typing import Dict, List

class RoleplayCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.roleplay_file = "roleplay_data.json"
        self.roleplay_data = self.load_roleplay_data()
        
        # Default roleplay commands if file doesn't exist
        if not self.roleplay_data:
            self.roleplay_data = {
                "anal": {
                    "name": "anal",
                    "description": "Anal action",
                    "nsfw": True,
                    "gifs": [
                        "https://cdn.hentaigifz.com/18337/anal001.gif",
                        "https://www.tagstube.com/wp-content/uploads/cache-e21155888465eabf55d969bc601f08b2/2016/01/Hentai-Anal-Gif-9.gif",
                        "https://www.hentaianime.net/imiphuma/2022/09/Hentai-anal-anal-penetration-anal-sex-animated-animation-big.gif",
                        "https://cdn.hentaigifz.com/78890/asi-o-mas.gif"
                    ],
                    "emoji": "🍑",
                    "usage_count": {}
                },
                "kiss": {
                    "name": "kiss",
                    "description": "Kiss action",
                    "nsfw": False,
                    "gifs": [
                        "https://gifdb.com/images/high/surprising-anime-kiss-togashi-yuuta-q5960hphr79b0rwy.gif",
                        "https://i.pinimg.com/originals/0b/39/ba/0b39ba7b0affa79d3d6eddbe5bea684a.gif",
                        "https://i.pinimg.com/originals/ea/de/5b/eade5b83bc8764de3037fcab1f5e2dec.gif"
                    ],
                    "emoji": "💋",
                    "usage_count": {}
                }
            }
            self.save_roleplay_data()

    def load_roleplay_data(self):
        """Load roleplay data from JSON file"""
        if os.path.exists(self.roleplay_file):
            try:
                with open(self.roleplay_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_roleplay_data(self):
        """Save roleplay data to JSON file"""
        with open(self.roleplay_file, 'w') as f:
            json.dump(self.roleplay_data, f, indent=2)

    def get_ordinal_number(self, n):
        """Convert number to ordinal (1st, 2nd, 3rd, etc.)"""
        if 10 <= n % 100 <= 20:
            suffix = 'th'
        else:
            suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')
        return f"{n}{suffix}"

    async def execute_roleplay_command(self, ctx, action: str, target: discord.Member):
        """Execute a roleplay command with the given action and target"""
        # Check if command exists
        if action not in self.roleplay_data:
            await ctx.send(f"Roleplay action '{action}' not found!")
            return

        command_data = self.roleplay_data[action]
        
        # NSFW check
        if command_data["nsfw"] and not ctx.channel.is_nsfw():
            embed = discord.Embed(
                description=f"<:Warning:1408771814100041738> {ctx.author.mention} you can use this command in **NSFW** Channels only",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return

        # Update usage count
        user_id = str(ctx.author.id)
        if user_id not in command_data["usage_count"]:
            command_data["usage_count"][user_id] = 0
        
        command_data["usage_count"][user_id] += 1
        count = command_data["usage_count"][user_id]
        
        # Save updated data
        self.save_roleplay_data()

        # Get random GIF
        gif_url = random.choice(command_data["gifs"])
        emoji = command_data.get("emoji", "❤️")
        
        # Create embed
        ordinal_count = self.get_ordinal_number(count)
        embed = discord.Embed(
            description=f"{ctx.author.mention} **{action}** {target.display_name} for the {ordinal_count} time {emoji}",
            color=0XFAFAFA
        )
        embed.set_image(url=gif_url)
        
        await ctx.send(embed=embed)

    # Roleplay command generators
    def create_roleplay_command(self, action: str):
        """Dynamically create a roleplay command"""
        @commands.command(name=action)
        async def roleplay_command(ctx, *, target: str = None):
            if not target:
                await ctx.send(f"Please mention someone to {action}!")
                return
            
            # Find the target user
            target_member = None
            
            # Check mentions first
            if ctx.message.mentions:
                target_member = ctx.message.mentions[0]
            else:
                # Search by username or display name
                for member in ctx.guild.members:
                    if (target.lower() in member.name.lower() or 
                        target.lower() in member.display_name.lower()):
                        target_member = member
                        break
            
            if not target_member:
                await ctx.send(f"Couldn't find user '{target}'!")
                return
            
            await self.execute_roleplay_command(ctx, action, target_member)
        
        return roleplay_command

    # Management commands
    @commands.group(name='roleplay', invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def roleplay(self, ctx):
        """Roleplay command management"""
        await ctx.send_help(ctx.command)

    @roleplay.command(name='add')
    @commands.has_permissions(manage_guild=True)
    async def roleplay_add(self, ctx, action: str, nsfw: bool, emoji: str, *, gif_urls: str):
        """Add a new roleplay command"""
        if action in self.roleplay_data:
            await ctx.send(f"Roleplay action '{action}' already exists!")
            return
        
        # Parse GIF URLs (comma separated)
        gif_list = [url.strip() for url in gif_urls.split(',') if url.strip()]
        
        if not gif_list:
            await ctx.send("Please provide at least one GIF URL!")
            return
        
        # Add new roleplay command
        self.roleplay_data[action] = {
            "name": action,
            "description": f"{action} action",
            "nsfw": nsfw,
            "gifs": gif_list,
            "emoji": emoji,
            "usage_count": {}
        }
        
        # Create the actual command
        new_command = self.create_roleplay_command(action)
        self.bot.add_command(new_command)
        
        self.save_roleplay_data()
        
        embed = discord.Embed(
            description=f"✅ Added new roleplay command '{action}' with {len(gif_list)} GIFs",
            color=0x00ff00
        )
        await ctx.send(embed=embed)

    @roleplay.command(name='remove')
    @commands.has_permissions(manage_guild=True)
    async def roleplay_remove(self, ctx, action: str):
        """Remove a roleplay command"""
        if action not in self.roleplay_data:
            await ctx.send(f"Roleplay action '{action}' not found!")
            return
        
        # Remove from data
        del self.roleplay_data[action]
        
        # Remove the actual command
        if action in self.bot.all_commands:
            self.bot.remove_command(action)
        
        self.save_roleplay_data()
        
        embed = discord.Embed(
            description=f"✅ Removed roleplay command '{action}'",
            color=0x00ff00
        )
        await ctx.send(embed=embed)

    @roleplay.command(name='list')
    async def roleplay_list(self, ctx):
        """List all available roleplay commands"""
        if not self.roleplay_data:
            embed = discord.Embed(
                description="No roleplay commands available",
                color=0xffff00
            )
            await ctx.send(embed=embed)
            return
        
        embed = discord.Embed(title="Available Roleplay Commands", color=0x00ff00)
        
        for action, data in self.roleplay_data.items():
            nsfw_status = "🔞 NSFW" if data["nsfw"] else "✅ SFW"
            gif_count = len(data["gifs"])
            total_uses = sum(data["usage_count"].values())
            
            embed.add_field(
                name=f",{action} {nsfw_status}",
                value=f"{gif_count} GIFs • {total_uses} total uses • {data['emoji']}",
                inline=False
            )
        
        await ctx.send(embed=embed)

    @roleplay.command(name='addgif')
    @commands.has_permissions(manage_guild=True)
    async def roleplay_addgif(self, ctx, action: str, gif_url: str):
        """Add a GIF to an existing roleplay command"""
        if action not in self.roleplay_data:
            await ctx.send(f"Roleplay action '{action}' not found!")
            return
        
        if gif_url in self.roleplay_data[action]["gifs"]:
            await ctx.send("This GIF is already in the command!")
            return
        
        self.roleplay_data[action]["gifs"].append(gif_url)
        self.save_roleplay_data()
        
        embed = discord.Embed(
            description=f"✅ Added GIF to '{action}' command",
            color=0xFAFAFA
        )
        await ctx.send(embed=embed)

    @roleplay.command(name='removegif')
    @commands.has_permissions(manage_guild=True)
    async def roleplay_removegif(self, ctx, action: str, gif_index: int):
        """Remove a GIF from a roleplay command by index"""
        if action not in self.roleplay_data:
            await ctx.send(f"Roleplay action '{action}' not found!")
            return
        
        gifs = self.roleplay_data[action]["gifs"]
        if gif_index < 1 or gif_index > len(gifs):
            await ctx.send(f"Invalid GIF index! Use numbers between 1 and {len(gifs)}")
            return
        
        removed_gif = gifs.pop(gif_index - 1)
        self.save_roleplay_data()
        
        embed = discord.Embed(
            description=f"✅ Removed GIF from '{action}' command",
            color=0xFAFAFA
        )
        await ctx.send(embed=embed)

    @roleplay.command(name='info')
    async def roleplay_info(self, ctx, action: str):
        """Get info about a specific roleplay command"""
        if action not in self.roleplay_data:
            await ctx.send(f"Roleplay action '{action}' not found!")
            return
        
        data = self.roleplay_data[action]
        nsfw_status = "🔞 NSFW" if data["nsfw"] else "✅ SFW"
        total_uses = sum(data["usage_count"].values())
        
        embed = discord.Embed(
            title=f"Roleplay Command: ,{action}",
            color=0xFAFAFA
        )
        embed.add_field(name="Status", value=nsfw_status, inline=True)
        embed.add_field(name="Emoji", value=data["emoji"], inline=True)
        embed.add_field(name="Total Uses", value=str(total_uses), inline=True)
        embed.add_field(name="GIF Count", value=str(len(data["gifs"])), inline=True)
        
        # Top users
        top_users = sorted(data["usage_count"].items(), key=lambda x: x[1], reverse=True)[:3]
        if top_users:
            user_list = []
            for user_id, count in top_users:
                user = self.bot.get_user(int(user_id))
                username = user.name if user else f"Unknown ({user_id})"
                user_list.append(f"{username}: {count} times")
            
            embed.add_field(name="Top Users", value="\n".join(user_list), inline=False)
        
        await ctx.send(embed=embed)

# Setup function to add all roleplay commands
async def setup(bot):
    cog = RoleplayCog(bot)
    await bot.add_cog(cog)
    
    # Add all existing roleplay commands
    for action in cog.roleplay_data.keys():
        command = cog.create_roleplay_command(action)
        bot.add_command(command)