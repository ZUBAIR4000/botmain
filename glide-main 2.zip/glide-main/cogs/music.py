import discord
from discord.ext import commands
from discord.utils import get
import yt_dlp
import asyncio

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}

YTDL_OPTIONS = {
    'format': 'bestaudio',
    'quiet': True,
    'default_search': 'ytsearch1:',
    'noplaylist': True
}

ytdl = yt_dlp.YoutubeDL(YTDL_OPTIONS)


class MusicPlayer(discord.ui.View):
    def __init__(self, bot, ctx, voice_client, queue):
        super().__init__(timeout=None)
        self.bot = bot
        self.ctx = ctx
        self.vc = voice_client
        self.queue = queue
        self.is_paused = False

    @discord.ui.button(emoji="<:rewind_music:1366368359528005663>", style=discord.ButtonStyle.secondary)
    async def rewind(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        await interaction.followup.send("⏮️ Going back not implemented yet.", ephemeral=True)

    @discord.ui.button(emoji="<:play_music:1366368418441461770>", style=discord.ButtonStyle.secondary)
    async def pause_resume(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        if self.vc.is_playing():
            self.vc.pause()
            self.is_paused = True
            await interaction.followup.send("⏸️ Paused", ephemeral=True)
        elif self.vc.is_paused():
            self.vc.resume()
            self.is_paused = False
            await interaction.followup.send("▶️ Resumed", ephemeral=True)

    @discord.ui.button(emoji="<:forward_music:1366368462368145428>", style=discord.ButtonStyle.secondary)
    async def skip(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        if self.vc.is_playing():
            self.vc.stop()
            await interaction.followup.send("⏭️ Skipping...", ephemeral=True)


class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queues = {}

    async def search_youtube(self, query):
        data = ytdl.extract_info(f"ytsearch1:{query}", download=False)['entries'][0]
        return {
            'title': data['title'],
            'url': data['url'],
            'webpage_url': data['webpage_url'],
            'thumbnail': data['thumbnail'],
            'uploader': data['uploader']
        }

    async def play_next(self, ctx, voice_client):
        if ctx.guild.id not in self.queues or not self.queues[ctx.guild.id]:
            await voice_client.disconnect()
            return

        next_track = self.queues[ctx.guild.id].pop(0)
        source = discord.FFmpegPCMAudio(next_track['url'], **FFMPEG_OPTIONS)
        voice_client.play(source, after=lambda e: self.bot.loop.create_task(self.play_next(ctx, voice_client)))

        # Update VC topic
        try:
            if voice_client.channel.permissions_for(voice_client.guild.me).manage_channels:
                sanitized_topic = f"Now Playing: {next_track['title']} - {next_track['uploader']}".replace("–", "-")
                sanitized_topic = ''.join(c for c in sanitized_topic if c.isprintable() and c not in ['`', '*', '_', '~', '|'])
                print(f"Updating channel topic to: {sanitized_topic}")  # Print the topic to the terminal
                await voice_client.channel.edit(topic=sanitized_topic)
            else:
                print("Bot lacks 'manage_channels' permission to update the voice channel topic.")
        except Exception as e:
            print(f"Failed to update voice channel topic: {e}")

        embed = discord.Embed(
            title="Now Playing",
            description=f"**{next_track['title']}**\nBy `{next_track['uploader']}`",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=next_track['thumbnail'])
        embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.display_avatar.url)

        view = MusicPlayer(self.bot, ctx, voice_client, self.queues[ctx.guild.id])
        await ctx.send(embed=embed, view=view)

    @commands.command(name='play', aliases=['p'])
    async def play(self, ctx, *, search: str):
        """Plays a song from YouTube search or URL"""
        if not ctx.author.voice:
            return await ctx.send(":x: You must be in a voice channel.")

        vc = ctx.voice_client
        if not vc:
            vc = await ctx.author.voice.channel.connect()

        info = await self.search_youtube(search)
        self.queues.setdefault(ctx.guild.id, []).append(info)

        if not vc.is_playing():
            await self.play_next(ctx, vc)
        else:
             await ctx.message.add_reaction("✅")

    @commands.command(name='skip')
    async def skip(self, ctx):
        """Skips current song"""
        vc = ctx.voice_client
        if vc and vc.is_playing():
            vc.stop()
            await ctx.message.add_reaction("⏭️")

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        # Auto-disconnect if everyone leaves the VC
        if before.channel and not after.channel:
            voice = discord.utils.get(self.bot.voice_clients, guild=member.guild)
            if voice and len(voice.channel.members) == 1:
                await asyncio.sleep(5)
                if len(voice.channel.members) == 1:
                    await voice.disconnect()
                    await member.guild.system_channel.send("")

async def setup(bot):
    await bot.add_cog(Music(bot))
