import discord
from discord.ext import commands
import json
import os
import asyncio
from datetime import datetime, timedelta

class VouchSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.vouches_file = 'data/vouches.json'
        self.cooldowns_file = 'data/vouch_cooldowns.json'
        
        # Create data directory if it doesn't exist
        os.makedirs('data', exist_ok=True)
        
        self.vouches_data = self.load_vouches()
        self.cooldowns_data = self.load_cooldowns()

    def load_vouches(self):
        if os.path.exists(self.vouches_file):
            with open(self.vouches_file, 'r') as f:
                return json.load(f)
        return {}

    def load_cooldowns(self):
        if os.path.exists(self.cooldowns_file):
            with open(self.cooldowns_file, 'r') as f:
                return json.load(f)
        return {}

    def save_vouches(self):
        with open(self.vouches_file, 'w') as f:
            json.dump(self.vouches_data, f)

    def save_cooldowns(self):
        with open(self.cooldowns_file, 'w') as f:
            json.dump(self.cooldowns_data, f)

    @commands.command(aliases=['rep'])
    async def vouch(self, ctx, user: discord.User):
        """Vouch for a user (15 minute cooldown per user)"""
        cooldown_key = f"{ctx.author.id}-{user.id}"
        current_time = datetime.now().timestamp()
        
        if cooldown_key in self.cooldowns_data:
            last_vouch = self.cooldowns_data[cooldown_key]
            cooldown_time = 15 * 60
            if current_time - last_vouch < cooldown_time:
                remaining = int(cooldown_time - (current_time - last_vouch))
                await ctx.send(f"You can vouch this user again in {remaining//60} minutes and {remaining%60} seconds.")
                return
        
        user_id = str(user.id)
        self.vouches_data[user_id] = self.vouches_data.get(user_id, 0) + 1
        self.cooldowns_data[cooldown_key] = current_time
        
        self.save_vouches()
        self.save_cooldowns()
        
        embed = discord.Embed(
            description=f"_ _\n> {user.mention} has been vouched\n> now has **{self.vouches_data[user_id]}** total vouches\n_ _",
            color=discord.Color.from_rgb(255, 255, 255)
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(aliases=['reps'])
    async def vouches(self, ctx, user: discord.User = None):
        """Check how many vouches a user has"""
        user = user or ctx.author
        user_id = str(user.id)
        
        embed = discord.Embed(
            description=f"_ _\n> {user.mention} has **{self.vouches_data.get(user_id, 0)}** Vouches\n> -# ,leaderboard vouch\n_ _",
            color=discord.Color.from_rgb(255, 255, 255)
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(aliases=['lb_vouches', 'lb_reps', 'lb_rep'])
    async def leaderboard(self, ctx):
        """Show the vouch leaderboard"""
        sorted_users = sorted(self.vouches_data.items(), key=lambda x: x[1], reverse=True)
        
        pages = []
        for i in range(0, len(sorted_users), 10):
            page_users = sorted_users[i:i+10]
            description = ""
            for rank, (user_id, count) in enumerate(page_users, start=i+1):
                user = self.bot.get_user(int(user_id))
                username = user.name if user else f"Unknown User ({user_id})"
                description += f"{rank}. {username} - **{count}** vouches\n"
            
            embed = discord.Embed(
                title="Vouches Leaderboard",
                description=description,
                color=discord.Color.from_rgb(255, 255, 255)
            )
            embed.set_footer(text=f"Page {i//10 + 1}/{(len(sorted_users)-1)//10 + 1}")
            pages.append(embed)
        
        if not pages:
            await ctx.send("No vouches data available yet.")
            return
        
        current_page = 0
        message = await ctx.send(embed=pages[current_page])
        
        # Button emojis
        buttons = {
            "left": "<:leftarrow:1387448445270360206>",
            "right": "<:rightarrow:1387448549670654122>",
            "close": "<:close:1387448637964947646>"
        }
        
        for emoji in buttons.values():
            await message.add_reaction(emoji)
        
        def check(reaction, reactor):
            return (
                reactor == ctx.author
                and str(reaction.emoji) in buttons.values()
                and reaction.message.id == message.id
            )
        
        while True:
            try:
                reaction, reactor = await self.bot.wait_for('reaction_add', timeout=60.0, check=check)
                
                if str(reaction.emoji) == buttons["left"] and current_page > 0:
                    current_page -= 1
                elif str(reaction.emoji) == buttons["right"] and current_page < len(pages) - 1:
                    current_page += 1
                elif str(reaction.emoji) == buttons["close"]:
                    await message.delete()
                    return
                else:
                    continue
                
                await message.edit(embed=pages[current_page])
                await message.remove_reaction(reaction.emoji, reactor)
                    
            except asyncio.TimeoutError:
                await message.clear_reactions()
                break

async def setup(bot):
    await bot.add_cog(VouchSystem(bot))