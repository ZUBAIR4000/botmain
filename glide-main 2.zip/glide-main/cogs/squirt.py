# cogs/roleplay_extended.py
import discord
from discord.ext import commands
import random

# Manual list of 10 hentai cum GIF URLs; replace the placeholder strings with your own URLs
MANUAL_CUM_GIFS = [
    "https://media.discordapp.net/attachments/1331988926834933872/1331989927197544581/squirt.gif?ex=680b9849&is=680a46c9&hm=5b6866226d8f8d967df9fccbca29d2695bbc498324d962598626a9717295819a&=&width=270&height=202",
    "https://media.discordapp.net/attachments/1331988926834933872/1331989763401453620/squirt.gif?ex=680b9822&is=680a46a2&hm=6a6ba38071a75e60bf89fd825a97291bd9856d6137d65aeb5d2eb56c8a6be73a&=&width=540&height=298",
    "https://media.discordapp.net/attachments/1331988926834933872/1331989195266330644/squirt.gif?ex=680b979b&is=680a461b&hm=6c6f9f71f066c4fb38e2ce4b179945e17b57325f27a44fffcf5ac87775afe0fc&=&width=720&height=405",
    "https://media.discordapp.net/attachments/1331988926834933872/1331988979528237067/squirt.gif?ex=680b9767&is=680a45e7&hm=d2f48707feeedf1f463265c6ddb7f6b75373743f1e67fa38c5e542d5c7fc8f3b&=&width=634&height=356",
    "https://media.discordapp.net/attachments/1331988926834933872/1331990056977694760/squirt.gif?ex=680b9868&is=680a46e8&hm=b42435c35de07a9ab8bdfb993024836fb2377c8c5726200ef0a5299c7bab5252&=&width=403&height=302",
    "https://media.discordapp.net/attachments/1331988926834933872/1331990109079339009/squirt.gif?ex=680b9875&is=680a46f5&hm=baf46caa4649cd0621e68bd88d840ea8f6c9d2f3a40c2b833501c0be043539c3&=&width=414&height=233",
    "https://media.discordapp.net/attachments/1331988926834933872/1331989125468913724/squirt.gif?ex=680b978a&is=680a460a&hm=8e8f876b72378e27f039adf755667041492239f26d74ed73dcb9805ac7102468&=&width=767&height=432",
    "https://media.discordapp.net/attachments/1331988926834933872/1331989125468913724/squirt.gif?ex=680b978a&is=680a460a&hm=8e8f876b72378e27f039adf755667041492239f26d74ed73dcb9805ac7102468&=&width=360&height=202",
    "https://media.discordapp.net/attachments/1331988926834933872/1331989854258462852/squirt.gif?ex=680b9838&is=680a46b8&hm=b61d4cbd1cf3ffd69229e106e2daf6168f4925241499ed039fb996ae6f68effb&=&width=720&height=405",
    "https://media.discordapp.net/attachments/1331988926834933872/1331989045588525078/squirt.gif?ex=680b9777&is=680a45f7&hm=be8ff3d359f76f5d086a24909d98ab9a13077b0bb6e82fabd9f5832c8e52bd23&=&width=414&height=212"
]

def ordinal(n: int) -> str:
    if 11 <= (n % 100) <= 13:
        return f"{n}th"
    return f"{n}{['th','st','nd','rd','th'][n%10 if n%10<4 else 0]}"  

class Roleplay(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # track counts per (author_id, target_id, command_name)
        self.counts: dict[tuple[int,int,str], int] = {}

    async def _do_action(self, ctx, target, command_name, action_text):
        # NSFW-only guard
        if not getattr(ctx.channel, "nsfw", False):
            return await ctx.send(":error: | This command can only be run in NSFW channels.")

        if target is None or target.bot:
            return await ctx.send(":x: | mention a user")

        # increment per-pair+command count
        key = (ctx.author.id, target.id, command_name)
        count = self.counts.get(key, 0) + 1
        self.counts[key] = count

        # pick a random GIF from manual list
        gif = random.choice(MANUAL_CUM_GIFS)

        embed = discord.Embed(
            description=(
                f"**{ctx.author.display_name}** {action_text} **{target.display_name}** "
                f"for the {ordinal(count)} time! 🤭"
            ),
            color=discord.Color.purple()
        )
        embed.set_image(url=gif)
        await ctx.send(embed=embed)

    @commands.command(name="squirt", aliases=["squirts"])
    async def cum(self, ctx, target: discord.Member = None):
        """Original cum command"""
        await self._do_action(ctx, target, "squirt", "squirted on")
 

async def setup(bot):
    # remove any existing commands to avoid collisions
    for cmd in ["squirt", "squirts",]:
        bot.remove_command(cmd)
    await bot.add_cog(Roleplay(bot))
