import discord
from discord.ext import commands
import asyncio
from datetime import datetime
from typing import Optional
from discord.ui import View, Button

class AvatarHistory(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.avatar_logs = {}
        self.initial_log_complete = set()
        self.emoji_left = "<:leftarrow:1387448445270360206>"
        self.emoji_right = "<:rightarrow:1387448549670654122>"
        self.emoji_close = "<:close:1387448637964947646>"

    async def get_log_channel(self, guild) -> discord.TextChannel:
        """Get or create the avatar log channel with embeds"""
        category = discord.utils.get(guild.categories, name="Avatar Logs")
        if not category:
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                guild.me: discord.PermissionOverwrite(read_messages=True)
            }
            category = await guild.create_category("Avatar Logs", overwrites=overwrites)
        
        channel = discord.utils.get(guild.text_channels, name="avatar-history", category=category)
        if not channel:
            channel = await guild.create_text_channel(
                "avatar-history",
                category=category,
                overwrites={
                    guild.default_role: discord.PermissionOverwrite(read_messages=False),
                    guild.me: discord.PermissionOverwrite(read_messages=True)
                }
            )
        return channel

    async def log_current_avatars(self, guild):
        """Log all current avatars in the server with embeds"""
        if guild.id in self.initial_log_complete:
            return
            
        log_channel = await self.get_log_channel(guild)
        
        if guild.id not in self.avatar_logs:
            self.avatar_logs[guild.id] = {}
        
        init_embed = discord.Embed(
            title="logging initial avatars...",
            description=f"saving data of {len(guild.members)} members...",
            color=discord.Color.blue()
        )
        init_msg = await log_channel.send(embed=init_embed)
        
        for member in guild.members:
            if not member.bot:
                if member.id not in self.avatar_logs[guild.id]:
                    self.avatar_logs[guild.id][member.id] = []
                    
                    embed = discord.Embed(
                        title=f"Initial Avatar Logged",
                        description=f"Member: {member.mention}\nUser ID: {member.id}",
                        color=discord.Color.green(),
                        timestamp=datetime.now()
                    )
                    embed.set_image(url=member.display_avatar.url)
                    embed.set_footer(text="Avatar History System")
                    
                    await log_channel.send(embed=embed)
                    
                    self.avatar_logs[guild.id][member.id].append({
                        "url": str(member.display_avatar.url),
                        "timestamp": datetime.now().isoformat(),
                        "type": "server" if member.guild_avatar else "user"
                    })
        
        self.initial_log_complete.add(guild.id)
        complete_embed = discord.Embed(
            title="initial av log done",
            description=f"Now tracking avatar changes for {len([m for m in guild.members if not m.bot])} members",
            color=discord.Color.green()
        )
        await init_msg.edit(embed=complete_embed)

    async def log_avatar_change(self, guild, user, change_type):
        """Log an avatar change with embed"""
        if user.bot:
            return
            
        log_channel = await self.get_log_channel(guild)
        
        embed = discord.Embed(
            title=f"🔄 {change_type.capitalize()} Avatar Changed",
            description=f"Member: {user.mention}\nUser ID: {user.id}",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        embed.set_image(url=user.display_avatar.url)
        embed.set_footer(text=f"Change type: {change_type}")
        
        await log_channel.send(embed=embed)
        
        if guild.id not in self.avatar_logs:
            self.avatar_logs[guild.id] = {}
        if user.id not in self.avatar_logs[guild.id]:
            self.avatar_logs[guild.id][user.id] = []
            
        self.avatar_logs[guild.id][user.id].append({
            "url": str(user.display_avatar.url),
            "timestamp": datetime.now().isoformat(),
            "type": change_type
        })

    @commands.command(aliases=['av_setup'])
    @commands.has_permissions(manage_guild=True)
    async def avhistory_setup(self, ctx):
        """Initialize avatar tracking for this server"""
        if ctx.guild.id in self.initial_log_complete:
            embed = discord.Embed(
                title="ℹ️ Already Set Up",
                description="Avatar tracking is already active for this server.",
                color=discord.Color.blue()
            )
            return await ctx.send(embed=embed)
        
        loading_embed = discord.Embed(
            title="⏳ Setting Up Avatar Tracking",
            description="This may take a few moments...",
            color=discord.Color.orange()
        )
        msg = await ctx.send(embed=loading_embed)
        
        await self.log_current_avatars(ctx.guild)
        
        success_embed = discord.Embed(
            title="✅ Setup Complete",
            description=f"Now tracking avatars for all members in {ctx.guild.name}",
            color=discord.Color.green()
        )
        await msg.edit(embed=success_embed)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Log avatar when new member joins"""
        if member.guild.id in self.initial_log_complete and not member.bot:
            await self.log_avatar_change(member.guild, member, "new member")

    @commands.Cog.listener()
    async def on_user_update(self, before, after):
        """Track user avatar changes"""
        if before.avatar != after.avatar:
            for guild in self.bot.guilds:
                if guild.get_member(after.id) and guild.id in self.initial_log_complete and not after.bot:
                    await self.log_avatar_change(guild, after, "user")

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        """Track server-specific avatar changes"""
        if before.guild_avatar != after.guild_avatar and after.guild.id in self.initial_log_complete and not after.bot:
            await self.log_avatar_change(after.guild, after, "server")

    @commands.command(aliases=['avhistory'])
    async def avatarhistory(self, ctx, user: Optional[discord.User] = None):
        """View avatar history (1 per page)"""
        user = user or ctx.author

        if ctx.guild.id not in self.initial_log_complete:
            setup_embed = discord.Embed(
                title="⚠️ Setup Required",
                description="Avatar tracking hasn't been set up yet.\n"
                            f"Use `{ctx.prefix}avhistory_setup` to start tracking avatars.",
                color=discord.Color.red()
            )
            return await ctx.send(embed=setup_embed)

        avatars = self.avatar_logs.get(ctx.guild.id, {}).get(user.id, [])
        if not avatars:
            embed = discord.Embed(
                title="No History Found",
                description=f"No avatar history found for {user.mention}",
                color=discord.Color.orange()
            )
            return await ctx.send(embed=embed)

        pages = []
        for idx, avatar in enumerate(avatars, start=1):
            embed = discord.Embed(
                color=discord.Color.white(),
                timestamp=datetime.fromisoformat(avatar['timestamp'])
            )
            # Updated author name
            embed.set_author(name=f"{user.display_name}'s avatarhistory", icon_url=user.display_avatar.url)
            embed.set_image(url=avatar['url'])

            # Fixed timestamp conversion
            timestamp = int(datetime.fromisoformat(avatar['timestamp']).timestamp())
            embed.add_field(
                name="Logged",
                value=f"<t:{timestamp}:R>",
                inline=True
            )

            embed.set_footer(text=f"Page {idx}/{len(avatars)}")
            pages.append(embed)

        current_page = 0

        # Create a custom view with buttons
        class AvatarHistoryView(View):
            def __init__(self, author):
                super().__init__(timeout=120)  # Timeout after 120 seconds
                self.author = author

            async def interaction_check(self, interaction: discord.Interaction) -> bool:
                # Ensure only the command author can interact with the buttons
                if interaction.user != self.author:
                    await interaction.response.send_message(
                        "You cannot interact with this menu.", ephemeral=True
                    )
                    return False
                return True

        view = AvatarHistoryView(ctx.author)

        # Add navigation buttons
        async def update_page(interaction, increment):
            nonlocal current_page
            current_page += increment
            current_page = max(0, min(current_page, len(pages) - 1))  # Clamp the page index
            await interaction.response.edit_message(embed=pages[current_page], view=view)

        @Button(label="", style=discord.ButtonStyle.grey, emoji=self.emoji_left)
        async def previous_button(interaction: discord.Interaction, button: Button):
            await update_page(interaction, -1)

        @Button(label="", style=discord.ButtonStyle.grey, emoji=self.emoji_right)
        async def next_button(interaction: discord.Interaction, button: Button):
            await update_page(interaction, 1)

        @Button(label="", style=discord.ButtonStyle.red, emoji=self.emoji_close)
        async def close_button(interaction: discord.Interaction, button: Button):
            await interaction.message.delete()
            self.stop()

        # Add buttons to the view
        view.add_item(previous_button)
        view.add_item(next_button)
        view.add_item(close_button)

        # Send the initial message with the first page and the view
        await ctx.send(embed=pages[current_page], view=view)

async def setup(bot):
    await bot.add_cog(AvatarHistory(bot))