import discord
from discord.ext import commands
import aiohttp
import json
import os
import asyncio
from datetime import datetime, timedelta
import urllib.parse
import base64
import zlib

class LastFMCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.settings_file = "fm_settings.json"
        self.templates_file = "fm_templates.json"
        self.settings = self.load_settings()
        self.templates = self.load_templates()
        self.lastfm_api_key = "c5020e7ff7f35d45c60893ace4cb1296"
        self.api_url = "https://ws.audioscrobbler.com/2.0/"
        self.special_bot_id = 593921296224747521

    def load_settings(self):
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def load_templates(self):
        if os.path.exists(self.templates_file):
            try:
                with open(self.templates_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_settings(self):
        with open(self.settings_file, 'w') as f:
            json.dump(self.settings, f, indent=4)
            
    def save_templates(self):
        with open(self.templates_file, 'w') as f:
            json.dump(self.templates, f, indent=4)

    async def send_error(self, ctx, message):
        """Send a standardized error embed"""
        embed = discord.Embed(
            description=f"<:lastfm:1408402685400453172> {ctx.author.mention} : {message}",
            color=0xff0000  # Red for errors
        )
        await ctx.send(embed=embed)

    async def send_success(self, ctx, message):
        """Send a standardized success embed"""
        embed = discord.Embed(
            description=f"<:lastfm:1408402685400453172> {ctx.author.mention} : {message}",
            color=0xffff00  # Yellow for neutral/success messages
        )
        await ctx.send(embed=embed)

    def get_default_settings(self, lastfm_username):
        """Return default settings for a user"""
        return {
            'lastfm_username': lastfm_username,
            'emoji': ['<a:a_kirbychillin:1408046108122288219>'],
            'color': 0x1DB954,
            'title': '{null}',
            'author_icon': '{user.avatar}',
            'author_name': '{user.display_name}\'s Current Track',
            'thumbnail': '{album.cover}',
            'image': '{null}',
            'description': '_ _\n**{track.name}**\nby **{artist.name}**\n_ _',
            'footer': 'Powered by Last.fm',
            'button_emoji': '🎵',
            'button_name': 'Listen on Last.fm',
            'button_url': '{track.url}'
        }

    async def send_error(self, ctx, message):
        """Send error embed"""
        embed = discord.Embed(description=message, color=0xff0000)
        await ctx.send(embed=embed)

    async def send_success(self, ctx, message):
        """Send success embed"""
        embed = discord.Embed(description=message, color=0xffff00)
        await ctx.send(embed=embed)

    def replace_variables(self, text, variables):
        """Replace variables in text with actual values"""
        if text == "{null}":
            return None  # Skip setting the field if {null} is used

        # Replace {gap} with a visible blank line (_ _)
        text = text.replace("{gap}", "_ _")

        # Replace variables in the text
        for var, value in variables.items():
            if value is None:
                value = "Unknown"  # Default value for missing variables
            text = text.replace(f"{{{var}}}", str(value))
        
        return text

    @commands.command()
    async def fmset(self, ctx, lastfm_username: str):
        """Set your Last.fm username"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            self.settings[user_id] = self.get_default_settings(lastfm_username)
        else:
            self.settings[user_id]['lastfm_username'] = lastfm_username
        
        self.save_settings()
        await self.send_success(ctx, f"<:lastfm:1408402685400453172> Last.fm username set to: **{lastfm_username}**")

    @commands.command()
    async def fmreset(self, ctx):
        """Reset your fm settings to default"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "You don't have any settings to reset!")
        
        # Get current username
        username = self.settings[user_id]['lastfm_username']
        
        # Reset to default settings
        self.settings[user_id] = self.get_default_settings(username)
        self.save_settings()
        
        await self.send_success(ctx, "<:lastfm:1408402685400453172> Your FM settings have been reset to default")

    @commands.command()
    async def fmemoji(self, ctx, *emojis):
        """Set custom emojis for your fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "<:lastfm:1408402685400453172> Please set your Last.fm username first with `,fmset`")
        
        if not emojis:
            return await self.send_error(ctx, "Please provide at least one emoji!")
        
        # Validate emojis (standard emojis or emoji IDs)
        valid_emojis = []
        for emoji in emojis:
            if emoji.isdigit():  # Emoji ID
                valid_emojis.append(f"<:custom:{emoji}>")
            else:  # Standard emoji
                valid_emojis.append(emoji)

        self.settings[user_id]['emoji'] = valid_emojis
        self.save_settings()

        await self.send_success(ctx, f"Emojis set to: {' '.join(valid_emojis)}")

    @commands.command()
    async def fmcolor(self, ctx, color: str):
        """Set custom color for your fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "<:lastfm:1408402685400453172> Please set your Last.fm username first with `,fmset`")
        
        try:
            # Detect color format
            if color.startswith('#'):
                color_int = int(color[1:], 16)  # Hex with #
            elif len(color) == 6 and all(c in "0123456789abcdefABCDEF" for c in color):
                color_int = int(color, 16)  # Hex without #
            else:
                color_int = getattr(discord.Color, color.lower())().value  # Named color
        except:
            return await self.send_error(ctx, "Invalid color! Use hex (#FF0000 or FF0000) or color name (e.g., red)")
        
        self.settings[user_id]['color'] = color_int
        self.save_settings()

        # Send success message with the new color
        embed = discord.Embed(
            description=f"<:lastfm:1408402685400453172> {ctx.author.mention} : Color set to: {color}",
            color=color_int
        )
        await ctx.send(embed=embed)

    @commands.command()
    async def fmauthor(self, ctx, *, icon_url: str):
        """Set author icon for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "<:lastfm:1408402685400453172> Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['author_icon'] = icon_url
        self.save_settings()
        await self.send_success(ctx, f"Author icon set to: {icon_url}")

    @commands.command()
    async def fmauthorname(self, ctx, *, name: str):
        """Set author name for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "<:lastfm:1408402685400453172> Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['author_name'] = name
        self.save_settings()
        await self.send_success(ctx, f"Author name set to: {name}")

    @commands.command()
    async def fmthumbnail(self, ctx, *, thumbnail_url: str):
        """Set thumbnail for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "<:lastfm:1408402685400453172> Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['thumbnail'] = thumbnail_url
        self.save_settings()
        await self.send_success(ctx, f"Thumbnail set to: {thumbnail_url}")

    @commands.command()
    async def fmdescription(self, ctx, *, description: str):
        """Set description for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['description'] = description
        self.save_settings()
        await self.send_success(ctx, f"Description set to: {description}")

    @commands.command()
    async def fmfooter(self, ctx, *, footer: str):
        """Set footer for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['footer'] = footer
        self.save_settings()
        await self.send_success(ctx, f"Footer set to: {footer}")

    @commands.command()
    async def fmtitle(self, ctx, *, title: str):
        """Set title for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['title'] = title
        self.save_settings()
        await self.send_success(ctx, f"Title set to: {title}")

    @commands.command()
    async def fmimage(self, ctx, *, image_url: str):
        """Set image for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['image'] = image_url
        self.save_settings()
        await self.send_success(ctx, f"Image set to: {image_url}")

    @commands.command()
    async def fmbuttonemoji(self, ctx, emoji: str):
        """Set button emoji for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['button_emoji'] = emoji
        self.save_settings()
        await self.send_success(ctx, f"Button emoji set to: {emoji}")

    @commands.command()
    async def fmbuttonname(self, ctx, *, name: str):
        """Set button name for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['button_name'] = name
        self.save_settings()
        await self.send_success(ctx, f"Button name set to: {name}")

    @commands.command()
    async def fmbuttonurl(self, ctx, *, url: str):
        """Set button URL for fm embed"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        self.settings[user_id]['button_url'] = url
        self.save_settings()
        await self.send_success(ctx, f"Button URL set to: {url}")

    @commands.command()
    async def fmsave(self, ctx):
        """Save your fm embed configuration as a shareable code"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        # Remove username from saved config
        config = self.settings[user_id].copy()
        config.pop('lastfm_username', None)
        
        # Convert to JSON and compress
        config_json = json.dumps(config)
        compressed = zlib.compress(config_json.encode())
        encoded = base64.urlsafe_b64encode(compressed).decode()
        
        await self.send_success(ctx, f"Your FM embed code:\n```{encoded}```\nUse `,fmload {encoded}` to apply this configuration.")

    @commands.command()
    async def fmupload(self, ctx, name: str, *, code: str):
        """Upload your fm embed configuration as a template"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        try:
            # Decode and decompress to validate
            decoded = base64.urlsafe_b64decode(code.encode())
            decompressed = zlib.decompress(decoded)
            config = json.loads(decompressed.decode())
            
            # Store template
            template_id = f"{ctx.author.id}_{name.lower()}"
            self.templates[template_id] = {
                'name': name,
                'author': ctx.author.id,
                'author_name': str(ctx.author),
                'code': code,
                'config': config
            }
            self.save_templates()
            
            await self.send_success(ctx, f"Template '{name}' uploaded successfully!")
        except:
            await self.send_error(ctx, "Invalid FM embed code!")

    @commands.command()
    async def fmload(self, ctx, *, code: str):
        """Load a premade fm embed configuration"""
        user_id = str(ctx.author.id)
        
        if user_id not in self.settings:
            return await self.send_error(ctx, "Please set your Last.fm username first with `,fmset`")
        
        try:
            # Decode and decompress
            decoded = base64.urlsafe_b64decode(code.encode())
            decompressed = zlib.decompress(decoded)
            config = json.loads(decompressed.decode())
            
            # Update settings
            self.settings[user_id].update(config)
            self.save_settings()
            
            await self.send_success(ctx, "FM embed configuration loaded successfully!")
        except:
            await self.send_error(ctx, "Invalid FM embed code!")

    @commands.command()
    async def fmtemplate(self, ctx):
        """Browse and load fm embed templates"""
        if not self.templates:
            return await self.send_error(ctx, "No templates available!")
        
        # Create embed with template list
        embed = discord.Embed(
            title="FM Embed Templates",
            description="Select a premade template embed for your FM configuration",
            color=0x1DB954
        )
        
        # Group templates by author
        author_templates = {}
        for template_id, template in self.templates.items():
            author_id = template['author']
            if author_id not in author_templates:
                author_templates[author_id] = []
            author_templates[author_id].append(template)
    
        
        # Create dropdown with templates
        options = []
        for template_id, template in self.templates.items():
            options.append(discord.SelectOption(
                label=template['name'][:100],
                description=f"By {template['author_name']}"[:100],
                value=template_id
            ))
        
        # Create select menu
        select = discord.ui.Select(
            placeholder="Choose a template...",
            options=options[:25]  # Discord limits to 25 options
        )
        
        async def select_callback(interaction):
            if interaction.user.id != ctx.author.id:
                await interaction.response.send_message("This menu is not for you!", ephemeral=True)
                return
                
            template_id = select.values[0]
            template = self.templates[template_id]
            
            # Load the template
            user_id = str(ctx.author.id)
            if user_id not in self.settings:
                self.settings[user_id] = self.get_default_settings("temp_username")
            
            self.settings[user_id].update(template['config'])
            self.save_settings()
            
            await interaction.response.send_message(
                f"Template '{template['name']}' loaded successfully!",
                ephemeral=True
            )
        
        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)
        
        await ctx.send(embed=embed, view=view)

    @commands.command()
    async def fmhelp(self, ctx):
        """Get help with the FM commands"""
        help_message = f"""
**FM Commands Help**

• `,fmset <username>` - Set your Last.fm username
• `,fm` - Show your current or last played track
• `,fmreset` - Reset your FM settings to default
• `,fmsave` - Generate a shareable code for your FM embed
• `,fmload <code>` - Load a premade FM embed configuration
• `,fmupload <name> <code>` - Upload your FM configuration as a template
• `,fmtemplate` - Browse and load FM embed templates
• `,fmvariables` - Show all available variables

**Customization Commands:**
• `,fmemoji <emojis>` - Set custom emojis for reactions
• `,fmcolor <color>` - Set embed color (hex or name)
• `,fmauthor <url>` - Set author icon
• `,fmauthorname <name>` - Set author name
• `,fmtitle <title>` - Set embed title
• `,fmthumbnail <url>` - Set thumbnail image
• `,fmimage <url>` - Set large image
• `,fmdescription <text>` - Set description text
• `,fmfooter <text>` - Set footer text
• `,fmbuttonemoji <emoji>` - Set button emoji
• `,fmbuttonname <name>` - Set button name
• `,fmbuttonurl <url>` - Set button URL

For more detailed help, visit: {self.website_url}
        """
        await ctx.send(help_message)

    @commands.command()
    async def fmvariables(self, ctx):
        """Show all available variables for FM embeds"""
        variables_message = """
**Available FM Embed Variables:**

**User Variables:**
- `{user.avatar}` - User's avatar URL
- `{user.server_avatar}` - User's server-specific avatar
- `{user.display_name}` - User's display name
- `{user.name}` - User's username
- `{user.mention}` - Mention the user
- `{author.nickname}` - User's nickname (if any)

**Guild Variables:**
- `{guild.icon}` - Server icon URL
- `{guild.name}` - Server name

**Track Variables:**
- `{track.name}` - Current track name
- `{track.url}` - Track URL on Last.fm
- `{track.plays}` - Track play count
- `{track.duration}` - Track duration
- `{track.release_date}` - Track release date

**Artist Variables:**
- `{artist.name}` - Artist name
- `{artist.url}` - Artist URL on Last.fm
- `{artist.plays}` - Artist play count

**Album Variables:**
- `{album.name}` - Album name
- `{album.cover}` - Album cover art URL
- `{album.covers}` - All available album covers

**Special Variables:**
- `{null}` - Removes the field from the embed

Use these variables in your embed customization commands!
        """
        await ctx.send(variables_message)

    async def get_lastfm_data(self, username):
        """Fetch data from Last.fm API"""
        params = {
            'method': 'user.getrecenttracks',
            'user': username,
            'api_key': self.lastfm_api_key,
            'format': 'json',
            'limit': 1
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.api_url, params=params, timeout=10) as response:
                    if response.status != 200:
                        return None, f"Last.fm api error {response.status}"
                    
                    data = await response.json()
                    
                    if 'error' in data:
                        error_code = data['error']
                        error_msg = data.get('message', 'Unknown error')
                        return None, f"Last.fm error {error_code}: {error_msg}"
                    
                    return data, None
                    
        except Exception as e:
            return None, f"Error: {str(e)}"

    @commands.command()
    async def fm(self, ctx, user: discord.Member = None):
        """Show current playing track from Last.fm (or most recent if not playing)"""
        target_user = user or ctx.author
        user_id = str(target_user.id)

        if user_id not in self.settings:
            return await self.send_error(ctx, "<:lastfm:1408402685400453172> Please set your Last.fm username first with `,fmset <username>`")

        username = self.settings[user_id]['lastfm_username']
        user_settings = self.settings[user_id]

        async with ctx.typing():
            # Get data from Last.fm API
            data, error = await self.get_lastfm_data(username)

            if error:
                return await self.send_error(ctx, error)

            # Process track data
            try:
                tracks = data.get('recenttracks', {}).get('track', [])
                if not tracks:
                    return await self.send_error(ctx, "No recent tracks found!")

                track = tracks[0]
                now_playing = '@attr' in track and track['@attr'].get('nowplaying') == 'true'

                # Extract track info
                track_name = track.get('name', 'Unknown Track')
                artist_name = track.get('artist', {}).get('#text', 'Unknown Artist')
                album_name = track.get('album', {}).get('#text', 'Unknown Album')

                # Create URLs
                track_url = f"https://www.last.fm/music/{urllib.parse.quote(artist_name)}/_/{urllib.parse.quote(track_name)}" if track_name != 'Unknown Track' and artist_name != 'Unknown Artist' else None
                artist_url = f"https://www.last.fm/music/{urllib.parse.quote(artist_name)}" if artist_name != 'Unknown Artist' else None

                track_info = {
                    'track.name': track_name,
                    'track.url': track_url or 'https://www.last.fm',
                    'artist.name': artist_name,
                    'artist.url': artist_url or 'https://www.last.fm',
                    'album.name': album_name,
                    'album.cover': None,
                    'album.covers': [],
                    'artist.plays': 'N/A',
                    'track.plays': 'N/A',
                    'track.duration': 'N/A',
                    'track.release_date': 'Unknown'
                }

                # Get all images and largest available image
                images = track.get('image', [])
                for image in images:
                    if image.get('#text'):
                        track_info['album.covers'].append(image['#text'])
                        if not track_info['album.cover']:  # Set the first image as cover
                            track_info['album.cover'] = image['#text']

                # For the largest image, use the last one (Last.fm orders from small to large)
                if track_info['album.covers']:
                    track_info['album.cover'] = track_info['album.covers'][-1]

                # User/guild variables
                user_vars = {
                    'user.avatar': str(target_user.avatar.url) if target_user.avatar else str(target_user.default_avatar.url),
                    'user.server_avatar': str(target_user.guild_avatar.url) if target_user.guild_avatar else track_info['album.cover'],
                    'user.display_name': target_user.display_name,
                    'user.name': target_user.name,
                    'user.mention': target_user.mention,
                    'author.nickname': target_user.nick or target_user.display_name,
                    'guild.icon': str(ctx.guild.icon.url) if ctx.guild.icon else None,
                    'guild.name': ctx.guild.name
                }

                # Combine all variables
                all_vars = {**track_info, **user_vars}

                # Create embed with custom settings
                embed = discord.Embed(
                    color=user_settings.get('color', 0x1DB954)
                )

                # Set title (skip if {null})
                title = self.replace_variables(user_settings.get('title', '{null}'), all_vars)
                if title is not None:
                    embed.title = title

                # Set author (skip if {null})
                author_name = self.replace_variables(user_settings.get('author_name', '{user.display_name}\'s Current Track'), all_vars)
                author_icon = self.replace_variables(user_settings.get('author_icon', '{user.avatar}'), all_vars)

                if author_name is not None and author_icon is not None:
                    embed.set_author(name=author_name, icon_url=author_icon)
                elif author_name is not None:
                    embed.set_author(name=author_name)

                # Set description (skip if {null})
                description = self.replace_variables(user_settings.get('description', '_ _\n**{track.name}**\nby **{artist.name}**\n_ _'), all_vars)
                if description is not None:
                    embed.description = description

                # Set thumbnail (skip if {null})
                thumbnail = self.replace_variables(user_settings.get('thumbnail', '{album.cover}'), all_vars)
                if thumbnail and thumbnail != 'None' and thumbnail != '{null}':
                    embed.set_thumbnail(url=thumbnail)

                # Set image (skip if {null})
                image = self.replace_variables(user_settings.get('image', '{null}'), all_vars)
                if image and image != 'None' and image != '{null}':
                    embed.set_image(url=image)

                # Set footer (skip if {null})
                footer = self.replace_variables(user_settings.get('footer', 'Powered by Last.fm'), all_vars)
                if footer is not None:
                    embed.set_footer(text=footer)
                    embed.timestamp = datetime.utcnow()  # Only set timestamp if footer is not null

                # Update title based on whether currently playing
                if not now_playing:
                    if not embed.title:
                        embed.title = f"Last played by {target_user.display_name}"
                    else:
                        embed.title += f" (Last played by {target_user.display_name})"

                # Create view with button if configured
                view = None
                button_url = self.replace_variables(user_settings.get('button_url', '{track.url}'), all_vars)
                button_name = self.replace_variables(user_settings.get('button_name', 'Listen on Last.fm'), all_vars)

                if button_url and button_url != '{null}' and button_name and button_name != '{null}':
                    button_emoji = self.replace_variables(user_settings.get('button_emoji', '🎵'), all_vars)
                    view = discord.ui.View()

                    if button_emoji and button_emoji != '{null}':
                        try:
                            button = discord.ui.Button(
                                label=button_name,
                                url=button_url,
                                emoji=button_emoji
                            )
                        except:
                            button = discord.ui.Button(
                                label=button_name,
                                url=button_url
                            )
                    else:
                        button = discord.ui.Button(
                            label=button_name,
                            url=button_url
                        )

                    view.add_item(button)

                # Send embed
                message = await ctx.send(embed=embed, view=view)

                # Add reactions (only if currently playing)
                if now_playing:
                    for emoji in user_settings.get('emoji', ['<a:a_kirbychillin:1408046108122288219>']):
                        try:
                            await message.add_reaction(emoji)
                        except:
                            pass

                # Check for special bot messages in next 5 seconds
                await self.cleanup_special_bot(ctx)

            except Exception as e:
                await self.send_error(ctx, f"Error processing track: {str(e)}")

    async def cleanup_special_bot(self, ctx):
        """Delete messages from special bot within 5 seconds"""
        await asyncio.sleep(5)  # Wait 5 seconds
        
        try:
            async for message in ctx.channel.history(limit=10, after=datetime.utcnow() - timedelta(seconds=10)):
                if message.author.id == self.special_bot_id and message.created_at > datetime.utcnow() - timedelta(seconds=5):
                    await message.delete()
        except:
            pass  # Ignore deletion errors

async def setup(bot):
    await bot.add_cog(LastFMCog(bot))