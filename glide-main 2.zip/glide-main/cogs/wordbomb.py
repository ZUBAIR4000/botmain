import discord
import asyncio
import random
import aiohttp
from discord.ext import commands
from typing import Dict, Set, List

class WordBombGame(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_games: Dict[int, dict] = {}  # channel_id: game_state
        self.dictionary_api = "https://api.dictionaryapi.dev/api/v2/entries/en/"

    @commands.command(name="wordbomb")
    async def start_word_bomb(self, ctx):
        """Start a Word Bomb game"""
        # Check for active game in channel
        if ctx.channel.id in self.active_games:
            await ctx.send("A game is already active in this channel")
            return
            
        # Create game embed
        embed = discord.Embed(
            title="Word Bomb Minigame",
          
            color=0xFAFAFA()
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_footer(text="React with ✅ to join - starting in 20 secs")
        
        message = await ctx.send(embed=embed)
        await message.add_reaction('✅')
        
        # Initialize game state
        self.active_games[ctx.channel.id] = {
            'message_id': message.id,
            'participants': {},
            'used_words': set(),
            'game_state': 'joining',
            'host_id': ctx.author.id
        }
        
        # Wait for participants
        await asyncio.sleep(20)
        
        # Verify game still exists
        if ctx.channel.id not in self.active_games:
            return
            
        game = self.active_games[ctx.channel.id]
        
        # Check if we have participants
        if not game['participants']:
            await ctx.send("no one joined :(")
            del self.active_games[ctx.channel.id]
            return
            
        # Start the game
        game['game_state'] = 'playing'
        game['player_order'] = list(game['participants'].keys())
        random.shuffle(game['player_order'])
        game['current_player_index'] = 0
        game['current_letter'] = random.choice('abcdefghijklmnopqrstuvwxyz')
        
        await ctx.send(
             
            f"First letter: **{game['current_letter'].upper()}**"
        )
        await self.play_round(ctx, game)
        
    async def is_valid_word(self, word: str, starting_letter: str) -> bool:
        """Check if a word is valid using dictionary API"""
        if not word.isalpha():
            return False
            
        if word[0].lower() != starting_letter.lower():
            return False
            
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.dictionary_api}{word}") as response:
                    return response.status == 200
        except Exception:
            return False
            
    async def play_round(self, ctx, game):
        """Play a round of Word Bomb"""
        # Get current player
        player_id = game['player_order'][game['current_player_index']]
        player = ctx.guild.get_member(player_id)
        lives = game['participants'][player_id]['lives']

        # Skip eliminated players
        if lives <= 0:
            game['current_player_index'] = (game['current_player_index'] + 1) % len(game['player_order'])
            await self.play_round(ctx, game)
            return

        letter = game['current_letter']
        await ctx.send(
            f"⏱️ {player.mention} type a word starting with **{letter.upper()}**!"
        )

        def check(m):
            return (
                m.channel.id == ctx.channel.id and
                m.author.id == player_id and
                not m.author.bot
            )

        try:
            while True:
                msg = await self.bot.wait_for('message', timeout=5.0, check=check)
                word = msg.content.strip().lower()

                # Ignore already used or invalid words, do not move to next player
                if word in game['used_words']:
                    continue
                if not await self.is_valid_word(word, letter):
                    continue

                # Valid word!
                await msg.add_reaction('✅')
                game['used_words'].add(word)
                last_letter = word[-1]
                game['current_letter'] = last_letter
                break  # End the loop and move to next player

        except asyncio.TimeoutError:
            # Timeout handling (subtract life)
            lives_left = game['participants'][player_id]['lives'] = lives - 1
            if lives_left > 0:
                await ctx.send(f"{player.mention} has **{lives_left} {'life' if lives_left == 1 else 'lives'}** remaining.")
            else:
                await ctx.send(
                    f"💥 **{player.mention}** is eliminated"
                )

        # Move to next player
        game['current_player_index'] = (game['current_player_index'] + 1) % len(game['player_order'])

        # Continue to next round or end game
        await self.check_game_status(ctx, game)
    
    async def check_game_status(self, ctx, game):
        """Check if game should continue or end"""
        # Count active players
        active_players = [
            uid for uid in game['player_order'] 
            if game['participants'][uid]['lives'] > 0
        ]
        
        if len(active_players) == 0:
            await ctx.send("💥 **Game over!** All players eliminated!")
            del self.active_games[ctx.channel.id]
        elif len(active_players) == 1:
            winner = ctx.guild.get_member(active_players[0])
            await ctx.send(f"🏆 **{winner.mention} wins the wordbomb.**")
            del self.active_games[ctx.channel.id]
        else:
            await asyncio.sleep(1.5)
            await self.play_round(ctx, game)
    
    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
        """Handle reaction-based game joining"""
        # Ignore bot reactions
        if user.bot:
            return
            
        # Check if reaction is in a game channel
        channel_id = reaction.message.channel.id
        if channel_id not in self.active_games:
            return
            
        game = self.active_games[channel_id]
        
        # Validate game state and reaction
        if (game['game_state'] == 'joining' and 
            reaction.message.id == game['message_id'] and 
            str(reaction.emoji) == '✅'):
            
            # Initialize player with 2 lives
            if user.id not in game['participants']:
                game['participants'][user.id] = {
                    'lives': 2,
                    'username': str(user)
                }

async def setup(bot):
    await bot.add_cog(WordBombGame(bot))