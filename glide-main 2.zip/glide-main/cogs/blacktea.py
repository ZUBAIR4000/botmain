import discord
from discord.ext import commands
import asyncio
import random
import aiohttp

class BlackTeaGame:
    def __init__(self):
        # Only 3-letter combinations
        self.letter_combinations = [
"ack", "act", "ade", "age", "aid", "ail", "aim", "air", "ale", "all", "alm", "alt", "amp", "and", "ant", "any",
"ape", "app", "are", "ark", "arm", "art", "ary", "ash", "ask", "asp", "ast", "ate", "ath", "att", "ave", "awk",
"bad", "bag", "bal", "ban", "bar", "bas", "bat", "bay", "bed", "beg", "bel", "ben", "ber", "bes", "bet", "bid",
"big", "bin", "bio", "bit", "ble", "bli", "blo", "blu", "boa", "bob", "bod", "bog", "bol", "bon", "boo", "bor",
"box", "boy", "bra", "bre", "bri", "bro", "bru", "bug", "bul", "bun", "bur", "bus", "but",
"cab", "cad", "cal", "cam", "can", "cap", "car", "cas", "cat", "ced", "cel", "cen", "cer", "ces", "cha", "che",
"chi", "cho", "chr", "cil", "cin", "cir", "cit", "cla", "cle", "cli", "clo", "clu", "coa", "cob", "cod", "col",
"com", "con", "cop", "cor", "cos", "cot", "cou", "cow", "cox", "cra", "cre", "cri", "cro", "cru", "cry", "cub",
"cue", "cul", "cum", "cup", "cur", "cut",
"dab", "dad", "dam", "dan", "dar", "day", "dea", "deb", "dec", "ded", "dee", "def", "del", "dem", "den", "der",
"des", "det", "dev", "dew", "dex", "dic", "did", "die", "dif", "dig", "dim", "din", "dip", "dir", "dis", "dit",
"div", "doc", "dog", "dol", "dom", "don", "doo", "dor", "dos", "dot", "dow", "dry", "dub", "due", "dug", "dul",
"dum", "dur", "dus", "dye",
"eal", "ean", "ear", "eas", "eat", "ebb", "ech", "eco", "ect", "eda", "ede", "edi", "edo", "eff", "egg", "ego",
"egr", "eic", "eil", "eir", "eke", "eld", "ele", "eli", "ell", "elm", "elo", "els", "ely", "ema", "eme", "emo",
"emp", "emu", "enc", "end", "ene", "eng", "eni", "ens", "ent", "enu", "eon", "eor", "eos", "epa", "epi", "ept",
"equ", "era", "ere", "erg", "eri", "ern", "ero", "err", "ers", "ert", "ery", "esc", "ese", "esh", "esi", "esk",
"esp", "est", "eta", "eth", "eti", "ety", "eum", "eup", "eur", "eve", "evi", "evo", "exa", "exc", "exe", "exp",
"eye",
"fac", "fad", "fan", "far", "fas", "fat", "fax", "fea", "fed", "fee", "fel", "fen", "fer", "fes", "fet", "feu",
"few", "fib", "fic", "fid", "fie", "fig", "fil", "fin", "fir", "fis", "fit", "fix", "flu", "fly", "foc", "fog",
"fol", "for", "fox", "fra", "fre", "fri", "fro", "fru", "fry", "ful", "fun", "fur",
"gad", "gag", "gal", "gam", "gan", "gap", "gar", "gas", "gat", "gee", "gel", "gem", "gen", "geo", "ger", "get",
"gig", "gil", "gin", "gir", "giv", "glad?","gla", "gle", "gli", "glo", "glu", "gly", "gnu", "gob", "god", "gof",
"gol", "gom", "gon", "goo", "gor", "got", "gov", "gox", "gra", "gre", "gri", "gro", "gru", "gry", "gua", "gue",
"guf", "gul", "gum", "gun", "gut", "guy", "gym",
"had", "hag", "hah", "hal", "ham", "han", "hap", "har", "has", "hat", "hav", "hay", "hed", "hee", "hem", "hen",
"her", "hes", "hew", "hex", "hey", "hid", "hie", "him", "hin", "hip", "hir", "his", "hit", "hob", "hod", "hoe",
"hog", "hol", "hom", "hon", "hoo", "hop", "hor", "hos", "hot", "how", "hub", "hue", "hug", "hum", "hun", "hur",
"hut", "hym", "hyp",
"ice", "ich", "ick", "ico", "icy", "ide", "idi", "ido", "ids", "idy", "ied", "ier", "ies", "iff", "ifs", "igg",
"ign", "igo", "ill", "ilm", "ilo", "ils", "ilt", "ily", "ima", "imb", "ime", "imi", "imm", "imp", "imu", "ina",
"inc", "ind", "ine", "ing", "inh", "ini", "ink", "inn", "ino", "ins", "int", "inv", "ion", "ior", "ios", "iot",
"ire", "irg", "iri", "irk", "iro", "irr", "isa", "isc", "ise", "ish", "isi", "isk", "isl", "ism", "iso", "ist",
"ita", "ite", "ith", "itl", "its", "ity", "iva", "ive", "ivi", "ivy",
"jab", "jag", "jam", "jar", "jaw", "jay", "jee", "jet", "jig", "jin", "job", "joe", "jog", "jon", "jot", "joy",
"jud", "jug", "jut",
"kab", "kai", "kam", "kan", "kap", "kar", "kas", "kat", "kay", "kea", "ked", "kee", "kel", "ken", "kep", "ker",
"ket", "key", "kid", "kil", "kin", "kip", "kit", "kob", "kon", "kop", "kor", "kos",
"lab", "lac", "lad", "lag", "lam", "lan", "lap", "lar", "las", "lat", "law", "lax", "lay", "lea", "led", "lee",
"leg", "lei", "lem", "len", "ler", "les", "let", "lev", "lex", "ley", "lib", "lic", "lid", "lie", "lif", "lig",
"lim", "lin", "lip", "lis", "lit", "liv", "lob", "log", "lom", "lon", "loo", "lop", "lor", "los", "lot", "low",
"lox", "loy", "lug", "lum", "lun", "lur", "lus", "lux", "lye",
"mac", "mad", "mag", "man", "map", "mar", "mas", "mat", "max", "may", "med", "meg", "mel", "men", "mer", "mes",
"met", "mew", "mid", "mil", "min", "mir", "mis", "mix", "mob", "mod", "mog", "moi", "mol", "mom", "mon", "moo",
"mor", "mos", "mot", "mou", "mov", "mud", "mug", "mul", "mum", "mun", "mus", "mut",
"nab", "nag", "nah", "nam", "nap", "nar", "nas", "nat", "nav", "nay", "nea", "neb", "nec", "ned", "nee", "neg",
"nek", "nel", "nem", "nen", "ner", "nes", "net", "new", "nib", "nic", "nid", "nie", "nil", "nim", "nin", "nip",
"nit", "nix", "nob", "nod", "nog", "noh", "nom", "non", "nor", "nos", "not", "now", "nub", "nud", "nug", "nul",
"nun", "nut",
"oak", "oat", "oba", "obe", "obi", "obo", "obs", "oca", "och", "ock", "oco", "oct", "odd", "ode", "odi", "odo",
"ods", "off", "oft", "oga", "ogd", "oge", "ogg", "ogl", "ogo", "ogs", "ohm", "oil", "oin", "oir", "oka", "oke",
"oki", "ola", "old", "ole", "oli", "olo", "olt", "oma", "omb", "ome", "omi", "omo", "oms", "one", "ong", "oni",
"ono", "ons", "ont", "ood", "oom", "oon", "oor", "oos", "oot", "opa", "ope", "opi", "ops", "opt", "orb", "orc",
"ord", "ore", "ori", "ork", "orl", "orn", "oro", "ors", "ort", "ory", "ose", "osi", "oss", "ost", "ota", "ote",
"oth", "oti", "oto", "ots", "ott", "oud", "oug", "our", "ous", "out", "ova", "ove", "ovi", "owl", "own", "oxo",
"oxy",
"pac", "pad", "pag", "pal", "pan", "pap", "par", "pas", "pat", "paw", "pay", "pea", "ped", "pee", "peg", "pel",
"pen", "per", "pes", "pet", "pew", "pex", "phi", "pho", "phy", "pia", "pic", "pid", "pie", "pig", "pil", "pin",
"pip", "pir", "pis", "pit", "pix", "pla", "ple", "pli", "plo", "plu", "ply", "pod", "poi", "pol", "pon", "pop",
"por", "pos", "pot", "pow", "poz", "pre", "pri", "pro", "pry", "psi", "pub", "pud", "pug", "pul", "pun", "pur",
"pus", "put", "pye",
"qua", "que", "qui", "quo",
"rab", "rac", "rad", "rag", "rah", "rai", "ram", "ran", "rap", "rar", "ras", "rat", "raw", "ray", "rea", "red",
"ree", "ref", "reg", "rei", "rel", "ren", "rep", "res", "ret", "rev", "rex", "rez", "rho", "rib", "ric", "rid",
"rie", "rif", "rig", "rim", "rin", "rip", "ris", "rit", "riv", "rob", "roc", "rod", "roe", "rog", "rol", "rom",
"ron", "roo", "rop", "ror", "ros", "rot", "row", "roy", "rub", "rue", "rug", "rum", "run", "rus", "rut", "rye",
"sab", "sac", "sad", "sag", "sal", "san", "sap", "sar", "sat", "saw", "say", "sca", "sce", "sch", "sci", "sco",
"scr", "sea", "sec", "sed", "see", "seg", "sei", "sel", "sem", "sen", "sep", "ser", "ses", "set", "sev", "sew",
"sex", "sha", "she", "shi", "sho", "shr", "shy", "sib", "sic", "sid", "sie", "sig", "sil", "sim", "sin", "sip",
"sir", "sis", "sit", "six", "ske", "ski", "sky", "sly", "smi", "smo", "sna", "sne", "sno", "soh", "sol", "son",
"sop", "sor", "sos", "sot", "sou", "sow", "spa", "spe", "spi", "spo", "spr", "spy", "squ", "sri", "sta", "ste",
"sti", "sto", "str", "stu", "sty", "sub", "sud", "sue", "suf", "sug", "sui", "sum", "sun", "sup", "sur", "sus",
"sut", "swa", "swe", "swi", "swo", "syl", "syn",
"tab", "tac", "tag", "tak", "tal", "tam", "tan", "tap", "tar", "tas", "tat", "tax", "tea", "ted", "tee", "tel",
"tem", "ten", "ter", "tes", "tet", "tex", "the", "thi", "tho", "thr", "thy", "tic", "tid", "tie", "til", "tim",
"tin", "tip", "tir", "tis", "tit", "tle", "tly", "toa", "tob", "tod", "toe", "tog", "tom", "ton", "too", "top",
"tor", "tos", "tot", "tou", "tow", "toy", "tri", "tro", "tru", "try", "tub", "tug", "tum", "tun", "tur", "tus",
"tut", "twi", "two", "tye",
"uct", "ude", "udi", "udo", "ugu", "ule", "uli", "ulo", "ult", "ume", "umi", "umo", "ump", "una", "und", "une",
"ung", "uni", "unk", "uno", "uns", "unt", "upc", "upd", "upe", "upl", "upo", "ups", "upt", "ura", "ure", "urg",
"uri", "urn", "uro", "urs", "urt", "ury", "use", "ush", "usi", "usk", "usp", "uss", "ust", "usu", "uta", "ute",
"uth", "uti", "uto", "uts", "utu",
"vac", "val", "van", "var", "vas", "vat", "vau", "vec", "ved", "vel", "ven", "ver", "ves", "vet", "vex", "via",
"vic", "vid", "vie", "vig", "vil", "vin", "vir", "vis", "vit", "viv", "vow", "vox", "vul",
"wac", "wad", "wag", "wah", "wan", "war", "was", "wax", "way", "web", "wed", "wee", "wel", "wen", "wer", "wet",
"wha", "whe", "whi", "who", "why", "wig", "wil", "win", "wir", "wis", "wit", "wok", "won", "woo", "wow", "wry",
"yak", "yam", "yap", "yaw", "yay", "yea", "yed", "yep", "yes", "yet", "yew", "yip", "yob", "yod", "yok", "yon",
"you", "yow", "yuk", "yum", "yup",
"zag", "zap", "zas", "zed", "zee", "zen", "zep", "zig", "zip", "zit", "zoo", "zat", "zor", "zum", "zyg"
]

    def get_random_letters(self):
        return random.choice(self.letter_combinations)

class BlackTeaCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.game = BlackTeaGame()
        self.sessions = {}
        self.check_emoji = "✅"

    @commands.command(name='blacktea')
    async def blacktea(self, ctx):
        """Start a BlackTea word game"""
        # Check if there's already a game in this channel
        for session_id, session in self.sessions.items():
            if session['channel_id'] == ctx.channel.id and session['started']:
                await ctx.send("There's already a game running in this channel!")
                return
        
        # Create embed for game setup
        embed = discord.Embed(
            title="🍵 BlackTea Word Game",
            description="React with ✅ to join the game!\nEach player has 3 lives.\nFind words containing the given 3 letters.",
            color=0x2b2d31
        )
        
        embed.set_footer(text="Game will start in 30 seconds")
        
        # Send message and add reaction
        message = await ctx.send(embed=embed)
        await message.add_reaction("✅")
        
        # Store game session
        self.sessions[message.id] = {
            'message_id': message.id,
            'channel_id': ctx.channel.id,
            'players': {},
            'started': False,
            'current_turn': None,
            'current_letters': None
        }
        
        # Wait for players to join
        await asyncio.sleep(30)
        
        # Check if we have at least 2 players
        session = self.sessions[message.id]
        if len(session['players']) < 2:
            await ctx.send("Not enough players joined the game. Game cancelled.")
            del self.sessions[message.id]
            return
        
        # Start the game
        session['started'] = True
        await self.start_game(ctx, message.id)

    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
        """Handle players joining the game"""
        # Ignore bot reactions
        if user.bot:
            return
        
        # Check if this is a game join reaction
        if reaction.emoji == "✅" and reaction.message.id in self.sessions:
            session = self.sessions[reaction.message.id]
            
            # Only allow joining before game starts
            if not session['started'] and user.id not in session['players']:
                session['players'][user.id] = {
                    'name': user.name,
                    'lives': 3
                }
                
                # Update the message with player list
                embed = reaction.message.embeds[0]
                players_list = [f"<@{player_id}>" for player_id in session['players']]
                
                # Clear existing fields and rebuild
                embed.clear_fields()
                embed.add_field(
                    name="How to Play",
                    value="1. React to join\n2. When it's your turn, you'll get 3 letters\n3. Find a word containing those letters\n4. Type your answer within 10 seconds\n5. Only timeout eliminates players\n6. Last player standing wins!",
                    inline=False
                )
                embed.add_field(
                    name="Players Joined",
                    value="\n".join(players_list) if players_list else "No players yet",
                    inline=False
                )
                
                await reaction.message.edit(embed=embed)

    async def start_game(self, ctx, message_id):
        """Start the game with the joined players"""
        session = self.sessions[message_id]
        channel = self.bot.get_channel(session['channel_id'])
        
        # Create player list
        players = list(session['players'].keys())
        random.shuffle(players)  # Randomize turn order
        
        # Send game start message
    

        
        # Game loop
        game_round = 1
        while len(players) > 1:
            # Send round announcement
          
            
            # Show player status
            
            
           
            await channel.send(embed=embed)
            await asyncio.sleep(2)
            
            # Process each player's turn
            eliminated_players = []
            for player_id in players:
                if len(players) <= 1:
                    break  # Game over if only one player left
                
                # Skip players with no lives
                if session['players'][player_id]['lives'] <= 0:
                    eliminated_players.append(player_id)
                    continue
                
                # Get player and set current turn
                player = self.bot.get_user(player_id)
                session['current_turn'] = player_id
                letters = self.game.get_random_letters()
                session['current_letters'] = letters
                
                # Send turn message
                turn_message = await channel.send(
                    f"<:007_tiktok_yummy:1408792387618078821> {player.mention} write a word containing **{letters.upper()}** \n"
                   
                )
                
                # Set up response check
                def check(m):
                    return m.author.id == player_id and m.channel.id == channel.id and letters.lower() in m.content.lower()
                
                # Wait for response with timeout
                try:
                    # Wait for a correct response (word containing the letters)
                    response_msg = await self.bot.wait_for('message', check=check, timeout=10.0)
                    
                    # Player responded with a word containing the required letters
                    word = response_msg.content.strip()
                    await response_msg.add_reaction(self.check_emoji)

                
                except asyncio.TimeoutError:
                    # Timeout - player loses a life
                    await channel.send(f"⏰ Time's up! {player.mention} have lost a life.")
                    session['players'][player_id]['lives'] -= 1
                    
                    # Check if player is eliminated
                    if session['players'][player_id]['lives'] <= 0:
                        await channel.send(f"**{player.mention}** is eliminated")
                        eliminated_players.append(player_id)
                
                # Small delay between turns
                await asyncio.sleep(1)
            
            # Remove eliminated players
            for player_id in eliminated_players:
                if player_id in players:
                    players.remove(player_id)
            
            game_round += 1
        
        # Game over - determine winner
        if players:
            winner_id = players[0]
            winner = self.bot.get_user(winner_id)
            
            # Create winner embed
            embed = discord.Embed(
                title="🎉 Game Over!",
                description=f"{winner.mention} wins the BlackTea game! 🏆",
                color=0xf1c40f
            )
            
            # Add all players' status
            player_status = []
            for player_id, data in session['players'].items():
                player = self.bot.get_user(player_id)
                status = "🏆 WINNER" if player_id == winner_id else f"Eliminated ({data['lives']} ❤️)"
                player_status.append(f"{player.mention} - {status}")
            
            embed.add_field(
                name="Final Results",
                value="\n".join(player_status) if player_status else "No players",
                inline=False
            )
            
            await channel.send(embed=embed)
        else:
            await channel.send("😵 The game ended with no winner!")
        
        # Clean up session
        del self.sessions[message_id]

async def setup(bot):
    await bot.add_cog(BlackTeaCog(bot))