import discord
from discord.ext import commands
from datetime import datetime

class Age(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="age")
    async def age(self, ctx, user: discord.User = None):
        """Check how old a Discord account is."""
        user = user or ctx.author  # If no user is mentioned, default to command invoker

        # Account creation time
        created_at = user.created_at.replace(tzinfo=None)
        now = datetime.utcnow()
        delta = now - created_at

        # Format into days, years, months approx.
        years, remainder = divmod(delta.days, 365)
        months, days = divmod(remainder, 30)

        # Build age string
        parts = []
        if years > 0:
            parts.append(f"{years} year{'s' if years != 1 else ''}")
        if months > 0:
            parts.append(f"{months} month{'s' if months != 1 else ''}")
        if days > 0:
            parts.append(f"{days} day{'s' if days != 1 else ''}")
        if not parts:  # If account is less than 1 day old
            parts.append("less than a day")

        age_str = ", ".join(parts)

        await ctx.send(f"{user.mention}'s account is **{age_str}** old")

async def setup(bot):
    await bot.add_cog(Age(bot))
