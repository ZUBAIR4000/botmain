import discord
from discord.ext import commands
import random

class NumbersGame(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_games = {}  # {channel_id: {"number": int, "range": int, "starter": int}}

    @commands.command(name="numbers")
    @commands.has_permissions(manage_channels=True)
    async def numbers_game(self, ctx, channel: discord.TextChannel, max_range: int):
        """Start a numbers guessing game"""
        # Validate range
        if max_range < 2 or max_range > 1000000:
            return await ctx.send(embed=self.create_embed(
                f"Max range must be between 2 and 1,000,000",
                color=discord.Color.red()
            ))
        
        # Check if game already running in channel
        if channel.id in self.active_games:
            return await ctx.send(embed=self.create_embed(
                f"There's already an active game in {channel.mention}",
                color=discord.Color.red()
            ))
        
        # Generate random number
        secret_number = random.randint(1, max_range)
        
        # Store game data
        self.active_games[channel.id] = {
            "number": secret_number,
            "range": max_range,
            "starter": ctx.author.id
        }
        
        # Send public embed
        embed = self.create_embed(
            f"**Guess the number**\n"
            f"Guess a number between **1** and **{max_range:,}**\n"
            f"correct guess wins\n\n"
            f"host: {ctx.author.mention}",
            color=discord.Color.green()
        )
        await channel.send(embed=embed)
        
        # DM the secret number to game starter
        try:
            await ctx.author.send(f"Shh! The secret number is: **{secret_number}**")
        except discord.Forbidden:
            await ctx.send(embed=self.create_embed(
                f"{ctx.author.mention} enable dms "
               ,
                color=discord.Color.orange()
            ))

    @commands.Cog.listener()
    async def on_message(self, message):
        # Ignore bots and non-game channels
        if message.author.bot or message.channel.id not in self.active_games:
            return
        
        game_data = self.active_games[message.channel.id]
        
        # Try to parse number from message
        try:
            guess = int(message.content.strip())
        except ValueError:
            return  # Not a number - ignore message
        
        # Validate guess is within range
        if guess < 1 or guess > game_data["range"]:
            return
        
        # Check guess
        if guess == game_data["number"]:
            # Winner!
            embed = self.create_embed(
                f"🎉 **{message.author.mention} guessed the correct number!** 🎉\n"
                f"The number was **{game_data['number']}**\n\n"
                f"Game started by: <@{game_data['starter']}>",
                color=discord.Color.gold()
            )
            winner_msg = await message.channel.send(embed=embed)
            await winner_msg.add_reaction("🎊")  # Congrats emoji
            del self.active_games[message.channel.id]
        else:
            # Add hint reaction
            hint_emoji = "⬆️" if guess < game_data["number"] else "⬇️"
            await message.add_reaction(hint_emoji)

    def create_embed(self, description, color=discord.Color.default()):
        """Helper to create consistent embeds"""
        return discord.Embed(
            description=description,
            color=color
        )

async def setup(bot):
    await bot.add_cog(NumbersGame(bot))