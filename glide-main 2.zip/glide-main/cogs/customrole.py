import discord
from discord.ext import commands
import json
import os
import re
from typing import Optional, Union

class CustomRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.base_role_id = 1312048236596297838
        self.data_file = "custom_roles.json"
        self.authorized_users = set()
        self.user_roles = {}
        self.load_data()

    def load_data(self):
        """Load authorized users and custom roles from JSON file"""
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                self.authorized_users = set(data.get("authorized_users", []))
                self.user_roles = data.get("user_roles", {})

    def save_data(self):
        """Save authorized users and custom roles to JSON file"""
        data = {
            "authorized_users": list(self.authorized_users),
            "user_roles": self.user_roles
        }
        with open(self.data_file, 'w') as f:
            json.dump(data, f)

    async def send_embed(self, ctx, message: str, embed_type: str = "normal"):
        """Send formatted embed response"""
        color_map = {
            "normal": discord.Color.default(),
            "error": discord.Color.red(),
            "notice": discord.Color.gold()
        }
        emoji_map = {
            "normal": "<:yes1:1389288766291574804>",
            "error": "<:no:1399080437556576356>",
            "notice": "<:warn:1400131848428064859>"
        }
        
        embed = discord.Embed(
            description=f"{emoji_map[embed_type]} {ctx.author.mention}: {message}",
            color=color_map[embed_type]
        )
        await ctx.send(embed=embed)

    def is_authorized(self, user_id: int, guild: discord.Guild) -> bool:
        """Check if user is authorized or has admin perms"""
        member = guild.get_member(user_id)
        return (user_id in self.authorized_users or 
                (member and (member.guild_permissions.administrator or 
                             member.guild_permissions.manage_roles)))

    @commands.group(name="customrole", aliases=["cr"], invoke_without_command=True)
    async def custom_role(self, ctx):
        """Custom role management system"""
        await ctx.send_help(ctx.command)

    @custom_role.command(name="authorize", aliases=["auth"])
    @commands.has_permissions(administrator=True)
    async def authorize_user(self, ctx, user: Union[discord.Member, discord.User]):
        """Authorize a user to use custom role commands"""
        if user.id in self.authorized_users:
            self.authorized_users.remove(user.id)
            await self.send_embed(ctx, f"Removed {user.mention} from authorized users.", "normal")
        else:
            self.authorized_users.add(user.id)
            await self.send_embed(ctx, f"Added {user.mention} to authorized users.", "normal")
        self.save_data()

    @custom_role.command(name="unauthorize", aliases=["unauth"])
    @commands.has_permissions(administrator=True)
    async def unauthorize_user(self, ctx, user: Union[discord.Member, discord.User]):
        """Unauthorize a user from using custom role commands"""
        if user.id in self.authorized_users:
            self.authorized_users.remove(user.id)
            await self.send_embed(ctx, f"Removed {user.mention} from authorized users.", "normal")
            self.save_data()
        else:
            await self.send_embed(ctx, f"{user.mention} is not authorized.", "notice")

    @custom_role.command(name="create")
    async def create_role(self, ctx, *, role_name: Optional[str] = None):
        """Create a custom role for yourself"""
        if not self.is_authorized(ctx.author.id, ctx.guild):
            return await self.send_embed(ctx, "You're not authorized to use this command.", "error")
        
        if str(ctx.author.id) in self.user_roles:
            return await self.send_embed(ctx, "You already have a custom role.", "error")
        
        base_role = ctx.guild.get_role(self.base_role_id)
        if not base_role:
            return await self.send_embed(ctx, "Base role not found. Contact server admin.", "error")
        
        # Default role name if not provided
        if not role_name:
            role_name = f"{ctx.author.display_name}'s Role"
        
        try:
            new_role = await ctx.guild.create_role(
                name=role_name,
                color=discord.Color.default(),
                hoist=True,
                mentionable=True,
                reason=f"Custom role for {ctx.author}"
            )
            
            # Position the new role just above the base role
            await new_role.edit(position=base_role.position + 1)
            
            # Assign the role to the user
            await ctx.author.add_roles(new_role)
            
            # Save to database
            self.user_roles[str(ctx.author.id)] = new_role.id
            self.save_data()
            
            await self.send_embed(ctx, f"Created custom role {new_role.mention} for you!", "normal")
        except discord.Forbidden:
            await self.send_embed(ctx, "I don't have permissions to create roles.", "error")
        except discord.HTTPException as e:
            await self.send_embed(ctx, f"Failed to create role: {str(e)}", "error")

    @custom_role.command(name="rename")
    async def rename_role(self, ctx, *, new_name: str):
        """Rename your custom role"""
        if not self.is_authorized(ctx.author.id, ctx.guild):
            return await self.send_embed(ctx, "You're not authorized to use this command.", "error")
        
        role_id = self.user_roles.get(str(ctx.author.id))
        if not role_id:
            return await self.send_embed(ctx, "You don't have a custom role to rename.", "error")
        
        role = ctx.guild.get_role(role_id)
        if not role:
            return await self.send_embed(ctx, "Your custom role was not found.", "error")
        
        try:
            await role.edit(name=new_name)
            await self.send_embed(ctx, f"Renamed your role to {new_name}", "normal")
        except discord.Forbidden:
            await self.send_embed(ctx, "I don't have permissions to edit roles.", "error")
        except discord.HTTPException as e:
            await self.send_embed(ctx, f"Failed to rename role: {str(e)}", "error")

    @custom_role.command(name="share")
    async def share_role(self, ctx, user: discord.Member):
        """Share your custom role with another user"""
        if not self.is_authorized(ctx.author.id, ctx.guild):
            return await self.send_embed(ctx, "You're not authorized to use this command.", "error")
        
        role_id = self.user_roles.get(str(ctx.author.id))
        if not role_id:
            return await self.send_embed(ctx, "You don't have a custom role to share.", "error")
        
        role = ctx.guild.get_role(role_id)
        if not role:
            return await self.send_embed(ctx, "Your custom role was not found.", "error")
        
        try:
            await user.add_roles(role)
            await self.send_embed(ctx, f"Shared your role {role.mention} with {user.mention}", "normal")
        except discord.Forbidden:
            await self.send_embed(ctx, "I don't have permissions to add roles.", "error")
        except discord.HTTPException as e:
            await self.send_embed(ctx, f"Failed to share role: {str(e)}", "error")

    @custom_role.command(name="color", aliases=["colour"])
    async def change_color(self, ctx, *, color_input: str):
        """Change your custom role color"""
        if not self.is_authorized(ctx.author.id, ctx.guild):
            return await self.send_embed(ctx, "You're not authorized to use this command.", "error")
        
        role_id = self.user_roles.get(str(ctx.author.id))
        if not role_id:
            return await self.send_embed(ctx, "You don't have a custom role to modify.", "error")
        
        role = ctx.guild.get_role(role_id)
        if not role:
            return await self.send_embed(ctx, "Your custom role was not found.", "error")
        
        # Parse color input
        color = None
        try:
            # Hex code (3 or 6 digit)
            if re.match(r'^#?[0-9a-fA-F]{3}$', color_input) or re.match(r'^#?[0-9a-fA-F]{6}$', color_input):
                color_input = color_input.lstrip('#')
                if len(color_input) == 3:
                    color_input = ''.join([c * 2 for c in color_input])
                color = discord.Color(int(color_input, 16))
            # Decimal color
            elif color_input.isdigit():
                color = discord.Color(int(color_input))
            # Color name
            else:
                color = getattr(discord.Color, color_input.lower())()
        except (ValueError, AttributeError):
            pass
        
        if not color:
            return await self.send_embed(ctx, "Invalid color. Use hex (#RRGGBB), decimal, or color name.", "error")
        
        try:
            await role.edit(color=color)
            await self.send_embed(ctx, f"Changed your role color to {color_input}", "normal")
        except discord.Forbidden:
            await self.send_embed(ctx, "I don't have permissions to edit roles.", "error")
        except discord.HTTPException as e:
            await self.send_embed(ctx, f"Failed to change color: {str(e)}", "error")

    @custom_role.command(name="icon", aliases=["logo", "emoji"])
    async def change_icon(self, ctx, icon_input: Optional[str] = None):
        """Change your custom role icon"""
        if not self.is_authorized(ctx.author.id, ctx.guild):
            return await self.send_embed(ctx, "You're not authorized to use this command.", "error")
        
        role_id = self.user_roles.get(str(ctx.author.id))
        if not role_id:
            return await self.send_embed(ctx, "You don't have a custom role to modify.", "error")
        
        role = ctx.guild.get_role(role_id)
        if not role:
            return await self.send_embed(ctx, "Your custom role was not found.", "error")
        
        # Check for attachment in replied message or current message
        icon_url = None
        if ctx.message.reference:
            try:
                replied_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
                if replied_msg.attachments:
                    icon_url = replied_msg.attachments[0].url
            except discord.NotFound:
                pass
        
        # Check for attachment in current message
        if not icon_url and ctx.message.attachments:
            icon_url = ctx.message.attachments[0].url
        
        # Check for emoji or URL in input
        if not icon_url and icon_input:
            # Check if it's a custom emoji
            emoji_match = re.match(r'<a?:[a-zA-Z0-9_]+:(\d+)>', icon_input)
            if emoji_match:
                emoji_id = emoji_match.group(1)
                ext = 'gif' if icon_input.startswith('<a:') else 'png'
                icon_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{ext}"
            # Check if it's a URL
            elif icon_input.startswith(('http://', 'https://')):
                icon_url = icon_input
        
        if not icon_url:
            return await self.send_embed(ctx, "Please provide an image URL, emoji, or attach an image.", "error")
        
        try:
            await role.edit(display_icon=icon_url)
            await self.send_embed(ctx, "Updated your role icon!", "normal")
        except discord.Forbidden:
            await self.send_embed(ctx, "I don't have permissions to edit roles.", "error")
        except discord.HTTPException as e:
            await self.send_embed(ctx, f"Failed to change icon: {str(e)}", "error")

    @custom_role.command(name="delete", aliases=["clear"])
    async def delete_role(self, ctx):
        """Delete your custom role"""
        if not self.is_authorized(ctx.author.id, ctx.guild):
            return await self.send_embed(ctx, "You're not authorized to use this command.", "error")
        
        role_id = self.user_roles.get(str(ctx.author.id))
        if not role_id:
            return await self.send_embed(ctx, "You don't have a custom role to delete.", "error")
        
        role = ctx.guild.get_role(role_id)
        if not role:
            return await self.send_embed(ctx, "Your custom role was not found.", "error")
        
        try:
            await role.delete()
            del self.user_roles[str(ctx.author.id)]
            self.save_data()
            await self.send_embed(ctx, "Deleted your custom role.", "normal")
        except discord.Forbidden:
            await self.send_embed(ctx, "I don't have permissions to delete roles.", "error")
        except discord.HTTPException as e:
            await self.send_embed(ctx, f"Failed to delete role: {str(e)}", "error")

    @custom_role.command(name="reset")
    @commands.has_permissions(administrator=True)
    async def reset_all_roles(self, ctx):
        """Reset all custom roles (admin only)"""
        # Create confirmation view
        view = discord.ui.View(timeout=60.0)
        
        async def confirm_callback(interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("You didn't initiate this command.", ephemeral=True)
                return
            
            deleted = 0
            for user_id, role_id in list(self.user_roles.items()):
                role = ctx.guild.get_role(role_id)
                if role:
                    try:
                        await role.delete()
                        deleted += 1
                    except discord.HTTPException:
                        pass
            
            self.user_roles = {}
            self.save_data()
            
            await interaction.response.edit_message(
                content=None,
                embed=discord.Embed(
                    description=f"<:yes1:1389288766291574804> {ctx.author.mention}: Deleted {deleted} custom roles.",
                    color=discord.Color.green()
                ),
                view=None
            )
        
        async def cancel_callback(interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("You didn't initiate this command.", ephemeral=True)
                return
            
            await interaction.response.edit_message(
                content=None,
                embed=discord.Embed(
                    description=f"<:warn:1400131848428064859> {ctx.author.mention}: Role reset cancelled.",
                    color=discord.Color.gold()
                ),
                view=None
            )
        
        confirm_button = discord.ui.Button(label="Confirm", style=discord.ButtonStyle.danger)
        confirm_button.callback = confirm_callback
        cancel_button = discord.ui.Button(label="Cancel", style=discord.ButtonStyle.secondary)
        cancel_button.callback = cancel_callback
        
        view.add_item(confirm_button)
        view.add_item(cancel_button)
        
        embed = discord.Embed(
            description=f"<:warn:1400131848428064859> {ctx.author.mention}: Are you sure you want to delete ALL custom roles?",
            color=discord.Color.gold()
        )
        await ctx.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(CustomRoles(bot))