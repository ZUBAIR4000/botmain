import discord
from discord.ext import commands
from typing import Union, List

class MassBan(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='ban')
    @commands.has_permissions(ban_members=True)
    async def mass_ban(self, ctx, *, users: str):
        """
        Ban multiple users by ID or username
        Format: ,ban user1 user2 user3...
        """
        # Parse input into individual user references
        user_refs = users.split()
        
        if not user_refs:
            return await ctx.send("Please provide at least one user ID or mention.")

        results = []
        success_count = 0
        failed_count = 0

        for user_ref in user_refs:
            try:
                # Try to convert to user ID (handles mentions and raw IDs)
                user = await commands.UserConverter().convert(ctx, user_ref)
                
                # Check if user is bannable
                if user == ctx.author:
                    results.append(f"{user_ref}: Can't ban yourself")
                    failed_count += 1
                    continue
                    
                if user == self.bot.user:
                    results.append(f"{user_ref}: Can't ban me")
                    failed_count += 1
                    continue
                    
                # Attempt ban
                try:
                    await ctx.guild.ban(user, reason=f"Mass ban by {ctx.author}")
                    results.append(f"{user} (ID: {user.id}): ✅ Banned")
                    success_count += 1
                except discord.Forbidden:
                    results.append(f"{user}: ❌ Missing permissions")
                    failed_count += 1
                except discord.HTTPException as e:
                    results.append(f"{user}: ❌ Error: {str(e)}")
                    failed_count += 1
                    
            except commands.UserNotFound:
                # Try raw ID if username failed
                if user_ref.isdigit():
                    try:
                        user = await self.bot.fetch_user(int(user_ref))
                        await ctx.guild.ban(user, reason=f"Mass ban by {ctx.author}")
                        results.append(f"ID {user_ref}: ✅ Banned")
                        success_count += 1
                    except discord.NotFound:
                        results.append(f"{user_ref}: ❌ User not found")
                        failed_count += 1
                    except discord.Forbidden:
                        results.append(f"ID {user_ref}: ❌ Missing permissions")
                        failed_count += 1
                    except discord.HTTPException as e:
                        results.append(f"ID {user_ref}: ❌ Error: {str(e)}")
                        failed_count += 1
                else:
                    results.append(f"{user_ref}: ❌ Invalid user reference")
                    failed_count += 1

        # Create results embed
        embed = discord.Embed(
            title="Ban Results",
            color=discord.Color.green() if success_count > 0 else discord.Color.red()
        )
        
        embed.add_field(
            name="Summary",
            value=f"✅ Success: {success_count}\n❌ Failed: {failed_count}",
            inline=False
        )
        
        # Split results into chunks if too long
        result_chunks = [results[i:i + 10] for i in range(0, len(results), 10)]
        
        for i, chunk in enumerate(result_chunks):
            embed.add_field(
                name=f"Details {'(cont.)' if i > 0 else ''}",
                value="\n".join(chunk),
                inline=False
            )
        
        embed.set_footer(text=f"Requested by {ctx.author}")
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(MassBan(bot))