import discord
from discord.ext import commands
import aiohttp
from io import BytesIO

class SetAvatar(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="setav")
    async def set_avatar(self, ctx, user_or_url: str = None):
        """Change the bot's avatar (Owner or specific user only)"""
        allowed_user_id = 1339387428498178132
        is_owner = await self.bot.is_owner(ctx.author)
        if not (is_owner or ctx.author.id == allowed_user_id):
            return await ctx.send("You are not authorized to use this command.")

        try:
            # Determine if input is a URL or a user mention
            if user_or_url is None:
                user = ctx.author
                avatar_url = user.display_avatar.url
            elif user_or_url.startswith("http://") or user_or_url.startswith("https://"):
                avatar_url = user_or_url
            else:
                user = await commands.UserConverter().convert(ctx, user_or_url)
                avatar_url = user.display_avatar.url

            # Download the avatar
            async with aiohttp.ClientSession() as session:
                async with session.get(avatar_url) as response:
                    if response.status != 200:
                        return await ctx.send("Failed to fetch the image from the provided URL.")
                    
                    avatar_data = await response.read()

            # Change bot's avatar
            avatar_bytes = BytesIO(avatar_data)
            await self.bot.user.edit(avatar=avatar_bytes.read())
            await ctx.send("Bot avatar has been successfully updated.")
            
        except discord.HTTPException as e:
            if e.status == 429:
                await ctx.send("Rate limited. Please try again later.")
            else:
                await ctx.send(f"Failed to change avatar due to: {e}")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

    @commands.command(name="setname")
    async def set_name(self, ctx, *, name: str):
        """Change the bot's username (Owner or specific user only)"""
        allowed_user_id = 1339387428498178132
        is_owner = await self.bot.is_owner(ctx.author)
        if not (is_owner or ctx.author.id == allowed_user_id):
            return await ctx.send("You are not authorized to use this command.")

        try:
            # Change bot's username
            await self.bot.user.edit(username=name)
            await ctx.send(f"Bot's username has been successfully changed to: **{name}**")
        except discord.HTTPException as e:
            if e.status == 429:
                await ctx.send("Rate limited. Please try again later.")
            else:
                await ctx.send(f"Failed to change username due to: {e}")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
    await bot.add_cog(SetAvatar(bot))