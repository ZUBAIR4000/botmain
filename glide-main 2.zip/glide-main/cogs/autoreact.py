import os
import json
import discord
from discord.ext import commands

# File to store reaction triggers
REACTION_FILE = "reactions.json"

class ReactionCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.reactions = {}
        self.load_reactions()

    def load_reactions(self):
        """Load reactions from JSON file"""
        try:
            if os.path.exists(REACTION_FILE):
                with open(REACTION_FILE, 'r') as f:
                    self.reactions = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.reactions = {}

    def save_reactions(self):
        """Save reactions to JSON file"""
        with open(REACTION_FILE, 'w') as f:
            json.dump(self.reactions, f, indent=2)

    @commands.group(invoke_without_command=True)
    async def reaction(self, ctx):
        """Manage automatic reactions"""
        await ctx.send_help(ctx.command)

    @reaction.command(name="add")
    @commands.has_permissions(manage_messages=True)
    async def add_reaction(self, ctx, trigger: str, emoji: str):
        """
        Add a reaction trigger
        Example: ,reaction add hello 👍
        Example: ,reaction add awesome :custom_emoji:
        """
        guild_id = str(ctx.guild.id)
        
        # Initialize guild storage if needed
        if guild_id not in self.reactions:
            self.reactions[guild_id] = {}
        
        # Try to convert to custom emoji if possible
        try:
            # Attempt to convert to custom emoji
            custom_emoji = await commands.EmojiConverter().convert(ctx, emoji)
            emoji_str = f"{custom_emoji.id}"  # Store custom emoji ID
        except commands.EmojiNotFound:
            # Treat as Unicode emoji
            emoji_str = emoji
        
        # Add or update trigger
        self.reactions[guild_id][trigger.lower()] = emoji_str
        self.save_reactions()
        
        # Show confirmation with actual emoji
        try:
            display_emoji = self.bot.get_emoji(int(emoji_str)) if emoji_str.isdigit() else emoji_str
        except:
            display_emoji = emoji_str
            
        await ctx.send(f"✅ Added reaction: When someone says `{trigger}`, I'll react with {display_emoji}")

    @reaction.command(name="remove")
    @commands.has_permissions(manage_messages=True)
    async def remove_reaction(self, ctx, trigger: str):
        """Remove a reaction trigger"""
        guild_id = str(ctx.guild.id)
        trigger = trigger.lower()
        
        if guild_id in self.reactions and trigger in self.reactions[guild_id]:
            # Get emoji for confirmation message
            emoji_str = self.reactions[guild_id][trigger]
            
            # Try to display the emoji
            try:
                if emoji_str.isdigit():
                    emoji = self.bot.get_emoji(int(emoji_str))
                    display = str(emoji) if emoji else f":unknown:{emoji_str}:"
                else:
                    display = emoji_str
            except:
                display = emoji_str
            
            # Remove trigger
            del self.reactions[guild_id][trigger]
            
            # Clean up guild if empty
            if not self.reactions[guild_id]:
                del self.reactions[guild_id]
            
            self.save_reactions()
            await ctx.send(f"✅ Removed reaction for `{trigger}` (was {display})")
        else:
            await ctx.send(f"❌ No reaction found for `{trigger}`")

    @reaction.command(name="list")
    async def list_reactions(self, ctx):
        """List all reaction triggers"""
        guild_id = str(ctx.guild.id)
        
        if guild_id in self.reactions and self.reactions[guild_id]:
            embed = discord.Embed(
                title="Reaction Triggers",
                description="Here are all configured auto-reactions:",
                color=discord.Color.blue()
            )
            
            for trigger, emoji_str in self.reactions[guild_id].items():
                try:
                    # Try to display custom emoji
                    if emoji_str.isdigit():
                        emoji = self.bot.get_emoji(int(emoji_str))
                        display = str(emoji) if emoji else f":unknown:{emoji_str}:"
                    else:
                        display = emoji_str
                except:
                    display = emoji_str
                
                embed.add_field(name=f"Trigger: `{trigger}`", value=f"Reaction: {display}", inline=False)
            
            await ctx.send(embed=embed)
        else:
            await ctx.send("ℹ️ No reaction triggers configured for this server.")

    @commands.Cog.listener()
    async def on_message(self, message):
        """Check messages for reaction triggers"""
        if message.author.bot or not message.guild:
            return
        
        guild_id = str(message.guild.id)
        
        # Skip if no reactions configured for this guild
        if guild_id not in self.reactions or not self.reactions[guild_id]:
            return
        
        content = message.content.lower()
        triggered = False
        emoji_str = ""
        
        # Check each trigger
        for trigger, e_str in self.reactions[guild_id].items():
            if trigger in content:
                triggered = True
                emoji_str = e_str
                break  # Only react once per message
        
        if triggered:
            try:
                # Get the emoji to react with
                if emoji_str.isdigit():
                    # Custom emoji
                    emoji = self.bot.get_emoji(int(emoji_str))
                    if not emoji:
                        # Try fetching if not in cache
                        try:
                            emoji = await message.guild.fetch_emoji(int(emoji_str))
                        except:
                            return  # Emoji not found
                else:
                    # Unicode emoji
                    emoji = emoji_str
                
                if emoji:
                    await message.add_reaction(emoji)
            except discord.HTTPException as e:
                print(f"Failed to add reaction: {e}")
            except Exception as e:
                print(f"Error with reaction: {e}")

async def setup(bot):
    await bot.add_cog(ReactionCog(bot))