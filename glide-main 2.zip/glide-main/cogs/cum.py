# cogs/roleplay.py
import discord
from discord.ext import commands
import random

# Manual list
GIFS = [
    "https://media.discordapp.net/attachments/834500528426844160/881904994863951873/cum.gif?ex=680b9907&is=680a4787&hm=19aeefed6e41f5823fe70e032fbd3bcc189a5914d59ea39fba5e4ef51429c837&=&width=360&height=202",
    "https://media.discordapp.net/attachments/834500528426844160/1151397084436627466/cum.gif?ex=680b2518&is=6809d398&hm=650de3cbd3fbf23c3250c7acef87acf829a6e5304930d946cc580e44fc436204&=&width=360&height=270",
    "https://media.discordapp.net/attachments/834500528426844160/834501127272923217/cum.gif?ex=680b307d&is=6809defd&hm=9203d5c3a42abad4e46ea51a8417a3dd9a5f55f0661f7a811b04e6a70a310ac5&=&width=450&height=337",
    "https://media.discordapp.net/attachments/834500528426844160/881905088447250443/cum.gif?ex=680b991e&is=680a479e&hm=43aa5cf383d1cbddcd0c7908ab6e788a6567c4b2d86270366318c1d619060e90&=&width=405&height=211",
    "https://media.discordapp.net/attachments/834500528426844160/834500991411945482/cum.gif?ex=680b305c&is=6809dedc&hm=5e965c45524cdcad792d1cafed3da29911aea8a4b53f34ce9d66188d42550d7f&=&width=540&height=302",
    "https://media.discordapp.net/attachments/834500528426844160/834500917847916605/cum.gif?ex=680b304b&is=6809decb&hm=db975eb673fe73eef75a2dbdc28eb9fe0511765a5c17e4d77a2e87896da3a09b&=&width=474&height=269",
    "https://media.discordapp.net/attachments/834500528426844160/834500940002230332/cum.gif?ex=680b3050&is=6809ded0&hm=5c3755efaba1dad0b60512be436f85e52226a57e99fd4d50b5dd533cd1655123&=&width=450&height=256",
    "https://media.discordapp.net/attachments/834500528426844160/834501054635704420/cum.gif?ex=680b306b&is=6809deeb&hm=3a366db65cac4e3f4a4a242c95e081a5eaf696a64b42674dd4d8b16b2dd7d102&=&width=360&height=274",
    "https://media.discordapp.net/attachments/834500528426844160/834500951191584809/cum.gif?ex=680b3053&is=6809ded3&hm=94d633da96e4299c3bfa9114cbfc81c774480e5a3a2a658c9726f1f6c88fd32f&=&width=414&height=232",
    "https://media.discordapp.net/attachments/834500528426844160/834501103655190548/cum.gif?ex=680b3077&is=6809def7&hm=97bd11ce65beea84042557a592036c8a5a11b54ec1c206fc11e86e300f44561e&=&width=450&height=254",
    "https://media.discordapp.net/attachments/834500528426844160/839471906024849408/cum.gif?ex=680b79a3&is=680a2823&hm=985a4d1f4234925a11e71ea230c6556b1d344b605b71e960f692f3f1996c1e44&=&width=644&height=353",
    "https://media.discordapp.net/attachments/834500528426844160/834501092069998622/cum.gif?ex=680b3074&is=6809def4&hm=ca2a51e0d08e0aad4c4b0706b61003888e00e06865988223acd75a6f3e2143a6&=&width=360&height=270",
    "https://media.discordapp.net/attachments/834500528426844160/834501078753476639/cum.gif?ex=680b3071&is=6809def1&hm=64fa8f9863f03ae27320a672553cf4cf0826799a5a69f48def90e1affac203a3&=&width=360&height=179",
    "https://media.discordapp.net/attachments/834500528426844160/834501065961111622/cum.gif?ex=680b306e&is=6809deee&hm=3cb94e3d9299187ec78f9f9d04b2eb7bbc322daeb10cf37e8c5f4cc5144c867a&=&width=441&height=248",
]

# Helper to format ordinals
def ordinal(n: int) -> str:
    if 11 <= (n % 100) <= 13:
        return f"{n}th"
    return f"{n}{['th','st','nd','rd','th'][n % 10 if n % 10 < 4 else 0]}"

class CumView(discord.ui.View):
    def __init__(self, author, target, count, gif_url, send_embed_callback):
        super().__init__(timeout=30)
        self.author = author
        self.target = target
        self.count = count
        self.gif_url = gif_url
        self.send_embed_callback = send_embed_callback

    @discord.ui.button(label="Approve", style=discord.ButtonStyle.green)
    async def approve(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.target.id:
            await interaction.response.send_message("this isnt your request", ephemeral=True)
            return
        await interaction.response.defer()
        await self.send_embed_callback(interaction)
        self.stop()

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.red)
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.target.id:
            await interaction.response.send_message("this is not your embed", ephemeral=True)
            return
        await interaction.response.send_message(
            f"{self.target.mention} rejected to be cumed by {self.author.mention}"
        )
        self.stop()

class cum(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.counts: dict[tuple[int,int], int] = {}

    @commands.command(name="cum", aliases=["cumm"])
    async def cum(self, ctx, target: discord.Member = None):
        """
        NSFW roleplay: show a hentai cum gif with a counter.
        Usage: ,cum @user
        """
       

        # Validate target
        if target is None or target.bot:
            return await ctx.send(":x: | Please mention a user to cum on.")

        if target.id == ctx.author.id:
            return await ctx.send(":x: | You can't cum on yourself.")

        # Increment per-pair count
        key = (ctx.author.id, target.id)
        count = self.counts.get(key, 0) + 1
        self.counts[key] = count

        # Choose a manual GIF randomly
        gif_url = random.choice(GIFS)

        async def send_cum_embed(interaction):
            embed = discord.Embed(
                description=(
                    f"**{ctx.author.display_name}** cummed on **{target.display_name}** "
                    f"for the {ordinal(count)} time! 🤭"
                ),
                color=discord.Color.purple()
            )
            embed.set_image(url=gif_url)
            await interaction.channel.send(content=target.mention, embed=embed)

        view = CumView(ctx.author, target, count, gif_url, send_cum_embed)
        embed = discord.Embed(
            title="Consent Required",
            description=f"{target.mention}, do you want to be cumed on by {ctx.author.mention}?"
        )


async def setup(bot):
    await bot.add_cog(cum(bot))