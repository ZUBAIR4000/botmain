import discord
from discord.ext import commands
import asyncio

class GhostPing(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='gp')
    @commands.has_permissions(administrator=True)
    async def ghost_ping(self, ctx):
        """Ghost ping all online users (Admin only)"""
        if ctx.guild is None:
            return await ctx.send("no.")

        # Get all online members (not offline/bots)
        online_members = [
            member for member in ctx.guild.members
            if not member.bot 
            and member.status != discord.Status.offline
            and member != ctx.author
        ]

        if not online_members:
            return await ctx.send("nope..")

        # DM user that the process is starting
        try:
            await ctx.author.send(f" {len(online_members)} online users...")
        except:
            pass  # Can't DM user, but continue anyway

        # Ping each user individually
        for member in online_members:
            try:
                # Send ping and delete immediately
                msg = await ctx.send(f"{member.mention}")
                await msg.delete()
                
                # Small delay to avoid rate limits
                await asyncio.sleep(1)
                
            except discord.Forbidden:
                continue
            except discord.HTTPException:
                continue

        # Send completion DM
        try:
            await ctx.author.send(f"✅ Successfully ghost pinged {len(online_members)} online users!")
        except:
            pass

        # Delete the original command message
        try:
            await ctx.message.delete()
        except:
            pass

    @ghost_ping.error
    async def ghost_ping_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("no")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("stfu cunt.")

async def setup(bot):
    await bot.add_cog(GhostPing(bot))