import discord
from discord.ext import commands
import random
import asyncio

class TicTacToeButton(discord.ui.Button):
    def __init__(self, x: int, y: int):
        super().__init__(style=discord.ButtonStyle.gray, label="\u200b", row=y)
        self.x = x
        self.y = y
        
    async def callback(self, interaction: discord.Interaction):
        assert self.view is not None
        view: TicTacToeView = self.view
        
        # Check if it's the player's turn
        if interaction.user != view.current_player:
            await interaction.response.send_message("It's not your turn!", ephemeral=True)
            return
            
        # Check if the position is already taken
        if view.board[self.y][self.x] != 0:
            await interaction.response.send_message("This position is already taken!", ephemeral=True)
            return
            
        # Make the move
        if view.current_player == view.player1:
            view.board[self.y][self.x] = 1
            self.emoji = view.x_emoji
            self.style = discord.ButtonStyle.red
            view.current_player = view.player2
        else:
            view.board[self.y][self.x] = 2
            self.emoji = view.o_emoji
            self.style = discord.ButtonStyle.green
            view.current_player = view.player1
            
        self.disabled = True
        
        # Check for win or draw
        winner = view.check_winner()
        if winner:
            view.disable_all_items()
            if winner == 1:
                view.title = f"{view.player1.mention} won the game! 🎉"
            elif winner == 2:
                view.title = f"{view.player2.mention} won the game! 🎉"
            else:
                view.title = "It's a draw! 🤝"
        else:
            # Update turn indicator
            view.title = f"{view.player1.display_name} **VS** {view.player2.display_name}\n{view.current_player.mention}'s turn"
        
        # Update the message
        await interaction.response.edit_message(content=view.title, view=view)
        
        # If playing against CPU and game isn't over, make CPU move
        if view.is_cpu and view.current_player == view.player2 and not winner:
            await asyncio.sleep(1)  # Small delay for realism
            await view.make_cpu_move()

class TicTacToeView(discord.ui.View):
    def __init__(self, player1: discord.Member, player2: discord.Member, x_emoji: str, o_emoji: str, is_cpu: bool = False):
        super().__init__(timeout=180)  # 3 minute timeout
        self.player1 = player1
        self.player2 = player2
        self.current_player = player1
        self.x_emoji = x_emoji
        self.o_emoji = o_emoji
        self.is_cpu = is_cpu
        self.board = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]  # 0 = empty, 1 = X, 2 = O
        
        # Create title
        self.title = f"{player1.display_name} **VS** {player2.display_name}\n{self.current_player.mention}'s turn"
        
        # Create 3x3 grid of buttons
        for y in range(3):
            for x in range(3):
                self.add_item(TicTacToeButton(x, y))
    
    def check_winner(self):
        """Check if there's a winner or draw"""
        # Check rows
        for row in self.board:
            if row[0] == row[1] == row[2] != 0:
                return row[0]
        
        # Check columns
        for col in range(3):
            if self.board[0][col] == self.board[1][col] == self.board[2][col] != 0:
                return self.board[0][col]
        
        # Check diagonals
        if self.board[0][0] == self.board[1][1] == self.board[2][2] != 0:
            return self.board[0][0]
        if self.board[0][2] == self.board[1][1] == self.board[2][0] != 0:
            return self.board[0][2]
        
        # Check for draw
        if all(cell != 0 for row in self.board for cell in row):
            return 3  # Draw
        
        return 0  # No winner yet
    
    async def make_cpu_move(self):
        """Make a move for the CPU player"""
        # Find all empty positions
        empty_positions = []
        for y in range(3):
            for x in range(3):
                if self.board[y][x] == 0:
                    empty_positions.append((x, y))
        
        if not empty_positions:
            return  # No moves left
        
        # Choose a random empty position
        x, y = random.choice(empty_positions)
        
        # Make the move
        self.board[y][x] = 2
        
        # Find and update the button
        for child in self.children:
            if hasattr(child, 'x') and hasattr(child, 'y'):
                if child.x == x and child.y == y:
                    child.emoji = self.o_emoji
                    child.style = discord.ButtonStyle.green
                    child.disabled = True
                    break
        
        self.current_player = self.player1
        
        # Check for win or draw
        winner = self.check_winner()
        if winner:
            self.disable_all_items()
            if winner == 1:
                self.title = f"{self.player1.mention} won the game! 🎉"
            elif winner == 2:
                self.title = f"{self.player2.mention} won the game! 🎉"
            else:
                self.title = "It's a draw! 🤝"
        else:
            # Update turn indicator
            self.title = f"{self.player1.display_name} **VS** {self.player2.display_name}\n{self.current_player.mention}'s turn"
        
        # Update the message
        message = self.message
        await message.edit(content=self.title, view=self)
    
    async def on_timeout(self):
        """Handle view timeout"""
        self.disable_all_items()
        self.title = "Game timed out! ⏰"
        if hasattr(self, 'message'):
            await self.message.edit(content=self.title, view=self)

class TicTacToeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.x_emoji = "<:x_ttt:1410607972576399390>"
        self.o_emoji = "<:o_ttt:1410607924912586793>"
        self.active_games = {}  # Store active games by channel ID

    @commands.command(aliases=['ttt'])
    async def tictactoe(self, ctx, opponent: discord.Member = None):
        """Start a Tic Tac Toe game with another user or CPU"""
        # Check if opponent is valid
       
        
        # Check if opponent is the bot itself (for CPU mode)
        is_cpu = False
        if opponent.id == self.bot.user.id or opponent.name.lower() == "cpu":
            is_cpu = True
            # Create a fake member object for CPU
            class FakeMember:
                def __init__(self):
                    self.display_name = "CPU"
                    self.mention = "CPU"
                    self.id = 0
            opponent = FakeMember()
        
        # Check if opponent is the same as the author
        if not is_cpu and opponent.id == ctx.author.id:
            await ctx.send("?")
            return
        
        # Check if opponent is a bot (other than CPU)
        if not is_cpu and opponent.bot:
            await ctx.send("no")
            return
        
        # Create the game view
        view = TicTacToeView(ctx.author, opponent, self.x_emoji, self.o_emoji, is_cpu)
        
        # Send the game message
        message = await ctx.send(view.title, view=view)
        view.message = message
        
        # Store the game in active games
        self.active_games[message.id] = view

async def setup(bot):
    await bot.add_cog(TicTacToeCog(bot))