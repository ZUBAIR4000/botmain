import discord
import re
import aiohttp
import random
from discord.ext import commands
from discord import ui

class WordHack(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_users = set()
        self.DATAMUSE_API = "https://api.datamuse.com/words"
        self.TARGET_BOT_ID = 432610292342587392

    class WordView(ui.View):
        """View for word hack response"""
        def __init__(self, word):
            super().__init__(timeout=15.0)
            self.word = word

        @ui.button(label="Show Word", style=discord.ButtonStyle.primary)
        async def show_word(self, interaction: discord.Interaction, button: ui.Button):
            """Show the word again"""
            await interaction.response.send_message(
                f"🔍 Word containing the letters: **{self.word}**",
                ephemeral=True
            )

    @commands.command(name="loadhackon")
    async def hack_on(self, ctx):
        """Enable word hack for BlackTea minigame"""
        self.active_users.add(ctx.author.id)
        await ctx.send(
            f"kallichai v1.4 is acitve , keep ur dms on with notifs",
            delete_after=10
        )

    @commands.command(name="loadhackoff")
    async def hack_off(self, ctx):
        """Disable word hack for BlackTea minigame"""
        if ctx.author.id in self.active_users:
            self.active_users.remove(ctx.author.id)
        await ctx.send(
            f"kallichai v1.4 is no longer active.",
            delete_after=10
        )

    async def find_words(self, letter_group: str) -> list:
        """Find words containing the letter group using Datamuse API"""
        params = {
            'sp': f'*{letter_group}*',
            'max': 50,  # Get up to 50 words
            'md': 'd'   # Include definitions
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.DATAMUSE_API, params=params) as response:
                    if response.status != 200:
                        return []
                    data = await response.json()
                    return [word['word'] for word in data if ' ' not in word['word']]
        except Exception:
            return []

    @commands.Cog.listener()
    async def on_message(self, message):
        """Listen for BlackTea minigame prompts and react/respond accordingly"""
        # Ignore messages from bots except the target bot
        if message.author.bot and message.author.id != self.TARGET_BOT_ID:
            return

        # React to BlackTea game start embed
        if message.embeds:
            for embed in message.embeds:
                if (
                    embed.title and "The Black Teaword will start!" in embed.title
                ) or (
                    embed.description and "The Black Teaword will start!" in embed.description
                ):
                    try:
                        await message.add_reaction("✅")
                    except Exception:
                        pass

        # If the message is from the BlackTea bot, check for the prompt
        if message.author.id == self.TARGET_BOT_ID:
            if not message.embeds and ":coffee:" not in message.content:
                return

            # Check for the pattern
            pattern = r"Type a word containing: \*\*([A-Z]{3})\*\*"
            match = re.search(pattern, message.content)
            if not match:
                return

            letter_group = match.group(1).lower()
            mentioned_users = message.mentions

            if not mentioned_users:
                return

            target_user = mentioned_users[0]

            # Check if hack is enabled for this user
            if target_user.id not in self.active_users:
                return

            # Find words containing the letter group
            words = await self.find_words(letter_group)
            if not words:
                return

            # Select a random word
            word = random.choice(words)

            # Send ephemeral message to the user
            try:
                await target_user.send(
                    f"🔍 Word containing **{letter_group.upper()}**: **{word}** ",
                )
            except discord.Forbidden:
                # User has DMs disabled
                pass

        # If another bot mentions this bot, reply with a word from the API if possible
        if (
            message.author.bot
            and message.mentions
            and self.bot.user in message.mentions
        ):
            # Try to extract the letter group
            pattern = r"Type a word containing: \*\*([A-Z]{3})\*\*"
            match = re.search(pattern, message.content)
            if match:
                letter_group = match.group(1).lower()
                words = await self.find_words(letter_group)
                if words:
                    word = random.choice(words)
                    try:
                        await message.channel.send(
                            f"🔍 Word containing **{letter_group.upper()}**: **{word}** ",
                            reference=message
                        )
                    except discord.Forbidden:
                        pass

async def setup(bot):
    await bot.add_cog(WordHack(bot))