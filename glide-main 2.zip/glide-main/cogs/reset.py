import discord
from discord.ext import commands
import asyncio

class ResetCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.reset_active = False

    class ResetConfirmView(discord.ui.View):
        def __init__(self, cog_instance, timeout=30):
            super().__init__(timeout=timeout)
            self.cog = cog_instance
            
        @discord.ui.button(label="CONFIRM RESET", style=discord.ButtonStyle.danger, emoji="💥")
        async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
            if interaction.user.id != self.cog.bot.owner_id:
                await interaction.response.send_message("❌ Only the bot owner can execute this command!", ephemeral=True)
                return
                
            await interaction.response.defer()
            self.cog.reset_active = True
            await self.cog.perform_server_reset(interaction)
            self.stop()
            
        @discord.ui.button(label="CANCEL", style=discord.ButtonStyle.secondary)
        async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
            await interaction.response.edit_message(
                content="🚨 Server reset cancelled. Nothing was changed.",
                view=None,
                embed=None
            )
            self.stop()

    @commands.command(name="reset")
    @commands.is_owner()
    async def reset_server(self, ctx):
        """☠️ COMPLETELY RESET THE SERVER (Owner Only)"""
        if self.reset_active:
            return await ctx.send("⚠️ A reset operation is already in progress.")
            
        # Safety checks
        if ctx.guild is None:
            return await ctx.send("❌ This command can only be used in a server.")
            
        if ctx.guild.owner_id != ctx.author.id:
            return await ctx.send("❌ Only the server owner can initiate a server reset.")
            
        # Create warning embed
        embed = discord.Embed(
            title="☠️ **SERVER RESET CONFIRMATION** ☠️",
            description="This command will **PERMANENTLY DELETE** all channels, roles, emojis, and stickers!",
            color=discord.Color.red()
        )
        embed.add_field(
            name="What will be deleted:",
            value="- All text and voice channels\n- All categories\n- All roles (except @everyone)\n- All emojis\n- All stickers",
            inline=False
        )
        embed.add_field(
            name="Irreversible Action",
            value="This action **CANNOT BE UNDONE**. All server content will be permanently lost!",
            inline=False
        )
        embed.set_footer(text=f"Requested by {ctx.author.display_name}", icon_url=ctx.author.avatar.url)
        embed.set_thumbnail(url="https://media.discordapp.net/attachments/1361730745973866496/1391882101924827136/skull.png?ex=686d83d0&is=686c3250&hm=8c2c0f7c5c2d0d8c8e8b0d8c8e8b0d8c8e8b0d8c8e8b0d8c8e8b0d8c8e8b0d8c8e8b0d8c8e8b&=&width=282&height=282")
        
        # Send confirmation with buttons
        view = self.ResetConfirmView(self)
        await ctx.send(embed=embed, view=view)

    async def perform_server_reset(self, interaction: discord.Interaction):
        guild = interaction.guild
        
        # Create loading message
        status_embed = discord.Embed(
            title="⚙️ **SERVER RESET IN PROGRESS** ⚙️",
            description="This may take several minutes...",
            color=discord.Color.orange()
        )
        status_embed.add_field(name="Current Operation", value="Initializing...", inline=False)
        status_embed.set_footer(text="Do not turn off the bot or server during this process")
        message = await interaction.followup.send(embed=status_embed)
        
        # Step 1: Delete all channels
        status_embed.set_field_at(0, name="Current Operation", value="Deleting channels...", inline=False)
        await message.edit(embed=status_embed)
        
        for channel in guild.channels:
            try:
                await channel.delete(reason="Server reset command")
                await asyncio.sleep(0.5)  # Rate limit prevention
            except Exception as e:
                print(f"Error deleting channel {channel.name}: {e}")
        
        # Step 2: Delete all roles
        status_embed.set_field_at(0, name="Current Operation", value="Deleting roles...", inline=False)
        await message.edit(embed=status_embed)
        
        for role in guild.roles:
            if role.name == "@everyone" or role.managed:
                continue
            try:
                await role.delete(reason="Server reset command")
                await asyncio.sleep(0.3)
            except Exception as e:
                print(f"Error deleting role {role.name}: {e}")
        
        # Step 3: Delete all emojis
        status_embed.set_field_at(0, name="Current Operation", value="Deleting emojis...", inline=False)
        await message.edit(embed=status_embed)
        
        for emoji in guild.emojis:
            try:
                await emoji.delete(reason="Server reset command")
                await asyncio.sleep(0.3)
            except Exception as e:
                print(f"Error deleting emoji {emoji.name}: {e}")
        
        # Step 4: Delete all stickers
        status_embed.set_field_at(0, name="Current Operation", value="Deleting stickers...", inline=False)
        await message.edit(embed=status_embed)
        
        for sticker in guild.stickers:
            try:
                await sticker.delete(reason="Server reset command")
                await asyncio.sleep(0.3)
            except Exception as e:
                print(f"Error deleting sticker {sticker.name}: {e}")
        
        # Final status
        status_embed.title = "✅ **SERVER RESET COMPLETE** ✅"
        status_embed.color = discord.Color.green()
        status_embed.description = "All server content has been permanently deleted!"
        status_embed.set_field_at(0, name="Operations Completed", value="- All channels deleted\n- All roles deleted\n- All emojis deleted\n- All stickers deleted", inline=False)
        status_embed.set_footer(text="Server reset successfully")
        await message.edit(embed=status_embed)
        
        # Reset flag
        self.reset_active = False

    @reset_server.error
    async def reset_error(self, ctx, error):
        if isinstance(error, commands.NotOwner):
            embed = discord.Embed(
                title="Permission Denied",
                description="❌ Only the bot owner can use this command!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(ResetCog(bot))