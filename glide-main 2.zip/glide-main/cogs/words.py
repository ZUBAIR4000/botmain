import discord
from discord.ext import commands

class WordsCounter(commands.Cog):
    @commands.command(name="words")
    async def words(self, ctx):
        """Counts the number of words in the replied message."""
        if not ctx.message.reference or not ctx.message.reference.resolved:
            await ctx.reply("uh")
            return

        replied_message = ctx.message.reference.resolved
        if not isinstance(replied_message, discord.Message):
            await ctx.reply("no")
            return

        word_count = len(replied_message.content.split())
        await ctx.reply(f"**{word_count}** words.", mention_author=True)

async def setup(bot):
        await bot.add_cog(WordsCounter(bot))