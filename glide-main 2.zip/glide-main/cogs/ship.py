from discord.ext import commands
import discord
import random
import aiohttp
import asyncio
from io import BytesIO
from PIL import Image, ImageDraw, ImageOps

class ShipCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.heart_url = "https://i.postimg.cc/W43TLwPN/heartfull.png"
        self.broken_heart_url = "https://i.postimg.cc/PpK3V8Xt/image-removebg-preview.png"
        self.emoji_ids = {
            "fullstart": 1387489338505298003,
            "fullbetween": 1387489635126612111,
            "fullend": 1387489847953850450,
            "emptystart": 1387489989499162664,
            "emptybetween": 1387489734200266752,
            "emptyend": 1387489792647761930
        }

    def _get_emoji(self, name):
        return f"<:{name}:{self.emoji_ids[name]}>".encode('utf-8').decode('unicode_escape')

    def _generate_progress_bar(self, percentage):
        filled = round(percentage / 100 * 14)
        bar = []
        for i in range(14):
            if i < filled:
                bar.append(self._get_emoji("fullstart" if i == 0 else "fullend" if i == 13 else "fullbetween"))
            else:
                bar.append(self._get_emoji("emptystart" if i == 0 else "emptyend" if i == 13 else "emptybetween"))
        return "".join(bar)

    async def _download_image(self, session, url):
        async with session.get(url) as response:
            return BytesIO(await response.read())

    def _make_circular(self, image):
        size = (100, 100)
        mask = Image.new('L', size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, *size), fill=255)
        output = ImageOps.fit(image.convert("RGBA"), size)
        output.putalpha(mask)
        return output

    def _create_composite_image(self, user1_img, user2_img, heart_img):
        user1_circle = self._make_circular(Image.open(user1_img))
        user2_circle = self._make_circular(Image.open(user2_img))
        heart = Image.open(heart_img).convert("RGBA").resize((50, 50))
        composite = Image.new("RGBA", (250, 100), (0, 0, 0, 0))
        composite.paste(user1_circle, (0, 0))
        composite.paste(heart, (100, 25))
        composite.paste(user2_circle, (150, 0))
        img_byte_arr = BytesIO()
        composite.save(img_byte_arr, format="PNG")
        img_byte_arr.seek(0)
        return img_byte_arr

    @commands.hybrid_command(name="ship", aliases=["match"])
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def ship(self, ctx, user1: discord.Member = None, user2: discord.Member = None):
        """
        Ship two users together! If only one user is mentioned, ships you with them.
        If no users are mentioned, ships you with a random member.
        Usage: ,ship @user1 @user2
        """
        if user1 and user2:
            pass  # use both mentioned users
        elif user1:
            user2 = ctx.author
        else:
            user1 = ctx.author
            user2 = random.choice([m for m in ctx.guild.members if not m.bot and m != user1])

        percentage = random.randint(0, 100)
        async with aiohttp.ClientSession() as session:
            user1_avatar, user2_avatar, heart_img = await asyncio.gather(
                self._download_image(session, user1.display_avatar.url),
                self._download_image(session, user2.display_avatar.url),
                self._download_image(session, self.heart_url if percentage > 40 else self.broken_heart_url)
            )
            composite = await self.bot.loop.run_in_executor(
                None,
                self._create_composite_image,
                user1_avatar,
                user2_avatar,
                heart_img
            )
        embed = discord.Embed(
            title=f"{user1.display_name} 💞 {user2.display_name}",
            description=f"**{percentage}%**\n{self._generate_progress_bar(percentage)}",
            color=0xff69b4
        )
        file = discord.File(composite, filename="ship.png")
        embed.set_image(url="attachment://ship.png")
        await ctx.send(file=file, embed=embed)

    @ship.error
    async def ship_cooldown_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            embed = discord.Embed(
                description=f"⏳ Please wait **{error.retry_after:.1f}** seconds before using this command again.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
        else:
            raise error

async def setup(bot):
    await bot.add_cog(ShipCog(bot))