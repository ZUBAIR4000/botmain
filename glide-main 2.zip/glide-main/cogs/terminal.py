import discord
from discord.ext import commands, tasks
import asyncio
import os

CHANNEL_ID = 1326445662589550633  # Channel to send terminal output

class TerminalMonitor(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.last_line = ""
        self.monitor_task = self.monitor_terminal.start()

    def cog_unload(self):
        self.monitor_task.cancel()

    @tasks.loop(seconds=3)
    async def monitor_terminal(self):
        await self.bot.wait_until_ready()
        channel = self.bot.get_channel(CHANNEL_ID)
        if not channel:
            return

        # You can change this to your actual log file or command output
        log_file = "bot.log"
        if not os.path.exists(log_file):
            return

        try:
            with open(log_file, "r") as f:
                lines = f.readlines()
                if lines:
                    last = lines[-1].strip()
                    if last != self.last_line:
                        self.last_line = last
                        # Send only new lines
                        await channel.send(f"```{last}```")
        except Exception as e:
            print(f"TerminalMonitor error: {e}")

async def setup(bot):
    await bot.add_cog(TerminalMonitor(bot))