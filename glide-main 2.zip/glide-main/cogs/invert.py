import discord
from discord.ext import commands
import asyncio
from utils import create_embed

class InvertCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_inverts = {}  # {guild_id: {user1_id: (user2_id, webhook1, webhook2, task)}}
        self.lock = asyncio.Lock()

    async def _clean_channel_webhooks(self, channel):
        """Delete all webhooks in channel to make room"""
        try:
            webhooks = await channel.webhooks()
            for webhook in webhooks:
                try:
                    await webhook.delete()
                    await asyncio.sleep(0.5)  # Rate limit protection
                except:
                    continue
        except:
            pass

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def invert(self, ctx, user1: discord.User, user2: discord.User = None):
        """Invert messages between two users for 15 minutes"""
        if user2 is None:
            user2 = ctx.author
        
        async with self.lock:
            # Check existing inversions
            guild_inverts = self.active_inverts.get(ctx.guild.id, {})
            if user1.id in guild_inverts or user2.id in guild_inverts:
                return await ctx.send(embed=create_embed("❌ One or both users are already in an inverted pair!"))
            
            # Clean up old webhooks if needed
            await self._clean_channel_webhooks(ctx.channel)
            
            try:
                # Create webhooks that look like the opposite users
                webhook1 = await ctx.channel.create_webhook(
                    name=user2.display_name[:80],  # Discord name limit
                    avatar=await user2.avatar.read() if user2.avatar else None
                )
                webhook2 = await ctx.channel.create_webhook(
                    name=user1.display_name[:80],
                    avatar=await user1.avatar.read() if user1.avatar else None
                )
            except discord.HTTPException as e:
                return await ctx.send(embed=create_embed(f"❌ Failed to create webhooks: {e}"))
            
            # Store the inversion (note webhook1 is user2's appearance)
            if ctx.guild.id not in self.active_inverts:
                self.active_inverts[ctx.guild.id] = {}
            
            self.active_inverts[ctx.guild.id][user1.id] = (user2.id, webhook1, webhook2)
            self.active_inverts[ctx.guild.id][user2.id] = (user1.id, webhook2, webhook1)
            
            # Auto-remove after 15 minutes
            task = asyncio.create_task(self._auto_remove_inversion(ctx.guild.id, user1.id, user2.id))
            self.active_inverts[ctx.guild.id][user1.id] += (task,)
            self.active_inverts[ctx.guild.id][user2.id] += (task,)
        
        await ctx.send(embed=create_embed(
            f"🌀 Messages between {user1.mention} and {user2.mention} are now INVERTED!\n"
            f"All their messages will appear as each other for 15 minutes!"
        ))

    async def _auto_remove_inversion(self, guild_id, user1_id, user2_id):
        """Automatically remove inversion after 15 minutes"""
        await asyncio.sleep(900)
        async with self.lock:
            await self._cleanup_inversion(guild_id, user1_id, user2_id)

    @commands.command(aliases=['cinvert'])
    @commands.has_permissions(manage_messages=True)
    async def clearinvert(self, ctx, user: discord.User = None):
        """Clear message inversions"""
        async with self.lock:
            if ctx.guild.id not in self.active_inverts or not self.active_inverts[ctx.guild.id]:
                return await ctx.send(embed=create_embed("❌ No active message inversions!"))
            
            if user:
                if user.id not in self.active_inverts[ctx.guild.id]:
                    return await ctx.send(embed=create_embed(f"❌ {user.mention} is not in an inverted pair!"))
                
                paired_id, _, _, task = self.active_inverts[ctx.guild.id][user.id]
                await self._cleanup_inversion(ctx.guild.id, user.id, paired_id)
                await ctx.send(embed=create_embed(f"✅ Removed inversion between {user.mention} and their partner"))
            else:
                inverted_pairs = set()
                for uid, (pid, wh1, wh2, task) in self.active_inverts[ctx.guild.id].items():
                    if (uid, pid) not in inverted_pairs and (pid, uid) not in inverted_pairs:
                        inverted_pairs.add((uid, pid))
                        await self._cleanup_inversion(ctx.guild.id, uid, pid)
                await ctx.send(embed=create_embed("✅ Cleared ALL message inversions in this server!"))

    async def _cleanup_inversion(self, guild_id, user1_id, user2_id):
        """Clean up inversion resources"""
        if guild_id not in self.active_inverts:
            return
        
        data1 = self.active_inverts[guild_id].get(user1_id)
        data2 = self.active_inverts[guild_id].get(user2_id)
        
        if data1 and len(data1) > 3:
            data1[3].cancel()
        
        try:
            if data1 and len(data1) > 1:
                await data1[1].delete()
            if data2 and len(data2) > 1:
                await data2[1].delete()
        except:
            pass
        
        if user1_id in self.active_inverts[guild_id]:
            del self.active_inverts[guild_id][user1_id]
        if user2_id in self.active_inverts[guild_id]:
            del self.active_inverts[guild_id][user2_id]
        
        if not self.active_inverts[guild_id]:
            del self.active_inverts[guild_id]

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
            
        guild_id = message.guild.id
        user_id = message.author.id
        
        async with self.lock:
            if guild_id in self.active_inverts and user_id in self.active_inverts[guild_id]:
                paired_id, paired_webhook, _, _ = self.active_inverts[guild_id][user_id]
                
                try:
                    await message.delete()
                    await paired_webhook.send(
                        content=message.content,
                        username=message.author.display_name,
                        avatar_url=message.author.avatar.url if message.author.avatar else None,
                        files=[await attachment.to_file() for attachment in message.attachments],
                        embeds=message.embeds
                    )
                except Exception as e:
                    print(f"Inversion error: {e}")

async def setup(bot):
    await bot.add_cog(InvertCog(bot))