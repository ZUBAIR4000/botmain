import discord
from discord.ext import commands
from utils import create_embed

class PingCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ping(self, ctx):
        """Check bot latency"""
        latency = round(self.bot.latency * 1000)
        await ctx.send(embed=create_embed(
            f"<a:tts_loading:1399005599965909012>    It took **{latency}ms** to ping Javed qbals basement"
        ))

async def setup(bot):
    await bot.add_cog(PingCog(bot))