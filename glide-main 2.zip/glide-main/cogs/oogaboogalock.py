import discord
from discord.ext import commands
import asyncio
import random
import re
from utils import create_embed

class OogaBoogaCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ooga_locks = {}
        self.ooga_phrases = [
            "OOGA", "BOOGA", "SHOOGA", "NOOGA", "GOOGA", "DOOGA", 
            "MOOGA", "ROOGA", "TOOGA", "WOOF", "GRRR", "OOGA BOOGA",
            "BOOGA SHOOGA", "OOGA??", "BOOGA!!", "SHOOGA???", "NOOGA BOOGA",
            "OOGA WOOF", "GRRR OOGA", "BOOGA GRRR", "UGGA", "BOGGA", "OOGA SMASH"
        ]
        self.special_responses = {
            r'\bhello\b': "OOGA",
            r'\bhi\b': "BOOGA",
            r'\bwhat\b': "SHOOGA",
            r'\bwhy\b': "NOOGA",
            r'\bhow\b': "GOOGA",
            r'\bwho\b': "DOOGA",
            r'\bwhen\b': "MOOGA",
            r'\bwhere\b': "ROOGA",
            r'\?+$': lambda m: "OOGA??" if len(m.group()) == 1 else "BOOGA???" if len(m.group()) == 2 else "SHOOGA????",
            r'\!+$': lambda m: "OOGA!!" * len(m.group()),
            r'\bhelp\b': "OOGA HELP BOOGA",
            r'\blol\b': "OOGA LOL BOOGA",
            r'\bthanks\b': "OOGA WELCOME BOOGA"
        }

    async def _clean_channel_webhooks(self, channel):
        """Delete all webhooks in channel"""
        try:
            webhooks = await channel.webhooks()
            for webhook in webhooks:
                try:
                    await webhook.delete()
                    await asyncio.sleep(0.5)
                except:
                    continue
        except:
            pass

    def oogafy_text(self, text):
        """Intelligently convert text to ooga booga"""
        original_text = text
        text = text.lower().strip()
        
        # Check special responses first
        for pattern, response in self.special_responses.items():
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                if callable(response):
                    return response(match)
                return response
        
        # Handle different message types
        if text.isupper() and len(text) > 3:
            return random.choice(["NOOGA YELL!!", "BOOGA SCREAM!!", "OOGA LOUD!!"])
        
        if any(p in text for p in ['?', 'what', 'why', 'how']):
            return random.choice(["OOGA??", "BOOGA??", "SHOOGA NOT KNOW??"])
        
        if len(text.split()) > 5:  # Long messages
            return "OOGA " + " ".join(random.choice(self.ooga_phrases) for _ in range(random.randint(2, 4)))
        
        # Default random response
        return random.choice(self.ooga_phrases)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def oogalock(self, ctx, user: discord.User):
        """Oogalock a user for 15 minutes"""
        if ctx.guild.id not in self.ooga_locks:
            self.ooga_locks[ctx.guild.id] = {}
        
        if user.id in self.ooga_locks[ctx.guild.id]:
            return await ctx.send(embed=create_embed(f"❌ {user.mention} is already oogalocked!"))
        
        # Clean up old webhooks if needed
        await self._clean_channel_webhooks(ctx.channel)
        
        try:
            webhook = await ctx.channel.create_webhook(
                name=user.display_name[:80],  # Webhook name limit
                avatar=await user.avatar.read() if user.avatar else None
            )
        except discord.HTTPException:
            return await ctx.send(embed=create_embed("❌ Failed to create webhook! Check bot permissions."))
        
        self.ooga_locks[ctx.guild.id][user.id] = (webhook, asyncio.get_event_loop().time())
        asyncio.create_task(self._auto_unlock(ctx.guild.id, user.id))
        
        await ctx.send(embed=create_embed(
            f"🔒 {user.mention} has been OOGALOCKED for 15 minutes!\n"
            f"All their messages will be OOGA BOOGA'D!!"
        ))

    async def _auto_unlock(self, guild_id, user_id):
        await asyncio.sleep(900)
        if guild_id in self.ooga_locks and user_id in self.ooga_locks[guild_id]:
            webhook, _ = self.ooga_locks[guild_id][user_id]
            await self._cleanup_oogalock(guild_id, user_id, webhook)

    @commands.command(aliases=['coogalock'])
    @commands.has_permissions(manage_messages=True)
    async def clearoogalock(self, ctx, user: discord.User = None):
        """Clear oogalocks"""
        if ctx.guild.id not in self.ooga_locks or not self.ooga_locks[ctx.guild.id]:
            return await ctx.send(embed=create_embed("❌ No users are currently oogalocked!"))
        
        if user:
            if user.id in self.ooga_locks[ctx.guild.id]:
                webhook, _ = self.ooga_locks[ctx.guild.id][user.id]
                await self._cleanup_oogalock(ctx.guild.id, user.id, webhook)
                await ctx.send(embed=create_embed(f"✅ Removed oogalock from {user.mention}"))
            else:
                await ctx.send(embed=create_embed(f"❌ {user.mention} is not oogalocked"))
        else:
            for user_id, (webhook, _) in list(self.ooga_locks[ctx.guild.id].items()):
                await self._cleanup_oogalock(ctx.guild.id, user_id, webhook)
            await ctx.send(embed=create_embed("✅ Cleared ALL oogalocks! OOGA!"))

    async def _cleanup_oogalock(self, guild_id, user_id, webhook):
        try:
            await webhook.delete()
        except:
            pass
        
        if guild_id in self.ooga_locks and user_id in self.ooga_locks[guild_id]:
            del self.ooga_locks[guild_id][user_id]
            if not self.ooga_locks[guild_id]:
                del self.ooga_locks[guild_id]

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
            
        guild_id = message.guild.id
        if guild_id in self.ooga_locks and message.author.id in self.ooga_locks[guild_id]:
            webhook, _ = self.ooga_locks[guild_id][message.author.id]
            
            try:
                await message.delete()
                ooga_text = self.oogafy_text(message.content)
                await webhook.send(
                    ooga_text,
                    username=message.author.display_name,
                    avatar_url=message.author.avatar.url if message.author.avatar else None
                )
            except Exception as e:
                print(f"Oogalock error: {e}")

async def setup(bot):
    await bot.add_cog(OogaBoogaCog(bot))