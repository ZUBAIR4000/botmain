import discord
from discord.ext import commands
import asyncio

class SingleUserRoleCleaner(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.processing = False

    @commands.command(name='sap')
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def strip_all_roles(self, ctx, member: discord.Member):
        """Remove ALL roles from a member (Admin only)"""
        if self.processing:
            return await ctx.send("⚠️ Another role removal is in progress.")
            
        if member == ctx.guild.owner:
            return await ctx.send("❌ Cannot strip roles from server owner.")
            
        if member == ctx.author:
            return await ctx.send("❌ You cannot strip your own roles.")
            
        if member.top_role >= ctx.guild.me.top_role:
            return await ctx.send("❌ Cannot strip roles from members with equal/higher rank than me.")

        self.processing = True
        
        # Get confirmation
        confirm_embed = discord.Embed(
            title="⚠️ FULL ROLE STRIP CONFIRMATION",
            description=f"This will remove ALL roles from {member.mention}",
            color=discord.Color.orange()
        )
        confirm_embed.add_field(
            name="Current Roles",
            value="\n".join([role.mention for role in member.roles[1:]]) or "No roles",
            inline=False
        )
        confirm_embed.set_footer(text="Type 'confirm' in the next 30 seconds to proceed")
        
        await ctx.send(embed=confirm_embed)
        
        # Wait for confirmation
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.lower() == 'confirm'
        
        try:
            await self.bot.wait_for('message', check=check, timeout=30)
        except asyncio.TimeoutError:
            self.processing = False
            return await ctx.send("🚫 Role strip cancelled (timeout).")

        # Start removal process
        removed_count = 0
        roles_to_remove = [role for role in member.roles if not role.is_default()]
        
        if not roles_to_remove:
            self.processing = False
            return await ctx.send(f"ℹ️ {member.display_name} has no roles to remove.")
        
        initial_msg = await ctx.send(f"⏳ Starting role removal from {member.display_name}...")
        
        for role in sorted(roles_to_remove, key=lambda r: r.position, reverse=True):
            try:
                await member.remove_roles(role, reason=f"Role strip by {ctx.author}")
                removed_count += 1
                
                # Send separate message for each removed role
                embed = discord.Embed(
                    description=f"🗑️ Removed {role.mention} from {member.mention}",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                
                # Rate limit protection
                await asyncio.sleep(1)
                
            except discord.Forbidden:
                await ctx.send(f"❌ Failed to remove {role.mention} (missing permissions)")
            except discord.HTTPException:
                await ctx.send(f"⚠️ Error removing {role.mention} (please try manually)")
        
        # Final result
        self.processing = False
        result_embed = discord.Embed(
            title="✅ Role Strip Complete",
            description=f"Removed {removed_count}/{len(roles_to_remove)} roles from {member.mention}",
            color=discord.Color.green() if removed_count == len(roles_to_remove) else discord.Color.orange()
        )
        await initial_msg.edit(embed=result_embed)

    @strip_all_roles.error
    async def strip_roles_error(self, ctx, error):
        self.processing = False
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need Administrator permissions to use this command.")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("❌ I need Manage Roles permission to execute this command.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send("❌ Please mention a user: `,sap @user`")

async def setup(bot):
    await bot.add_cog(SingleUserRoleCleaner(bot))