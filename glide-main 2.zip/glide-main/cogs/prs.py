import discord
from discord.ext import commands
from discord.ui import Button, View, Modal, TextInput

class Promotions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.panels = {}  # {guild_id: {"panel_channel": id, "servers_channel": id}}

    @commands.group(name="promotions", aliases=["pr", "promo", "promos"], invoke_without_command=True)
    async def promotions(self, ctx):
        """Promotions system management"""
        await ctx.send_help(ctx.command)

    @promotions.command(name="setup")
    @commands.has_permissions(administrator=True)
    async def setup_promotions(self, ctx, panel_channel: discord.TextChannel = None, servers_channel: discord.TextChannel = None):
        """Setup the promotions panel"""
        # Check if setup already exists
        if ctx.guild.id in self.panels:
            return await ctx.send(embed=self.create_embed(
                "Promotions panel already exists!",
                color=discord.Color.red()
            ))
        
        # Create channels if not provided
        if not panel_channel or not servers_channel:
            try:
                category = await ctx.guild.create_category("Promotions")
                panel_channel = await ctx.guild.create_text_channel(
                    "promotions-panel",
                    category=category,
                    reason="Promotions system setup"
                )
                servers_channel = await ctx.guild.create_text_channel(
                    "servers",
                    category=category,
                    reason="Promotions system setup"
                )
            except discord.Forbidden:
                return await ctx.send(embed=self.create_embed(
                    "I don't have permissions to create channels!",
                    color=discord.Color.red()
                ))
        
        # Save configuration
        self.panels[ctx.guild.id] = {
            "panel_channel": panel_channel.id,
            "servers_channel": servers_channel.id
        }
        
        # Create and send panel embed
        embed = discord.Embed(
            title="Promotions Panel",
            description=(
                "**Make sure the bot is added in the server you want to promote or merge or it will cause an error. Create a ticket for paid promotions. if the interaction fails create a ticket in support.\n\n"
                "> <:blue_add:1400817914507952260> become a 808s partner and display your server in https://discord.com/channels/1267031864539873372/1399810534064390257 \n"
                "> <:blue_merge:1400817948641202288> button to merge/move your server to 808s and get top admin roles automatically for the owner and staff."
            ),
            color=discord.Color.white()
        )
        embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else None)
        
        # Create view with buttons
        view = View(timeout=None)
        view.add_item(Button(emoji="<:blue_add:1400817914507952260>", style=discord.ButtonStyle.secondary, custom_id="promote_button"))
        view.add_item(Button(emoji="<:blue_merge:1400817948641202288>", style=discord.ButtonStyle.secondary, custom_id="merge_button"))
        
        # Send panel
        await panel_channel.send(embed=embed, view=view)
        
        # Send success message
        await ctx.send(embed=self.create_embed(
            f"Promotions panel created in {panel_channel.mention}",
            color=discord.Color.green()
        ))

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        # Handle button clicks
        if interaction.type == discord.InteractionType.component:
            custom_id = interaction.data.get("custom_id")
            
            if custom_id == "promote_button":
                await self.handle_promote_button(interaction)
            elif custom_id == "merge_button":
                await self.handle_merge_button(interaction)
        
        # Handle modal submissions
        elif interaction.type == discord.InteractionType.modal_submit:
            custom_id = interaction.data.get("custom_id")
            
            if custom_id == "promote_modal":
                await self.handle_promote_submission(interaction)
            elif custom_id == "merge_modal":
                await self.handle_merge_submission(interaction)

    async def handle_promote_button(self, interaction: discord.Interaction):
        """Handle the promote button click"""
        # Create modal
        modal = Modal(title="Promote Your Server", custom_id="promote_modal")
        
        modal.add_item(TextInput(
            label="Server ID",
            placeholder="enable dev mode to get server id",
            custom_id="server_id",
            required=True
        ))
        
        modal.add_item(TextInput(
            label="Server Advertisement",
            placeholder="Paste your server ad here...",
            custom_id="server_ad",
            style=discord.TextStyle.paragraph,
            required=True
        ))
        
        await interaction.response.send_modal(modal)

    async def handle_merge_button(self, interaction: discord.Interaction):
        """Handle the merge button click"""
        # Create modal
        modal = Modal(title="Request Server Merge", custom_id="merge_modal")
        
        modal.add_item(TextInput(
            label="Server ID",
            placeholder="Enable developer mode and right-click your server to get its ID",
            custom_id="server_id",
            required=True
        ))
        
        await interaction.response.send_modal(modal)

    async def handle_promote_submission(self, interaction: discord.Interaction):
        """Handle promote form submission"""
        server_id = interaction.data["components"][0]["components"][0]["value"]
        server_ad = interaction.data["components"][1]["components"][0]["value"]
        
        # Validate server ID
        try:
            server_id = int(server_id.strip())
        except ValueError:
            return await interaction.response.send_message(
                embed=self.create_embed(
                    "❌ Invalid Server ID. Please enter a valid numeric ID.",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
        
        # Check if bot is in the server
        target_guild = self.bot.get_guild(server_id)
        if not target_guild:
            # Create invite button
            view = View()
            view.add_item(Button(
                label="Invite Bot",
                url=f"https://discord.com/api/oauth2/authorize?client_id={self.bot.user.id}&permissions=8&scope=bot%20applications.commands",
                style=discord.ButtonStyle.url
            ))
            
            return await interaction.response.send_message(
                embed=self.create_embed(
                    "❌ Bot not found in your server. Please invite me first!",
                    color=discord.Color.red()
                ),
                view=view,
                ephemeral=True
            )
        
        # Success response
        await interaction.response.send_message(
            embed=self.create_embed(
                "✅ Your server has been submitted for promotion!",
                color=discord.Color.green()
            ),
            ephemeral=True
        )
        
        # Send to global logs
        await self.send_to_global_logs(
            f"**New Promotion Request**\n"
            f"From: {interaction.user.mention} (`{interaction.user.id}`)\n"
            f"Server: `{target_guild.name}` (`{server_id}`)\n"
            f"Ad:\n{server_ad}",
            interaction.guild.id
        )

    async def handle_merge_submission(self, interaction: discord.Interaction):
        """Handle merge form submission"""
        server_id = interaction.data["components"][0]["components"][0]["value"]
        
        # Validate server ID
        try:
            server_id = int(server_id.strip())
        except ValueError:
            return await interaction.response.send_message(
                embed=self.create_embed(
                    "❌ Invalid Server ID. Please enter a valid numeric ID.",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
        
        # Check if bot is in the server
        target_guild = self.bot.get_guild(server_id)
        if not target_guild:
            return await interaction.response.send_message(
                embed=self.create_embed(
                    "❌ Bot not found in your server. Please add me to your server first!",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
        
        # Success response
        await interaction.response.send_message(
            embed=self.create_embed(
                "✅ Your server merge request has been submitted!",
                color=discord.Color.green()
            ),
            ephemeral=True
        )
        
        # Send to global logs
        await self.send_to_global_logs(
            f"**New Merge Request**\n"
            f"From: {interaction.user.mention} (`{interaction.user.id}`)\n"
            f"Server: `{target_guild.name}` (`{server_id}`)",
            interaction.guild.id
        )

    async def send_to_global_logs(self, content: str, source_guild_id: int):
        """Send promotion/merge requests to global logs"""
        log_channel_id = 1326445662589550633
        log_channel = self.bot.get_channel(log_channel_id)
        
        if log_channel:
            embed = discord.Embed(
                description=content,
                color=discord.Color.blue()
            )
            embed.set_footer(text=f"Source Server ID: {source_guild_id}")
            await log_channel.send(embed=embed)

    def create_embed(self, description: str, color: discord.Color = discord.Color.blue()):
        """Create a formatted embed"""
        return discord.Embed(
            description=description,
            color=color
        )

async def setup(bot):
    await bot.add_cog(Promotions(bot))