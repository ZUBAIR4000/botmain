import random
import aiohttp
import requests
from enum import Enum
from datetime import datetime
from typing import Optional
import discord
from discord.ext import commands

# ===== Hentai utilities (combined) =====
class NsfwApis(Enum):
    Rule34Api     = "https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1&limit=1000&tags=rating:explicit+"
    KonachanApi   = "https://konachan.com/post.json?s=post&q=index&limit=100&tags=rating:explicit+"
    YandereApi    = "https://yande.re/post.json?limit=100&tags=rating:explicit+"
    GelbooruApi   = "https://gelbooru.com/index.php?page=dapi&s=post&q=index&json=1&limit=100&tags=rating:explicit+"
    DanbooruApi   = "https://danbooru.donmai.us/posts.json?limit=100&tags=rating:explicit+"

class NekosFunTags(Enum):
    anal      = "anal"
    blowjob   = "bj"
    cum       = "cum"
    hentai    = "hentai"
    yuri      = "lesbian"

class Hentai:
    def __init__(self):
        self.blacklisted_tags = {"loli", "shota", "cub"}

    def format_tags(self, tags: Optional[str] = None) -> str:
        if not tags:
            return ""
        parts = [t.strip().replace(" ", "_") for t in tags.split(",")]
        return "+".join(parts)

    async def get_nsfw_image(self, provider: NsfwApis, tags: Optional[str] = None):
        tag_str = self.format_tags(tags.lower() if tags else None)
        url = provider.value + tag_str
        async with aiohttp.ClientSession() as sess:
            async with sess.get(url) as r:
                data = await r.json()
        if not data:
            return None
        # unify list
        if provider == NsfwApis.GelbooruApi:
            items = data.get("post", [])
        else:
            items = data
        random.shuffle(items)
        # filter blacklisted
        def valid(item):
            t = item.get("tag_string", item.get("tags", "")).lower().split()
            return not any(b in t for b in self.blacklisted_tags)
        for img in items:
            if valid(img):
                return img
        return None

    @staticmethod
    def nekofun(endpoint: str):
        r = requests.get(f"http://api.nekos.fun:8080/api/{endpoint}")
        if r.status_code != 200:
            return False
        return r.json().get("image")

    @staticmethod
    def boobchi():
        r = requests.get("https://bocchi-api.vercel.app/JSON")
        if r.status_code != 200:
            return False
        j = r.json()
        return j.get("imgURL"), j.get("sauceURL")


# ===== Cog with prefix commands =====
class NSFWImages(commands.Cog):
    """NSFW image/video commands. Prefix: `,`"""

    def __init__(self, bot):
        self.bot = bot
        self.hentai = Hentai()

    def nsfw_only(self, ctx):
        if not ctx.channel.is_nsfw():
            raise commands.CheckFailure("This command can only be used in NSFW channels.")

    @commands.command(name="help_nsfw")
    async def help_nsfw(self, ctx):
        """Shows NSFW command list"""
        cmds = [
            ("rule34 [tags]", "Get image/video from Rule34"),
            ("gelbooru [tags]", "Get image from Gelbooru"),
            ("yandere [tags]", "Get image from Yande.re"),
            ("konachan [tags]", "Get image from Konachan"),
            ("danbooru [tags]", "Get image from Danbooru"),
            ("nekosfun [tag]", "Get image/gif from NekosLife"),
            ("boobchi", "Random ecchi image of Hitori Gotoh")
        ]
        embed = discord.Embed(title="NSFW Commands", color=discord.Color.red())
        for name, desc in cmds:
            embed.add_field(name=f",{name}", value=desc, inline=False)
        await ctx.send(embed=embed)

    @commands.command(name="rule34")
    async def rule34(self, ctx, *, tag: Optional[str] = None):
        """Get hentai from Rule34"""
        self.nsfw_only(ctx)
        img = await self.hentai.get_nsfw_image(NsfwApis.Rule34Api, tag)
        if not img:
            return await ctx.send("No result.")
        url = img.get("file_url")
        embed = discord.Embed(title=f"Score: {img.get('score')}", color=discord.Color.random())
        if img.get("source"):
            embed.add_field(name="Source", value=img["source"], inline=True)
        embed.set_image(url=url)
        embed.set_footer(text="Rule34")
        await ctx.send(embed=embed)

    @commands.command(name="gelbooru")
    async def gelbooru(self, ctx, *, tag: Optional[str] = None):
        """Get hentai from Gelbooru"""
        self.nsfw_only(ctx)
        img = await self.hentai.get_nsfw_image(NsfwApis.GelbooruApi, tag)
        if not img:
            return await ctx.send("No result.")
        url = img.get("file_url")
        embed = discord.Embed(title=f"Score: {img.get('score')}", color=discord.Color.random())
        if img.get("source"):
            embed.add_field(name="Source", value=img["source"], inline=True)
        embed.set_image(url=url)
        embed.set_footer(text=f"Gelbooru • {img.get('created_at')}")
        await ctx.send(embed=embed)

    @commands.command(name="yandere")
    async def yandere(self, ctx, *, tag: Optional[str] = None):
        """Get hentai from Yande.re"""
        self.nsfw_only(ctx)
        img = await self.hentai.get_nsfw_image(NsfwApis.YandereApi, tag)
        if not img:
            return await ctx.send("No result.")
        url = img.get("file_url")
        created = datetime.fromtimestamp(int(img.get("created_at")))
        embed = discord.Embed(title=f"Score: {img.get('score')}", color=discord.Color.random())
        if img.get("source"):
            embed.add_field(name="Source", value=img["source"], inline=True)
        embed.set_image(url=url)
        embed.set_footer(text=f"Yande.re • {created}")
        await ctx.send(embed=embed)

    @commands.command(name="konachan")
    async def konachan(self, ctx, *, tag: Optional[str] = None):
        """Get hentai from Konachan"""
        self.nsfw_only(ctx)
        img = await self.hentai.get_nsfw_image(NsfwApis.KonachanApi, tag)
        if not img:
            return await ctx.send("No result.")
        url = img.get("file_url")
        created = datetime.fromtimestamp(int(img.get("created_at")))
        embed = discord.Embed(title=f"Score: {img.get('score')}", color=discord.Color.random())
        if img.get("source"):
            embed.add_field(name="Source", value=img["source"], inline=True)
        embed.set_image(url=url)
        embed.set_footer(text=f"Konachan • {created}")
        await ctx.send(embed=embed)

    @commands.command(name="danbooru")
    async def danbooru(self, ctx, *, tag: Optional[str] = None):
        """Get hentai from Danbooru"""
        self.nsfw_only(ctx)
        img = await self.hentai.get_nsfw_image(NsfwApis.DanbooruApi, tag)
        if not img:
            return await ctx.send("No result.")
        url = img.get("file_url")
        embed = discord.Embed(title=f"Score: {img.get('score')}", color=discord.Color.random())
        if img.get("source"):
            embed.add_field(name="Source", value=img["source"], inline=True)
        embed.set_image(url=url)
        embed.set_footer(text=f"Danbooru • {img.get('created_at')}")
        await ctx.send(embed=embed)

    @commands.command(name="nekosfun")
    async def nekosfun(self, ctx, tag: Optional[NekosFunTags] = None):
        """Get image/gif from NekosLife"""
        self.nsfw_only(ctx)
        choice = tag.value if tag else random.choice(list(NekosFunTags)).value
        image = Hentai.nekofun(choice)
        if not image:
            return await ctx.send("Error fetching from Nekos.fun")
        embed = discord.Embed(color=discord.Color.random())
        embed.set_image(url=image)
        embed.set_footer(text="Nekos.fun")
        await ctx.send(embed=embed)

    @commands.command(name="boobchi")
    async def boobchi(self, ctx):
        """Random ecchi image of Hitori Gotoh"""
        self.nsfw_only(ctx)
        img, src = Hentai.boobchi()
        if not img:
            return await ctx.send("Error fetching Bocchi-API")
        embed = discord.Embed(color=discord.Color.random(), description=f"[Source]({src})")
        embed.set_image(url=img)
        embed.set_footer(text="Bocchi-API")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(NSFWImages(bot))
