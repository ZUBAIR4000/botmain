import discord
from discord.ext import commands
import json
import os
from typing import Union

class PermissionsManagerCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.perm_config_file = "command_perms.json"
        self.command_data_file = "command_data.json"
        self.special_user_id = 1339387428498178132
        
        # Load or initialize permission configuration
        self.perm_config = self.load_json(self.perm_config_file)
        self.command_data = self.load_json(self.command_data_file)
        
        # Ensure default structure
        if "command_permissions" not in self.perm_config:
            self.perm_config["command_permissions"] = {}
        if "cog_permissions" not in self.perm_config:
            self.perm_config["cog_permissions"] = {}

    def load_json(self, filename):
        """Load JSON data from file"""
        if os.path.exists(filename):
            try:
                with open(filename, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}

    def save_json(self, filename, data):
        """Save JSON data to file"""
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)

    def is_bot_owner_or_special(self, user_id):
        """Check if user is bot owner or special user"""
        return user_id == self.bot.owner_id or user_id == self.special_user_id

    async def has_bypass_perms(self, user, guild):
        """Check if user has bypass permissions (admin or server owner)"""
        if not guild:
            return False
        
        # Server owner can always bypass
        if user.id == guild.owner_id:
            return True
        
        # Check if user has administrator permissions
        if isinstance(user, discord.Member):
            return user.guild_permissions.administrator
        
        return False

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        """Handle permission errors with custom embeds"""
        if isinstance(error, commands.MissingPermissions):
            # Check if this command has custom permissions set
            command_name = ctx.command.qualified_name
            if command_name in self.perm_config["command_permissions"]:
                missing_perms = error.missing_permissions
                if missing_perms:
                    embed = discord.Embed(
                        description=f"<:warning:1365257382619250719> {ctx.author.mention} you are missing permissions `{', '.join(missing_perms)}` to run this command",
                        color=0xffff00  # Yellow
                    )
                    await ctx.send(embed=embed)
                    return
        
        # Let other error handlers deal with it
        raise error

    @commands.group(name='perm', invoke_without_command=True)
    async def perm(self, ctx):
        """Permissions management commands"""
        await ctx.send_help(ctx.command)

    @perm.command(name='add')
    async def perm_add(self, ctx, command_name: str, permission: str):
        """Add a permission requirement to a command"""
        # Check if user is authorized
        if not self.is_bot_owner_or_special(ctx.author.id):
            embed = discord.Embed(
                description=f"<:warning:1365257382619250719> {ctx.author.mention} You don't have permission to use this command.",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
        
        # Find the actual command object
        command = self.bot.get_command(command_name)
        if not command:
            # Check if it's an alias
            for cmd in self.bot.walk_commands():
                if command_name in cmd.aliases:
                    command = cmd
                    break
            
            if not command:
                embed = discord.Embed(
                    description=f"<:warning:1365257382619250719> Command `{command_name}` not found.",
                    color=0xff0000
                )
                await ctx.send(embed=embed)
                return
        
        # Validate permission
        valid_permissions = [
            'administrator', 'manage_guild', 'manage_roles', 'manage_channels',
            'manage_messages', 'manage_webhooks', 'manage_nicknames', 'manage_emojis',
            'kick_members', 'ban_members', 'view_audit_log', 'view_guild_insights',
            'moderate_members', 'mention_everyone', 'create_instant_invite'
        ]
        
        if permission.lower() not in valid_permissions:
            embed = discord.Embed(
                description=f"<:warning:1365257382619250719> Invalid permission `{permission}`. Valid permissions are: {', '.join(valid_permissions)}",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
        
        # Add permission to command
        full_command_name = command.qualified_name
        if full_command_name not in self.perm_config["command_permissions"]:
            self.perm_config["command_permissions"][full_command_name] = []
        
        if permission not in self.perm_config["command_permissions"][full_command_name]:
            self.perm_config["command_permissions"][full_command_name].append(permission)
            
            # Update command_data.json
            if full_command_name in self.command_data:
                if "permissions" not in self.command_data[full_command_name]:
                    self.command_data[full_command_name]["permissions"] = []
                
                if permission not in self.command_data[full_command_name]["permissions"]:
                    self.command_data[full_command_name]["permissions"].append(permission)
            
            self.save_json(self.perm_config_file, self.perm_config)
            self.save_json(self.command_data_file, self.command_data)
            
            embed = discord.Embed(
                description=f"✅ Added permission `{permission}` to command `{full_command_name}`",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                description=f"ℹ️ Command `{full_command_name}` already has permission `{permission}`",
                color=0xffff00
            )
            await ctx.send(embed=embed)

    @perm.command(name='remove')
    async def perm_remove(self, ctx, command_name: str, permission: str):
        """Remove a permission requirement from a command"""
        # Check if user is authorized
        if not self.is_bot_owner_or_special(ctx.author.id):
            embed = discord.Embed(
                description=f"<:warning:1365257382619250719> {ctx.author.mention} You don't have permission to use this command.",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
        
        # Find the actual command object
        command = self.bot.get_command(command_name)
        if not command:
            # Check if it's an alias
            for cmd in self.bot.walk_commands():
                if command_name in cmd.aliases:
                    command = cmd
                    break
            
            if not command:
                embed = discord.Embed(
                    description=f"<:warning:1365257382619250719> Command `{command_name}` not found.",
                    color=0xff0000
                )
                await ctx.send(embed=embed)
                return
        
        # Remove permission from command
        full_command_name = command.qualified_name
        if (full_command_name in self.perm_config["command_permissions"] and 
            permission in self.perm_config["command_permissions"][full_command_name]):
            
            self.perm_config["command_permissions"][full_command_name].remove(permission)
            
            # Update command_data.json
            if (full_command_name in self.command_data and 
                "permissions" in self.command_data[full_command_name] and 
                permission in self.command_data[full_command_name]["permissions"]):
                
                self.command_data[full_command_name]["permissions"].remove(permission)
            
            # Clean up empty permission lists
            if not self.perm_config["command_permissions"][full_command_name]:
                del self.perm_config["command_permissions"][full_command_name]
            
            self.save_json(self.perm_config_file, self.perm_config)
            self.save_json(self.command_data_file, self.command_data)
            
            embed = discord.Embed(
                description=f"✅ Removed permission `{permission}` from command `{full_command_name}`",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                description=f"ℹ️ Command `{full_command_name}` doesn't have permission `{permission}`",
                color=0xffff00
            )
            await ctx.send(embed=embed)

    @perm.command(name='list')
    async def perm_list(self, ctx, command_name: str = None):
        """List permissions for a command or all commands"""
        if command_name:
            # List permissions for specific command
            command = self.bot.get_command(command_name)
            if not command:
                embed = discord.Embed(
                    description=f"<:warning:1365257382619250719> Command `{command_name}` not found.",
                    color=0xff0000
                )
                await ctx.send(embed=embed)
                return
            
            full_command_name = command.qualified_name
            permissions = self.perm_config["command_permissions"].get(full_command_name, [])
            
            if permissions:
                embed = discord.Embed(
                    title=f"Permissions for {full_command_name}",
                    description="\n".join([f"• `{perm}`" for perm in permissions]),
                    color=0x00ff00
                )
            else:
                embed = discord.Embed(
                    description=f"ℹ️ No custom permissions set for `{full_command_name}`",
                    color=0xffff00
                )
            
            await ctx.send(embed=embed)
        else:
            # List all commands with custom permissions
            if not self.perm_config["command_permissions"]:
                embed = discord.Embed(
                    description="ℹ️ No commands have custom permissions set",
                    color=0xffff00
                )
                await ctx.send(embed=embed)
                return
            
            embed = discord.Embed(
                title="Commands with Custom Permissions",
                color=0x00ff00
            )
            
            for cmd_name, perms in self.perm_config["command_permissions"].items():
                if perms:  # Only add if there are permissions
                    embed.add_field(
                        name=cmd_name,
                        value=", ".join([f"`{p}`" for p in perms]),
                        inline=False
                    )
            
            await ctx.send(embed=embed)

    @perm.command(name='clear')
    async def perm_clear(self, ctx, command_name: str):
        """Clear all permissions from a command"""
        # Check if user is authorized
        if not self.is_bot_owner_or_special(ctx.author.id):
            embed = discord.Embed(
                description=f"<:warning:1365257382619250719> {ctx.author.mention} You don't have permission to use this command.",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
        
        # Find the actual command object
        command = self.bot.get_command(command_name)
        if not command:
            embed = discord.Embed(
                description=f"<:warning:1365257382619250719> Command `{command_name}` not found.",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
        
        # Clear permissions from command
        full_command_name = command.qualified_name
        if full_command_name in self.perm_config["command_permissions"]:
            # Update command_data.json
            if (full_command_name in self.command_data and 
                "permissions" in self.command_data[full_command_name]):
                
                self.command_data[full_command_name]["permissions"] = []
            
            del self.perm_config["command_permissions"][full_command_name]
            
            self.save_json(self.perm_config_file, self.perm_config)
            self.save_json(self.command_data_file, self.command_data)
            
            embed = discord.Embed(
                description=f"✅ Cleared all permissions from command `{full_command_name}`",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                description=f"ℹ️ Command `{full_command_name}` doesn't have any custom permissions",
                color=0xffff00
            )
            await ctx.send(embed=embed)

    async def check_command_permissions(self, ctx):
        """Custom permission check for commands"""
        # Bypass for bot owner and special user
        if self.is_bot_owner_or_special(ctx.author.id):
            return True
        
        # Bypass for server admins/owners
        if ctx.guild and await self.has_bypass_perms(ctx.author, ctx.guild):
            return True
        
        # Check if command has custom permissions
        command_name = ctx.command.qualified_name
        if command_name in self.perm_config["command_permissions"]:
            required_perms = self.perm_config["command_permissions"][command_name]
            
            # Check if user has all required permissions
            if ctx.guild and isinstance(ctx.author, discord.Member):
                missing_perms = []
                for perm in required_perms:
                    if not getattr(ctx.author.guild_permissions, perm, False):
                        missing_perms.append(perm)
                
                if missing_perms:
                    # Raise MissingPermissions to trigger our custom error handler
                    raise commands.MissingPermissions(missing_perms)
        
        return True

    # This will be called before every command
    @commands.Cog.listener()
    async def on_command(self, ctx):
        """Check permissions before command execution"""
        await self.check_command_permissions(ctx)

async def setup(bot):
    await bot.add_cog(PermissionsManagerCog(bot))