import discord
from discord.ext import commands
from datetime import datetime, timezone
import asyncio

class TimeoutClear(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.clearing_active = False

    @commands.command(name='cleartimeouts', aliases=['cto'])
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def clear_timeouts(self, ctx):
        """Remove all active timeouts from the server"""
        if self.clearing_active:
            return await ctx.send("⚠️ Timeout clearance is already in progress.")
            
        self.clearing_active = True
        
        # Get current time in UTC
        now = datetime.now(timezone.utc)
        cleared_count = 0
        total_timed_out = 0
        
        # Create progress embed
        embed = discord.Embed(
            title="⏳ Clearing Server Timeouts",
            description="Scanning members...",
            color=discord.Color.orange()
        )
        progress_msg = await ctx.send(embed=embed)
        
        try:
            # Count total timed out members first
            async for member in ctx.guild.fetch_members(limit=None):
                if member.timed_out_until and member.timed_out_until > now:
                    total_timed_out += 1
            
            if total_timed_out == 0:
                embed = discord.Embed(
                    title="✅ No Active Timeouts",
                    description="There are no members currently timed out in this server.",
                    color=discord.Color.green()
                )
                await progress_msg.edit(embed=embed)
                self.clearing_active = False
                return
            
            # Update embed with count
            embed.description = f"Found {total_timed_out} members to clear. Starting removal..."
            await progress_msg.edit(embed=embed)
            
            # Actually clear timeouts
            async for member in ctx.guild.fetch_members(limit=None):
                if member.timed_out_until and member.timed_out_until > now:
                    try:
                        await member.timeout(None, reason="Mass timeout clearance")
                        cleared_count += 1
                        
                        # Update progress every 5 members
                        if cleared_count % 5 == 0:
                            embed.description = (
                                f"Cleared {cleared_count}/{total_timed_out} timeouts\n"
                                f"Current: {member.display_name}"
                            )
                            await progress_msg.edit(embed=embed)
                        
                        # Rate limit protection
                        await asyncio.sleep(0.5)
                        
                    except discord.Forbidden:
                        continue
                    except discord.HTTPException:
                        continue
            
            # Final result
            embed.title = "✅ Timeout Clearance Complete"
            embed.color = discord.Color.green()
            embed.description = (
                f"Successfully cleared {cleared_count} timeout(s).\n"
                f"Failed to clear {total_timed_out - cleared_count} due to permission issues."
            )
            await progress_msg.edit(embed=embed)
            
        except Exception as e:
            embed.title = "❌ Error Clearing Timeouts"
            embed.color = discord.Color.red()
            embed.description = f"An error occurred: {str(e)}"
            await progress_msg.edit(embed=embed)
        finally:
            self.clearing_active = False

    @clear_timeouts.error
    async def clear_timeouts_error(self, ctx, error):
        self.clearing_active = False
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need Timeout Members permission to use this command.")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("❌ I need Timeout Members permission to execute this command.")

async def setup(bot):
    await bot.add_cog(TimeoutClear(bot))