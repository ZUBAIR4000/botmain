import discord
import platform
from datetime import datetime
from discord import __version__ as discordpy_version
from discord.ext import commands
import psutil
import time

class BotInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.start_time = time.time()

    def get_stats(self):
        total_members = sum(guild.member_count or 0 for guild in self.bot.guilds)
        human_members = sum(sum(1 for m in guild.members if not m.bot) for guild in self.bot.guilds)
        bot_members = sum(sum(1 for m in guild.members if m.bot) for guild in self.bot.guilds)
        text_channels = sum(len(guild.text_channels) for guild in self.bot.guilds)
        voice_channels = sum(len(guild.voice_channels) for guild in self.bot.guilds)
        categories = sum(len(guild.categories) for guild in self.bot.guilds)

        return {
            "servers": len(self.bot.guilds),
            "shards": self.bot.shard_count,
            "members": {
                "total": total_members,
                "human": human_members,
                "bots": bot_members
            },
            "channels": {
                "text": text_channels,
                "voice": voice_channels,
                "categories": categories
            }
        }

    def format_uptime(self):
        seconds = int(time.time() - self.start_time)
        days, seconds = divmod(seconds, 86400)
        hours, seconds = divmod(seconds, 3600)
        minutes, seconds = divmod(seconds, 60)
        return f"{days}d {hours}h {minutes}m {seconds}s"

    @commands.hybrid_command(name="botinfo", aliases=["bi"], description="Show bot statistics")
    async def botinfo(self, ctx):
        try:
            stats = self.get_stats()
            
            embed = discord.Embed(
                title=f"{self.bot.user.name} Information",
                description="Premium multi-purpose Discord bot made by 808 network",
                color=0xFAFAFA
            )
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)

            # Server Statistics
            embed.add_field(
                name="Usage",
                value=f"> Used by {stats['members'] ['total']:,} \n > Servers {stats['servers']:,} \n > Shards: {stats['shards']}",
                inline=False
            )

            # Member Statistics
            embed.add_field(
                name="Members",
                value=f"> Total: {stats['members']['total']:,}\n> Human: {stats['members']['human']:,}\n> Bots: {stats['members']['bots']:,}",
                inline=True
            )

            # Channel Statistics
            embed.add_field(
                name="Channels",
                value=f"> Text: {stats['channels']['text']:,}\n> Voice: {stats['channels']['voice']:,}\n> Categories: {stats['channels']['categories']:,}",
                inline=True
            )

            # System Information
            process = psutil.Process()
            embed.add_field(
                name="System",
                value=f"> Commands: {len(self.bot.commands)}\n> Discord.py: {discordpy_version}\n> Python: {platform.python_version()}\n> Ping: {round(self.bot.latency * 1000)}ms\n> Uptime: {self.format_uptime()}",
                inline=False
            )

            await ctx.send(embed=embed)
        except Exception as e:
            print(f"Error in botinfo command: {e}")
            await ctx.send("An error occurred while fetching bot information.")

async def setup(bot):
    await bot.add_cog(BotInfo(bot))