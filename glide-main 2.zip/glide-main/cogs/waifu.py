# cogs/waifu_nsfw.py

import discord
from discord.ext import commands
import aiohttp

class WaifuNSFW(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api_url = "https://api.waifu.pics/nsfw/waifu"

    @commands.command(name="waifu", aliases=["wf"])
    async def waifu_nsfw(self, ctx):
        """Fetches a random NSFW waifu image (plain link)."""
        if not getattr(ctx.channel, "nsfw", False):
            emoji = discord.utils.get(self.bot.emojis, name="error")
            error_msg = f"{emoji} |" if emoji else ":x: |"
            return await ctx.send(f"{error_msg} This command can only be run in **NSFW** channels.")

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.api_url) as resp:
                    data = await resp.json()
                    url = data.get("url")
                    if not url:
                        return await ctx.send("❌ No image found. Try again.")
        except Exception:
            return await ctx.send("❌ Failed to fetch image. Please try again later.")

        await ctx.send(f"**NSFW🔞 | Waifus**\n[Source]({url})")

async def setup(bot):
    bot.remove_command("waifu")
    bot.remove_command("wf")
    await bot.add_cog(WaifuNSFW(bot))
