import discord
import asyncio
from discord.ext import commands

class TypingIndicator(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.typing_channels = set()
        self.TARGET_CHANNEL_ID = 1309879760326754385

    @commands.command(name="starttyping")
    async def start_typing(self, ctx):
        """Start infinite typing indicator in this channel"""
        if ctx.channel.id != self.TARGET_CHANNEL_ID:
            return await ctx.send(f"❌ This command can only be used in <#{self.TARGET_CHANNEL_ID}>")
            
        if ctx.channel.id in self.typing_channels:
            return await ctx.send("⌨️ Typing indicator is already active in this channel")
            
        self.typing_channels.add(ctx.channel.id)
        asyncio.create_task(self.typing_loop(ctx.channel))
        await ctx.send("⌨️ **Infinite typing indicator started!** Use `,stoptyping` to stop.")

    @commands.command(name="stoptyping")
    async def stop_typing(self, ctx):
        """Stop infinite typing indicator in this channel"""
        if ctx.channel.id != self.TARGET_CHANNEL_ID:
            return await ctx.send(f"❌ This command can only be used in <#{self.TARGET_CHANNEL_ID}>")
            
        if ctx.channel.id not in self.typing_channels:
            return await ctx.send("ℹ️ No active typing indicator in this channel")
            
        self.typing_channels.discard(ctx.channel.id)
        await ctx.send("⌨️ **Typing indicator stopped!**")

    async def typing_loop(self, channel):
        """Maintain typing indicator in the channel"""
        while channel.id in self.typing_channels:
            try:
                # Send typing indicator for 10 seconds
                async with channel.typing():
                    await asyncio.sleep(8)  # Discord typing lasts ~10 seconds
                    
                # Short pause between typing sessions
                await asyncio.sleep(0.5)
            except discord.NotFound:
                # Channel was deleted
                self.typing_channels.discard(channel.id)
                return
            except discord.Forbidden:
                # Bot lost permissions
                self.typing_channels.discard(channel.id)
                return
            except Exception:
                # Other errors - pause briefly and continue
                await asyncio.sleep(2)

async def setup(bot):
    await bot.add_cog(TypingIndicator(bot))