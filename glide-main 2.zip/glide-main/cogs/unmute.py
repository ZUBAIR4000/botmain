import discord
from discord.ext import commands
import asyncio

class MuteManagement(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="mutelist")
    @commands.has_permissions(manage_roles=True)
    async def mute_list(self, ctx):
        """Show all muted members in the server"""
        # Find muted role
        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if not muted_role:
            return await ctx.send("❌ No 'Muted' role found in this server")
        
        # Get members with muted role or timeout
        muted_members = []
        timed_out_members = []
        
        for member in ctx.guild.members:
            if muted_role in member.roles:
                muted_members.append(member)
            if member.timed_out_until:
                timed_out_members.append(member)
        
        # Create embed
        embed = discord.Embed(
            title="🔇 Muted Members List",
            color=discord.Color.orange(),
            description=f"Total members muted: **{len(muted_members) + len(timed_out_members)}**"
        )
        
        # Add muted by role section
        if muted_members:
            muted_list = "\n".join(f"• {m.mention} (Role mute)" for m in muted_members)
            embed.add_field(
                name=f"Muted by Role ({len(muted_members)})",
                value=muted_list,
                inline=False
            )
        else:
            embed.add_field(
                name="Muted by Role",
                value="No members muted by role",
                inline=False
            )
            
        # Add timed out section
        if timed_out_members:
            timeout_list = "\n".join(f"• {m.mention} (Timeout)" for m in timed_out_members)
            embed.add_field(
                name=f"Timed Out ({len(timed_out_members)})",
                value=timeout_list,
                inline=False
            )
        else:
            embed.add_field(
                name="Timed Out",
                value="No members timed out",
                inline=False
            )
            
        await ctx.send(embed=embed)

    @commands.command(name="unmuteall")
    @commands.has_permissions(manage_roles=True)
    async def unmute_all(self, ctx):
        """Unmute all members in the server"""
        # Find muted role
        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        
        # Get members to unmute
        members_to_unmute = []
        for member in ctx.guild.members:
            if muted_role and muted_role in member.roles:
                members_to_unmute.append(member)
            if member.timed_out_until:
                members_to_unmute.append(member)
        
        if not members_to_unmute:
            return await ctx.send("no mutes found")
            
        # Confirmation view
        view = self.ConfirmationView(ctx.author.id)
        msg = await ctx.send(
            f"⚠️ Are you sure you want to unmute **{len(members_to_unmute)}** members?",
            view=view
        )
        
        # Wait for confirmation
        await view.wait()
        if not view.value:
            return await msg.edit(content="aborted", view=None)
        
        # Unmute members
        await msg.edit(content=f"<a:loading_circle:1387477958570148021> Unmuting **{len(members_to_unmute)}** members...", view=None)
        success_count = 0
        
        for member in members_to_unmute:
            try:
                # Remove timeout
                if member.timed_out_until:
                    await member.timeout(None)
                
                # Remove muted role
                if muted_role and muted_role in member.roles:
                    await member.remove_roles(muted_role)
                
                success_count += 1
                await ctx.send(f"<:yes1:1389288766291574804> Unmuted {member.mention}")
                await asyncio.sleep(0.5)  # Rate limit prevention
            except discord.Forbidden:
                await ctx.send(f"❌ Could not unmute {member.mention} (missing permissions)")
            except discord.HTTPException:
                await ctx.send(f"❌ Could not unmute {member.mention} (HTTP error)")
        
        await msg.edit(content=f"✅ Successfully unmuted **{success_count}/{len(members_to_unmute)}** members!")

    class ConfirmationView(discord.ui.View):
        def __init__(self, author_id):
            super().__init__(timeout=30)
            self.value = None
            self.author_id = author_id
            
        @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger)
        async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message("❌ You can't confirm this action!", ephemeral=True)
            self.value = True
            self.stop()
            
        @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
        async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message("❌ You can't cancel this action!", ephemeral=True)
            self.value = False
            self.stop()
            
        async def on_timeout(self):
            self.stop()

async def setup(bot):
    await bot.add_cog(MuteManagement(bot))